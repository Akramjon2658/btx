; /* /bitrix/js/landing/bxdom.js?17081150491560*/
; /* /bitrix/js/landing/typedef.min.js?170811504936*/
; /* /bitrix/js/landing/ui/editor_config.min.js?1708115049316*/
; /* /bitrix/js/landing/ui/style_factory.min.js?17081150491806*/
; /* /bitrix/js/landing/ui/field_factory.min.js?17081150496802*/
; /* /bitrix/js/landing/ui/card/block_preview_card.min.js?17081150483777*/
; /* /bitrix/js/landing/ui/card/field_group.min.js?1708115048774*/
; /* /bitrix/js/landing/ui/card/image_preview_card.min.js?17081150481553*/
; /* /bitrix/js/landing/ui/card/add_your_first_block.js?1708115048770*/
; /* /bitrix/js/landing/ui/card/base_image_library_card.min.js?17081150484171*/
; /* /bitrix/js/landing/ui/card/unsplash_card.min.js?17081150482529*/
; /* /bitrix/js/landing/ui/card/google_images_card.min.js?17081150483828*/
; /* /bitrix/js/landing/ui/card/uploader_card.js?1708115048800*/
; /* /bitrix/js/landing/ui/card/loader.min.js?1708115048617*/
; /* /bitrix/js/landing/ui/card/link_card.js?1708115048771*/
; /* /bitrix/js/landing/ui/card/landing_preview.min.js?1708115048805*/
; /* /bitrix/js/landing/ui/card/block_html_preview.js?1708115048990*/
; /* /bitrix/js/landing/ui/card/tab_card.min.js?17081150482439*/
; /* /bitrix/js/landing/ui/card/dynamic_fields_group.min.js?1708115048633*/
; /* /bitrix/js/landing/ui/card/add_page_card.min.js?17081150482627*/
; /* /bitrix/js/landing/ui/tool/color_picker.min.js?17081150493735*/
; /* /bitrix/js/landing/ui/tool/auto-font-scale.min.js?17081150491240*/
; /* /bitrix/js/landing/ui/tool/auto-font-scale-entry.min.js?17081150492175*/
; /* /bitrix/js/landing/ui/tool/suggests.min.js?17081150491716*/
; /* /bitrix/js/landing/ui/tool/font-manager.min.js?17081150492719*/
; /* /bitrix/js/landing/ui/adapter/css-property.min.js?1708115049408*/
; /* /bitrix/js/landing/ui/button/plus_button.js?1708115049662*/
; /* /bitrix/js/landing/ui/button/editor_action_button.min.js?1708115049760*/
; /* /bitrix/js/landing/ui/button/ai_text_button.min.js?1708115049342*/
; /* /bitrix/js/landing/ui/button/design_button.min.js?1708115049299*/
; /* /bitrix/js/landing/ui/button/color_button.min.js?17081150492396*/
; /* /bitrix/js/landing/ui/button/block_card_action.min.js?1708115049418*/
; /* /bitrix/js/landing/ui/button/create_link.min.js?1708115049733*/
; /* /bitrix/js/landing/ui/button/create_table.min.js?17081150493459*/
; /* /bitrix/js/landing/ui/button/paste_table.min.js?1708115049932*/
; /* /bitrix/js/landing/ui/button/delete_element_table.min.js?1708115049826*/
; /* /bitrix/js/landing/ui/button/align_table.min.js?17081150491082*/
; /* /bitrix/js/landing/ui/button/style_table.min.js?17081150494266*/
; /* /bitrix/js/landing/ui/button/copy_table.min.js?1708115049893*/
; /* /bitrix/js/landing/ui/button/delete_table.min.js?1708115049599*/
; /* /bitrix/js/landing/ui/button/change_tag.min.js?17081150491933*/
; /* /bitrix/js/landing/ui/button/text_background_color.min.js?1708115049531*/
; /* /bitrix/js/landing/ui/button/create_page.min.js?1708115049624*/
; /* /bitrix/js/landing/ui/panel/base_button_panel.min.js?1708115049874*/
; /* /bitrix/js/landing/ui/panel/editor_panel.min.js?170811504913898*/
; /* /bitrix/js/landing/ui/panel/small_editor_panel.js?17081150491474*/
; /* /bitrix/js/landing/ui/panel/edit_content_panel.js?17081150494274*/
; /* /bitrix/js/landing/ui/panel/preview_panel.js?17081150494501*/
; /* /bitrix/js/landing/ui/panel/unsplash_panel.js?17081150494349*/
; /* /bitrix/js/landing/ui/panel/image_panel.min.js?17081150493651*/
; /* /bitrix/js/landing/ui/panel/url_list.min.js?170811504911600*/
; /* /bitrix/js/landing/ui/panel/top_panel.min.js?170811504911370*/
; /* /bitrix/js/landing/ui/panel/card_action.js?17081150492386*/
; /* /bitrix/js/landing/ui/panel/link_panel.min.js?17081150494116*/
; /* /bitrix/js/landing/ui/panel/google_fonts_panel.min.js?170811504913021*/
; /* /bitrix/js/landing/ui/panel/google_images_settings_panel.min.js?17081150492137*/
; /* /bitrix/js/landing/ui/panel/catalog_panel.js?170811504911032*/
; /* /bitrix/js/landing/ui/panel/status_panel.js?17081150491915*/
; /* /bitrix/js/landing/ui/panel/detail_page_panel.min.js?17081150494359*/
; /* /bitrix/js/landing/ui/field/dropdown_field.min.js?17081150494296*/
; /* /bitrix/js/landing/ui/field/dropdown_preview_field.min.js?17081150492746*/
; /* /bitrix/js/landing/ui/field/unit_field.min.js?17081150492463*/
; /* /bitrix/js/landing/ui/field/range_field.min.js?17081150498326*/
; /* /bitrix/js/landing/ui/field/button_group_field.min.js?17081150492697*/
; /* /bitrix/js/landing/ui/field/dropdown_inline.min.js?17081150492393*/
; /* /bitrix/js/landing/ui/field/dnd_list.min.js?17081150499052*/
; /* /bitrix/js/landing/ui/field/sortable_list.min.js?17081150492604*/
; /* /bitrix/js/landing/ui/field/position_field.min.js?17081150491930*/
; /* /bitrix/js/landing/ui/field/checkbox_field.min.js?17081150492746*/
; /* /bitrix/js/landing/ui/field/radio_field.min.js?1708115049469*/
; /* /bitrix/js/landing/ui/field/multiselect_field.min.js?17081150495813*/
; /* /bitrix/js/landing/ui/field/filter_field.min.js?17081150491673*/
; /* /bitrix/js/landing/ui/field/font_field.min.js?17081150495233*/
; /* /bitrix/js/landing/ui/field/html_field.min.js?17081150491233*/
; /* /bitrix/js/landing/ui/field/embed_field.min.js?17081150493108*/
; /* /bitrix/js/landing/ui/field/embed_bg_field.min.js?1708115049939*/
; /* /bitrix/js/landing/ui/field/date_field.min.js?17081150491896*/
; /* /bitrix/js/landing/ui/field/block_source_field.min.js?17081150491561*/
; /* /bitrix/js/landing/ui/field/dynamic_image_field.min.js?17081150491947*/
; /* /bitrix/js/landing/ui/field/dynamic_dropdown_field.min.js?1708115049430*/
; /* /bitrix/js/landing/ui/field/pages_field.min.js?17081150491478*/
; /* /bitrix/js/landing/ui/field/click_action_field.min.js?17081150492334*/
; /* /bitrix/js/landing/ui/field/color_field.min.js?17081150492119*/
; /* /bitrix/js/landing/ui/style_node.min.js?17081150495255*/
; /* /bitrix/js/landing/events/block_event.min.js?1708115049520*/
; /* /bitrix/js/landing/group.min.js?1708115049576*/
; /* /bitrix/js/landing/block.min.js?170811504981296*/
; /* /bitrix/js/landing/card.min.js?17081150491589*/
; /* /bitrix/js/landing/node.min.js?17081150492544*/
; /* /bitrix/js/landing/node/text.min.js?170811504917809*/
; /* /bitrix/js/landing/node/link.min.js?17081150493900*/
; /* /bitrix/js/landing/node/img.min.js?17081150496006*/
; /* /bitrix/js/landing/node/ul.js?17081150495944*/
; /* /bitrix/js/landing/node/map.min.js?17081150492472*/
; /* /bitrix/js/landing/node/component.min.js?1708115049491*/
; /* /bitrix/js/landing/node/icon.min.js?17081150491728*/
; /* /bitrix/js/landing/node/embed.min.js?17081150492431*/
; /* /bitrix/js/landing/client/unsplash.min.js?17081150491537*/
; /* /bitrix/js/landing/client/google_images.min.js?17081150491041*/
; /* /bitrix/js/landing/client/google_fonts.min.js?17081150491141*/
; /* /bitrix/js/landing/mediaservice/base_mediaservice.min.js?17081150482709*/
; /* /bitrix/js/landing/mediaservice/youtube_mediaservice.min.js?17081150483285*/
; /* /bitrix/js/landing/mediaservice/rutube_mediaservice.min.js?1708115048971*/
; /* /bitrix/js/landing/mediaservice/vk_mediaservice.min.js?17081150483055*/
; /* /bitrix/js/landing/mediaservice/vimeo_mediaservice.min.js?17081150482897*/
; /* /bitrix/js/landing/mediaservice/vine_mediaservice.min.js?17081150481047*/
; /* /bitrix/js/landing/mediaservice/instagram_mediaservice.min.js?17081150481215*/
; /* /bitrix/js/landing/mediaservice/google_maps_search_mediaservice.min.js?17081150481169*/
; /* /bitrix/js/landing/mediaservice/google_maps_place_mediaservice.min.js?1708115048828*/
; /* /bitrix/js/landing/mediaservice/facebook_page_plugin_service.min.js?17081150482767*/
; /* /bitrix/js/landing/mediaservice/facebook_post_embed_service.min.js?17081150481228*/
; /* /bitrix/js/landing/mediaservice/facebook_video_embed_service.min.js?17081150481239*/
; /* /bitrix/js/landing/mediaservice/service_factory.min.js?1708115048847*/
; /* /bitrix/js/landing/error_manager.min.js?17081150492325*/
; /* /bitrix/js/landing/external/webfontloader/webfontloader_landing.min.js?170811504912558*/

; /* Start:"a:4:{s:4:"full";s:42:"/bitrix/js/landing/bxdom.js?17081150491560";s:6:"source";s:27:"/bitrix/js/landing/bxdom.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
;(function(window) {

	var debug = 0 ? console.log.bind(console, '[BXDOM]') : function() {};

	var raf = (
		window.requestAnimationFrame
		|| window.webkitRequestAnimationFrame
		|| window.mozRequestAnimationFrame
		|| window.msRequestAnimationFrame
		|| function(cb) { return setTimeout(cb, 16); }
	);

	var BXDOM = function()
	{
		this.reads = [];
		this.writes = [];
		this.raf = raf.bind(window);
		debug('initialized', this);
	};

	BXDOM.prototype = {
		constructor: BXDOM,

		read: function(fn, ctx)
		{
			debug('read');
			this.reads.push(!ctx ? fn : fn.bind(ctx));
			scheduleFlush(this);
		},

		write: function(fn, ctx)
		{
			debug('write');
			this.writes.push(!ctx ? fn : fn.bind(ctx));
			scheduleFlush(this);
		},

		catch: null
	};

	function scheduleFlush(dom) {
		if (!dom.scheduled)
		{
			dom.scheduled = true;
			dom.raf(flush.bind(null, dom));
			debug('flush scheduled');
		}
	}

	function flush(dom) {
		debug('flush');

		var writes = dom.writes;
		var reads = dom.reads;
		var error;

		try {
			debug('flushing reads', reads.length);
			runTasks(reads);
			debug('flushing writes', writes.length);
			runTasks(writes);
		} catch (e) { error = e; }

		dom.scheduled = false;

		if (reads.length || writes.length)
		{
			scheduleFlush(dom);
		}

		if (error)
		{
			debug('task errored', error.message);
			if (dom.catch) dom.catch(error);
			else throw error;
		}
	}

	function runTasks(tasks) {
		debug('run tasks');
		var task;

		while (task = tasks.shift())
		{
			task();
		}
	}

	BX.DOM = (BX.DOM || new BXDOM());

})(window);
/* End */
;
; /* Start:"a:4:{s:4:"full";s:46:"/bitrix/js/landing/typedef.min.js?170811504936";s:6:"source";s:29:"/bitrix/js/landing/typedef.js";s:3:"min";s:33:"/bitrix/js/landing/typedef.min.js";s:3:"map";s:33:"/bitrix/js/landing/typedef.map.js";}"*/

/* End */
;
; /* Start:"a:4:{s:4:"full";s:56:"/bitrix/js/landing/ui/editor_config.min.js?1708115049316";s:6:"source";s:38:"/bitrix/js/landing/ui/editor_config.js";s:3:"min";s:42:"/bitrix/js/landing/ui/editor_config.min.js";s:3:"map";s:42:"/bitrix/js/landing/ui/editor_config.map.js";}"*/
(function(){"use strict";document.execCommand("defaultParagraphSeparator",false,"p");document.execCommand("styleWithCSS",false,true);if(top!==window){parent.document.addEventListener("keydown",function(e){parent.BX.onCustomEvent(parent.document,"iframe:keydown",[e])})}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:57:"/bitrix/js/landing/ui/style_factory.min.js?17081150491806";s:6:"source";s:38:"/bitrix/js/landing/ui/style_factory.js";s:3:"min";s:42:"/bitrix/js/landing/ui/style_factory.min.js";s:3:"map";s:42:"/bitrix/js/landing/ui/style_factory.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Factory");BX.Landing.UI.Factory.StyleFactory=function(e){this.frame=!!e.frame?e.frame:null;this.postfix=typeof e.postfix==="string"?e.postfix:""};function e(e,t,n,l,i){l=!!l?l:"";if(!!t&&typeof t==="object"){var o=Object.keys(t);t=o.map((function(e){return t[e]}))}else if(typeof t==="string"){t=[t]}t.forEach((function(t){n.forEach((function(n){if(t+l!==n.value+l){e.classList.remove(n.value+l)}if(i){e.style[i]=null;[].slice.call(e.querySelectorAll("*")).forEach((function(e){e.style[i]=null}))}}));e.classList.add(t+l)}))}BX.Landing.UI.Factory.StyleFactory.prototype={createField:function(t){var n=null;var l={title:t.title,selector:t.selector,contentRoot:BX.Landing.PageObject.getStylePanelContent(),style:t.style,format:e,frame:this.frame,property:t.property,pseudoElement:t.pseudoElement,pseudoClass:t.pseudoClass,items:t.items,postfix:this.postfix,onChange:t.onChange,onReset:t.onReset,help:t.help,attrKey:t.attrKey};if(t.type==="slider"||t.type==="range-slider"){n=new BX.Landing.UI.Field.Range(Object.assign(l,{type:t.type==="range-slider"?"multiple":null}))}if(t.type==="buttons"){n=new BX.Landing.UI.Field.ButtonGroup(Object.assign(l,{multiple:t.multiple===true}))}if(t.type==="display"){n=new BX.Landing.UI.Field.ButtonGroup(Object.assign(l,{multiple:true,className:"landing-ui-display-button-group"}))}if(t.type==="palette"){n=new BX.Landing.UI.Field.ColorPalette(l)}if(t.type==="color"){n=new BX.Landing.UI.Field.ColorField(Object.assign(l,{block:t.block,styleNode:t.styleNode,subtype:t.subtype}))}if(t.type==="list"&&t.style!=="font-family"){n=new BX.Landing.UI.Field.Dropdown(l)}if(t.style==="font-family"){n=new BX.Landing.UI.Field.Font(Object.assign(l,{styleNode:t.styleNode}))}return n}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:57:"/bitrix/js/landing/ui/field_factory.min.js?17081150496802";s:6:"source";s:38:"/bitrix/js/landing/ui/field_factory.js";s:3:"min";s:42:"/bitrix/js/landing/ui/field_factory.min.js";s:3:"map";s:42:"/bitrix/js/landing/ui/field_factory.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Factory");var e=BX.Landing.Utils.isFunction;var t=BX.Landing.Utils.assign;BX.Landing.UI.Factory.FieldFactory=function(t){this.uploadParams=t.uploadParams||{};this.linkOptions=t.linkOptions||{};this.selector=t.selector;this.onChangeHandler=e(t.onChange)?t.onChange:function(){};this.onValueChangeHandler=e(t.onValueChange)?t.onValueChange:function(){}};BX.Landing.UI.Factory.FieldFactory.prototype={create:function(e){if(e.type==="text"){return new BX.Landing.UI.Field.Text({title:e.name,selector:this.selector,content:e.value,placeholder:e.placeholder,description:e.description,textOnly:true,onInput:e.onInput,onChange:this.onChangeHandler,onValueChange:this.onValueChangeHandler,attribute:e.attribute,attrKey:e.attrKey,disabled:BX.Text.toBoolean(e.disabled)})}if(e.type==="date"){return new BX.Landing.UI.Field.Date({title:e.name,selector:this.selector,content:e.value,placeholder:e.placeholder,description:e.description,textOnly:true,onInput:e.onInput,onChange:this.onChangeHandler,onValueChange:this.onValueChangeHandler,attribute:e.attribute,attrKey:e.attrKey,time:e.time,format:e.format,disabled:BX.Text.toBoolean(e.disabled)})}if(e.type==="html"){return new BX.Landing.UI.Field.Html({title:e.name,selector:this.selector,content:e.value,placeholder:e.placeholder,onChange:this.onChangeHandler,onValueChange:this.onValueChangeHandler,attribute:e.attribute,attrKey:e.attrKey,disabled:BX.Text.toBoolean(e.disabled)})}if(!e.type||e.type==="list"||e.type==="dropdown"){return new BX.Landing.UI.Field.Dropdown({title:e.name,selector:this.selector,items:e.items,content:e.value,onChange:this.onChangeHandler,onValueChange:this.onValueChangeHandler,attribute:e.attribute,attrKey:e.attrKey,disabled:BX.Text.toBoolean(e.disabled),dependency:e.dependency,hint:e.hint})}if(e.type==="image"){return new BX.Landing.UI.Field.Image({title:e.name,selector:this.selector,content:e.value,onChange:this.onChangeHandler,onValueChange:this.onValueChangeHandler,attribute:e.attribute,attrKey:e.attrKey,uploadParams:this.uploadParams,disabled:BX.Text.toBoolean(e.disabled)})}if(e.type==="icon"){e.value=BX.Landing.Utils.isPlainObject(e.value)?e.value:{};return new BX.Landing.UI.Field.Icon({title:e.name,selector:this.selector,content:{type:"icon",src:"",alt:"",classList:"classList"in e.value?e.value.classList:[]},onChange:this.onChangeHandler,onValueChange:this.onValueChangeHandler,attribute:e.attribute,attrKey:e.attrKey,disabled:BX.Text.toBoolean(e.disabled)})}if(e.type==="link"){return new BX.Landing.UI.Field.Link({title:e.name,selector:this.selector,content:e.value,onChange:this.onChangeHandler,onValueChange:this.onValueChangeHandler,attribute:e.attribute,attrKey:e.attrKey,options:this.linkOptions,disabled:BX.Text.toBoolean(e.disabled)})}if(e.type==="url"){e=t({},e,{title:e.name,content:e.value,selector:this.selector,onChange:this.onChangeHandler,onValueChange:this.onValueChangeHandler,options:this.linkOptions,textOnly:true,disabled:BX.Text.toBoolean(e.disabled)});return new BX.Landing.UI.Field.LinkUrl(e)}if(e.type==="dynamic_source"){e=t({},e,{title:e.name,content:e.value,selector:this.selector,onChange:this.onChangeHandler,onValueChange:this.onValueChangeHandler,options:this.linkOptions,textOnly:true,currentPageOnly:e.currentPageOnly,allowedTypes:["block"],disableCustomURL:true,disallowType:true,customPlaceholder:BX.Landing.Loc.getMessage("LANDING_BLOCK__BLOCK_SOURCE_PLACEHOLDER"),panelTitle:BX.Landing.Loc.getMessage("LANDING_BLOCK__BLOCK_SOURCE_PLACEHOLDER"),disabled:BX.Text.toBoolean(e.disabled)});return new BX.Landing.UI.Field.LinkUrl(e)}if(e.type==="slider"||e.type==="range-slider"){return new BX.Landing.UI.Field.Range({title:e.name,selector:this.selector,items:e.items,content:e.value,onChange:this.onChangeHandler,onValueChange:this.onValueChangeHandler,attribute:e.attribute,attrKey:e.attrKey,frame:window,type:e.type==="range-slider"?"multiple":null,disabled:BX.Text.toBoolean(e.disabled)})}if(e.type==="palette"){return new BX.Landing.UI.Field.ColorPalette({title:e.name,selector:this.selector,items:e.items,content:e.value,onChange:this.onChangeHandler,onValueChange:this.onValueChangeHandler,attribute:e.attribute,attrKey:e.attrKey,property:e.property,disabled:BX.Text.toBoolean(e.disabled)})}if(e.type==="color"){return new BX.Landing.UI.Field.ColorField({title:e.name,selector:this.selector,subtype:e.subtype,content:e.value,onChange:this.onChangeHandler,onValueChange:this.onValueChangeHandler,attribute:e.attribute,attrKey:e.attrKey,disabled:BX.Text.toBoolean(e.disabled)})}if(e.type==="catalog-view"){return new BX.Landing.UI.Field.DragAndDropList({title:e.name,selector:this.selector,items:e.items,value:e.value,onChange:this.onChangeHandler,onValueChange:this.onValueChangeHandler,attribute:e.attribute,attrKey:e.attrKey,property:e.property,disabled:BX.Text.toBoolean(e.disabled)})}if(e.type==="sortable-list"){return new BX.Landing.UI.Field.SortableList({title:e.name,selector:this.selector,items:e.items,value:e.value,onChange:this.onChangeHandler,onValueChange:this.onValueChangeHandler,attribute:e.attribute,attrKey:e.attrKey,property:e.property,disabled:BX.Text.toBoolean(e.disabled)})}if(e.type==="position"){return new BX.Landing.UI.Field.Position({title:e.name,selector:this.selector,items:e.items,value:e.value,onChange:this.onChangeHandler,onValueChange:this.onValueChangeHandler,attribute:e.attribute,attrKey:e.attrKey,property:e.property,mode:e.mode,disabled:BX.Text.toBoolean(e.disabled)})}if(e.type==="checkbox"){return new BX.Landing.UI.Field.Checkbox({title:e.name,selector:this.selector,items:e.items,value:e.value,onChange:this.onChangeHandler,onValueChange:this.onValueChangeHandler,attribute:e.attribute,attrKey:e.attrKey,property:e.property,compact:e.compact,disabled:BX.Text.toBoolean(e.disabled)})}if(e.type==="radio"){return new BX.Landing.UI.Field.Radio({title:e.name,selector:this.selector,items:e.items,value:e.value,onChange:this.onChangeHandler,onValueChange:this.onValueChangeHandler,attribute:e.attribute,attrKey:e.attrKey,property:e.property,compact:e.compact,disabled:BX.Text.toBoolean(e.disabled)})}if(e.type==="multiselect"){return new BX.Landing.UI.Field.MultiSelect({title:e.name,selector:this.selector,items:e.items,value:e.value,onChange:this.onChangeHandler,onValueChange:this.onValueChangeHandler,attribute:e.attribute,attrKey:e.attrKey,property:e.property,disabled:BX.Text.toBoolean(e.disabled)})}if(e.type==="filter"){return new BX.Landing.UI.Field.Filter({title:e.name,selector:this.selector,items:e.items,value:e.value,html:e.html,filterId:e.filterId,onChange:this.onChangeHandler,onValueChange:this.onValueChangeHandler,attribute:e.attribute,attrKey:e.attrKey,property:e.property,disabled:BX.Text.toBoolean(e.disabled)})}}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:67:"/bitrix/js/landing/ui/card/block_preview_card.min.js?17081150483777";s:6:"source";s:48:"/bitrix/js/landing/ui/card/block_preview_card.js";s:3:"min";s:52:"/bitrix/js/landing/ui/card/block_preview_card.min.js";s:3:"map";s:52:"/bitrix/js/landing/ui/card/block_preview_card.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Card");var e=BX.Landing.Utils.addClass;var i=BX.Landing.Utils.append;var a=BX.Landing.Utils.create;BX.Landing.UI.Card.BlockPreviewCard=function(t){BX.Landing.UI.Card.BaseCard.apply(this,arguments);this.layout.classList.add("landing-ui-card-block-preview");this.mode=typeof t.mode==="string"?t.mode:"img";this.title=typeof t.title==="string"?t.title:"";this.appExpired=typeof t.app_expired==="boolean"?t.app_expired:false;this.repoId=t.repo_id||null;this.imageSrc=typeof t.image==="string"?t.image:"/bitrix/images/landing/empty-preview.png";this.code=typeof t.code==="string"?t.code:"";this.favorite=t.favorite;this.favoriteMy=t.favoriteMy;this.isNew=typeof t.isNew==="boolean"?t.isNew:false;this.imageContainer=BX.create("div",{props:{className:"landing-ui-card-block-preview-image-container"}});this.body.appendChild(this.imageContainer);this.header.innerText=this.title;this.layout.dataset.code=this.code;this.requiresUpdates=t.requires_updates;if(this.isNew){this.title=BX.create("span",{props:{className:"landing-ui-new-inline"},text:BX.Landing.Loc.getMessage("LANDING_BLOCKS_LIST_PREVIEW_NEW")}).outerHTML+"&nbsp;"+this.title;this.header.innerHTML=this.title}if(this.repoId||this.favorite||this.appExpired){this.labels=BX.create("div",{props:{className:"landing-ui-card-labels"}});BX.insertAfter(this.labels,this.getHeader())}if(this.repoId||this.appExpired){var s=BX.create("div",{props:{className:"landing-ui-card-label landing-ui-card-label-repo"},text:BX.Landing.Loc.getMessage("LANDING_BLOCKS_LIST_PREVIEW_MARKET"),dataset:{hint:BX.Landing.Loc.getMessage("LANDING_BLOCKS_LIST_PREVIEW_MARKET_HINT"),hintNoIcon:"Y"}});BX.append(s,this.labels);BX.UI.Hint.init(this.labels)}if(this.favorite){if(this.favoriteMy){BX.append(BX.create("div",{props:{className:"landing-ui-card-label landing-ui-card-label-my"},text:BX.Landing.Loc.getMessage("LANDING_BLOCKS_LIST_PREVIEW_MY_NEW")}),this.labels)}BX.append(BX.create("div",{props:{className:"landing-ui-card-label landing-ui-card-label-favorite"},text:BX.Landing.Loc.getMessage("LANDING_BLOCKS_LIST_PREVIEW_FAVORITE")}),this.labels);var n=this.code.split("@").length===2?this.code.split("@")[1]:false;if(n&&this.favoriteMy){BX.Runtime.loadExtension("ui.dialogs.messagebox").then((()=>{const e=this.getRemoveButton();e.onclick=e=>{e.stopPropagation();BX.UI.Dialogs.MessageBox.show({message:BX.Landing.Loc.getMessage("LANDING_BLOCKS_LIST_PREVIEW_DELETE_MSG"),buttons:BX.UI.Dialogs.MessageBoxButtons.YES_CANCEL,onYes:()=>BX.Landing.Backend.getInstance().action("Landing::unFavoriteBlock",{blockId:n}).then((()=>{const e=BX.Landing.Main.getInstance();e.removeBlockFromList(this.code);return true})).catch((function(e){console.log("error",e);return false}))})};BX.append(e,this.getBody())}))}}if(this.appExpired){this.addWarning(BX.Landing.Loc.getMessage("LANDING_BLOCKS_LIST_PREVIEW_EXPIRED"));this.onClickHandler=function(){}}if(this.mode==="background"){this.imageContainer.style.backgroundImage="url("+this.imageSrc+")"}else{var r=this.imageSrc||"/bitrix/images/landing/empty-preview.png";this.image=BX.create("img",{props:{src:r},attrs:{style:"opacity: "+(this.imageSrc?1:.6)}});this.imageContainer.appendChild(this.image)}if(this.requiresUpdates){e(this.layout,"landing-ui-requires-update");var o=a("div",{props:{className:"landing-ui-requires-update-overlay"},children:[a("div",{props:{className:"landing-ui-requires-update-overlay-footer"},html:BX.Landing.Loc.getMessage("LANDING_BLOCK_REQUIRES_UPDATE_MESSAGE")})]});i(o,this.imageContainer);this.onClickHandler=function(){}}};BX.Landing.UI.Card.BlockPreviewCard.prototype={constructor:BX.Landing.UI.Card.BlockPreviewCard,__proto__:BX.Landing.UI.Card.BaseCard.prototype}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:59:"/bitrix/js/landing/ui/card/field_group.min.js?1708115048774";s:6:"source";s:41:"/bitrix/js/landing/ui/card/field_group.js";s:3:"min";s:45:"/bitrix/js/landing/ui/card/field_group.min.js";s:3:"map";s:45:"/bitrix/js/landing/ui/card/field_group.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Card");BX.Landing.UI.Card.FieldGroup=function(i){BX.Landing.UI.Card.BaseCard.apply(this,arguments);this.items=i.items;this.layout.classList.add("landing-ui-card-field-group");this.fields=new BX.Landing.Collection.BaseCollection;this.init()};BX.Landing.UI.Card.FieldGroup.createItem=function(){return BX.create("div",{props:{className:"landing-ui-card-field-group-item"}})};BX.Landing.UI.Card.FieldGroup.prototype={constructor:BX.Landing.UI.Card.FieldGroup,__proto__:BX.Landing.UI.Card.BaseCard.prototype,init:function(){this.items.forEach(function(i){var a=BX.Landing.UI.Card.FieldGroup.createItem();a.appendChild(i.layout);this.body.appendChild(a);this.fields.add(a)},this)}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:67:"/bitrix/js/landing/ui/card/image_preview_card.min.js?17081150481553";s:6:"source";s:48:"/bitrix/js/landing/ui/card/image_preview_card.js";s:3:"min";s:52:"/bitrix/js/landing/ui/card/image_preview_card.min.js";s:3:"map";s:52:"/bitrix/js/landing/ui/card/image_preview_card.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Card");BX.Landing.UI.Card.ImagePreview=function(i){BX.Landing.UI.Card.BaseCard.apply(this,arguments);this.title="title"in i?i.title:"";this.imageSrc=("image"in i?i.image:"").replace("http:","");this.code="code"in i?i.code:"";this.clickHandler="onClick"in i?i.onClick:"";this.credit="credit"in i?i.credit:null;this.dimensions="dimensions"in i?i.dimensions:{width:0,height:0};this.layout.classList.add("landing-ui-card-image-preview");this.imageContainer=BX.Landing.UI.Card.ImagePreview.createImageContainer();this.header.innerText=this.title;this.layout.dataset.code=this.code;if(this.credit){this.creditLayout=BX.create("div",{props:{className:"landing-ui-card-image-preview-credit"},children:[BX.create("a",{props:{className:"landing-ui-card-image-preview-credit-link"},attrs:{href:this.credit.link,target:"_blank",rel:"nofollow",title:BX.Landing.Loc.getMessage("LANDING_UNSPLASH_CREDIT_LABEL")+" "+this.credit.name},text:this.credit.name})]});this.layout.appendChild(this.creditLayout)}if(this.imageSrc){this.imageContainer.style.backgroundImage="url("+this.imageSrc+")";this.body.appendChild(this.imageContainer)}};BX.Landing.UI.Card.ImagePreview.createImageContainer=function(){return BX.create("div",{props:{className:"landing-ui-card-image-preview-container"}})};BX.Landing.UI.Card.ImagePreview.prototype={constructor:BX.Landing.UI.Card.ImagePreview,__proto__:BX.Landing.UI.Card.BaseCard.prototype,onClick:function(){this.clickHandler(this)}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:64:"/bitrix/js/landing/ui/card/add_your_first_block.js?1708115048770";s:6:"source";s:50:"/bitrix/js/landing/ui/card/add_your_first_block.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
;(function() {
	"use strict";

	BX.namespace("BX.Landing.UI.Card");


	BX.Landing.UI.Card.AddYourFirstBlock = function(data)
	{
		BX.Landing.UI.Card.BaseCard.apply(this, arguments);
		this.layout.classList.add("landing-ui-card-add-first-block");
		this.subheader = BX.create("div", {props: {className: "landing-ui-card-add-first-block-subheader"}});
		this.layout.insertBefore(this.subheader, this.body);
	};

	BX.Landing.UI.Card.AddYourFirstBlock.prototype = {
		constructor: BX.Landing.UI.Card.AddYourFirstBlock,
		__proto__: BX.Landing.UI.Card.BaseCard.prototype,

		/**
		 * @inheritDoc
		 */
		show: function()
		{
			BX.Landing.Utils.Show(this.layout);
		},


		/**
		 * @inheritDoc
		 */
		hide: function()
		{
			BX.Landing.Utils.Hide(this.layout);
		}
	};
})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:72:"/bitrix/js/landing/ui/card/base_image_library_card.min.js?17081150484171";s:6:"source";s:53:"/bitrix/js/landing/ui/card/base_image_library_card.js";s:3:"min";s:57:"/bitrix/js/landing/ui/card/base_image_library_card.min.js";s:3:"map";s:57:"/bitrix/js/landing/ui/card/base_image_library_card.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Card");var i=BX.Landing.Utils.addClass;var e=BX.Landing.Utils.removeClass;var t=BX.Landing.Utils.slice;var a=BX.Landing.Utils.Show;var r=BX.Landing.Utils.Hide;BX.Landing.UI.Card.Library=function(i){BX.Landing.UI.Card.BaseCard.apply(this,arguments);this.layout.classList.add("landing-ui-card-library");this.searchLabel=!!i.searchLabel?i.searchLabel:"";this.searchPlaceholder=!!i.searchPlaceholder?i.searchPlaceholder:"";this.serchTipsList=!!i.searchTips?i.searchTips:[];this.onChangeHandler=typeof i.onChange==="function"?i.onChange:function(){};this.search=BX.create("div",{props:{className:"landing-ui-card-library-search"}});this.searchField=this.createSearchField();this.searchTips=this.createSearchTips();if(i.description){this.description=BX.create("div",{props:{className:"landing-ui-card-library-description"},html:i.description});this.searchField.layout.insertBefore(this.description,this.searchField.input)}this.search.appendChild(this.searchField.layout);this.search.appendChild(this.searchTips.layout);this.body.appendChild(this.search);this.loader=new BX.Loader({target:this.body});this.imageList=BX.create("div",{props:{className:"landing-ui-card-library-list"}});this.body.appendChild(this.imageList);this.bottomLoader=new BX.Loader({target:this.body,mode:"inline",offset:{left:"calc(50% - 55px)"}});this.loadMore=BX.create("div",{props:{className:"landing-ui-card-library-load-more"}});this.loadMoreButton=this.createLoadMoreButton();this.loadMore.hidden=true;this.loadMore.dataset.isShown="false";this.loadMore.appendChild(this.loadMoreButton.layout);this.body.appendChild(this.loadMore)};BX.Landing.UI.Card.Library.prototype={constructor:BX.Landing.UI.Card.Library,__proto__:BX.Landing.UI.Card.BaseCard.prototype,onSearchInput:function(i){},onTipsChange:function(i){this.searchField.setValue(i)},onLoadMore:function(){},onChange:function(i){this.onChangeHandler(i)},renderItems:function(e){e.forEach((function(e){var t=new BX.Landing.UI.Card.ImagePreview(e);this.imageList.appendChild(t.layout);requestAnimationFrame((function(){i(t.layout,"landing-ui-show")}))}),this)},showEmptyResult:function(){if(!this.empty){this.empty=BX.create("div",{props:{className:"landing-ui-card-library-empty"},html:BX.Landing.Loc.getMessage("LANDING_IMAGES_PANEL_EMPTY_RESULT")});BX.insertAfter(this.empty,this.imageList)}return a(this.empty)},hideEmptyResult:function(){if(this.empty){return r(this.empty)}},showError:function(){if(!this.error){this.error=BX.create("div",{props:{className:"landing-ui-card-library-error"},html:BX.Landing.Loc.getMessage("LANDING_IMAGES_PANEL_ERROR")||"Error"});BX.insertAfter(this.error,this.imageList)}this.hideEmptyResult();this.hideLoadMore();this.hideBottomLoader();this.hideLoadMore();this.hideLoader();this.clearItems();return a(this.error)},hideError:function(){if(this.error){return r(this.error)}},clearItems:function(){this.imageList.innerHTML=""},createLoadMoreButton:function(){return new BX.Landing.UI.Button.BaseButton("load_more",{text:BX.Landing.Loc.getMessage("LANDING_IMAGE_LIBRARY_LOAD_MORE"),className:"landing-ui-card-library-load-more-button",onClick:this.onLoadMore.bind(this)})},createSearchTips:function(){return new BX.Landing.UI.Field.ButtonGroup({items:this.serchTipsList,className:"landing-ui-card-library-search-tips",onChange:this.onTipsChange.bind(this)})},createSearchField:function(){var i=new BX.Landing.UI.Field.Unit({onInput:this.onSearchInput.bind(this),className:"landing-ui-card-library-search-field",placeholder:BX.Landing.Loc.getMessage("SEARCH_FIELD_PLACEHOLDER"),title:this.searchLabel,skipPasteControl:true});i.input.type="text";i.input.min=null;i.input.max=null;i.enableTextOnly();return i},showLoader:function(){t(this.imageList.children).forEach((function(i){e(i,"landing-ui-show")}));this.loader.show()},hideLoader:function(){this.loader.hide()},showBottomLoader:function(){this.bottomLoader.show()},hideBottomLoader:function(){this.bottomLoader.hide()},showLoadMore:function(){BX.Landing.Utils.Show(this.loadMore)},hideLoadMore:function(){BX.Landing.Utils.Hide(this.loadMore)}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:62:"/bitrix/js/landing/ui/card/unsplash_card.min.js?17081150482529";s:6:"source";s:43:"/bitrix/js/landing/ui/card/unsplash_card.js";s:3:"min";s:47:"/bitrix/js/landing/ui/card/unsplash_card.min.js";s:3:"map";s:47:"/bitrix/js/landing/ui/card/unsplash_card.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Card");var t=BX.Landing.Utils.getFileExtension;function e(t){return BX.util.add_url_param(t,{utm_source:"bitrix",utm_medium:"referral",utm_campaign:"api-credit"})}function i(t,i){return{image:t.urls.small,credit:{name:t.user.name,link:e(t.user.links.html)},dimensions:{width:t.width,height:t.height},onClick:i.onPictureChange.bind(i,t)}}function n(t,e){return t.map(function(t){return i(t,e)})}BX.Landing.UI.Card.Unsplash=function(t){BX.Landing.UI.Card.Library.apply(this,arguments);this.state="popular";this.page=1;this.query="";this.onSearchWithDebounce=BX.debounce(this.onSearchWithDebounce,1e3,this);this.showPopular()};BX.Landing.UI.Card.Unsplash.prototype={constructor:BX.Landing.UI.Card.Unsplash,__proto__:BX.Landing.UI.Card.Library.prototype,onLoadMore:function(){if(this.state==="popular"){this.appendPopular()}if(this.state==="search"){this.appendSearch()}},appendSearch:function(){this.state="search";this.page+=1;this.showBottomLoader();this.hideLoadMore();var t=BX.Landing.Client.Unsplash.getInstance();t.search(this.query,this.page).then(function(t){this.hideBottomLoader();this.showLoadMore();this.renderItems(n(t,this))}.bind(this))},appendPopular:function(){this.state="popular";this.page+=1;this.query="";var t=BX.Landing.Client.Unsplash.getInstance();var e=this;this.showBottomLoader();this.hideLoadMore();t.popular(this.page).then(function(t){e.hideBottomLoader();e.showLoadMore();e.renderItems(n(t,e))})},onSearchInput:function(t){var e=t.getValue();if(!!e&&e.length){this.state="search";this.query=e;this.page=1;this.showLoader();this.onSearchWithDebounce(e);this.hideEmptyResult();return}if(this.state!=="popular"){this.showPopular()}},onSearchWithDebounce:function(t){var e=BX.Landing.Client.Unsplash.getInstance();e.search(t).then(function(t){this.hideLoader();this.clearItems();if(t.length===0){this.hideLoadMore();this.showEmptyResult();return}this.renderItems(n(t,this))}.bind(this))},showPopular:function(){this.state="popular";this.page=1;this.query="";var t=BX.Landing.Client.Unsplash.getInstance();this.showLoader();this.hideEmptyResult();t.popular().then(function(t){this.hideLoader();this.clearItems();if(t.length===0){this.hideLoadMore();this.showEmptyResult();return}this.showLoadMore();this.renderItems(n(t,this))}.bind(this))},onPictureChange:function(e){BX.Landing.Client.Unsplash.getInstance().download(e).then(function(i){this.onChange({link:i,ext:t(i),name:e.id+"."+t(i)})}.bind(this))}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:67:"/bitrix/js/landing/ui/card/google_images_card.min.js?17081150483828";s:6:"source";s:48:"/bitrix/js/landing/ui/card/google_images_card.js";s:3:"min";s:52:"/bitrix/js/landing/ui/card/google_images_card.min.js";s:3:"map";s:52:"/bitrix/js/landing/ui/card/google_images_card.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Card");var t=BX.Landing.Utils.create;var i=BX.Landing.Utils.append;var e=BX.Landing.Utils.prepend;var n=BX.Landing.Utils.remove;var t=BX.Landing.Utils.create;function s(t,i){return{image:t.link,credit:{},dimensions:{width:t.image.width,height:t.image.height},onClick:i.onPictureChange.bind(i,t.link)}}function r(t,i){return t.map(function(t){return s(t,i)})}BX.Landing.UI.Card.Google=function(t){BX.Landing.UI.Card.Library.apply(this,arguments);this.page=1;this.query="";this.loader=new BX.Loader({target:this.body,offset:{top:"12%"}});this.client=BX.Landing.Client.Google.getInstance();this.onSearchWithDebounce=BX.debounce(this.onSearchWithDebounce,1e3,this);this.showPopular()};BX.Landing.UI.Card.Google.prototype={constructor:BX.Landing.UI.Card.Google,__proto__:BX.Landing.UI.Card.Library.prototype,onLoadMore:function(){this.appendSearch()},appendSearch:function(){this.page+=1;this.state="search";this.showBottomLoader();this.hideLoadMore();this.hideError();this.client.search(this.query,this.page).then(function(t){this.hideBottomLoader();this.showLoadMore();this.renderItems(r(t,this))}.bind(this)).catch(this.showError.bind(this))},showPopular:function(){this.hideError();this.showLoader();this.query="Nature";this.state="popular";this.onSearchWithDebounce("Nature");if(BX.Landing.Client.Google.allowKeyChange){this.showSettingsButton()}else{this.hideSettingsButton()}},showSettingsButton:function(){if(!this.settingsButton){this.settingsButton=BX.create("a",{props:{className:"ui-btn ui-btn-xs ui-btn-light-border ui-btn-icon-setting landing-google-settings-button"},html:BX.Landing.Loc.getMessage("LANDING_GOOGLE_IMAGES_CHANGE_KEY_BUTTON"),events:{click:this.onSettingsClick.bind(this)}});this.body.appendChild(this.settingsButton)}this.settingsButton.hidden=false},hideSettingsButton:function(){if(this.settingsButton){this.settingsButton.hidden=true}},onSettingsClick:function(t){t.preventDefault();if(BX.Landing.Client.Google.allowKeyChange){BX.Landing.UI.Panel.GoogleImagesSettings.getInstance().show().then(function(){this.showPopular();this.searchField.input.innerHTML=""}.bind(this))}},onSearchInput:function(t){this.hideError();var i=t.getValue();if(!!i&&i.length){this.query=i;this.page=1;this.state="search";this.showLoader();this.onSearchWithDebounce(i);return}if(this.state!=="popular"){this.showPopular()}},onSearchWithDebounce:function(t){this.hideError();this.client.search(t).then(function(t){this.hideLoader();this.clearItems();this.hideEmptyResult();if(t.length===0){this.showEmptyResult();this.hideLoadMore();return}this.renderItems(r(t,this));this.showLoadMore();if(BX.Landing.Client.Google.allowKeyChange){this.showSettingsButton()}else{this.hideSettingsButton()}}.bind(this)).catch(this.showError.bind(this))},onPictureChange:function(t){var i=BX.util.add_url_param("/bitrix/tools/landing/proxy.php",{sessid:BX.bitrix_sessid(),url:t});this.onChange({link:i,ext:BX.util.getExtension(t),name:BX.Landing.Utils.getFileName(t)})},createKeyError:function(){return t("div",{props:{className:"ui-alert ui-alert-warning"},children:[t("span",{props:{className:"ui-alert-message"},html:BX.Landing.Loc.getMessage("LANDING_IMAGES_PANEL_KEY_ERROR")})]})},createError:function(){return t("div",{props:{className:"ui-alert ui-alert-danger"},children:[t("span",{props:{className:"ui-alert-message"},html:BX.Landing.Loc.getMessage("LANDING_IMAGES_PANEL_GOOGLE_ERROR")})]})},hideError:function(){BX.Landing.UI.Card.Library.prototype.hideError.call(this);if(this.error){n(this.error)}},showError:function(){if(!BX.Landing.Client.Google.key){this.error=this.createKeyError()}else{this.error=this.createError()}BX.insertAfter(this.error,this.imageList);BX.Landing.UI.Card.Library.prototype.showError.call(this)}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:57:"/bitrix/js/landing/ui/card/uploader_card.js?1708115048800";s:6:"source";s:43:"/bitrix/js/landing/ui/card/uploader_card.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
;(function() {
	"use strict";

	BX.namespace("BX.Landing.UI.Card");


	/**
	 * Implements interface for works with uploader
	 *
	 * @extends {BX.Landing.UI.Card.Library}
	 *
	 * @param {object} data
	 *
	 * @constructor
	 */
	BX.Landing.UI.Card.Uploader = function(data)
	{
		BX.Landing.UI.Card.Library.apply(this, arguments);
		this.layout.classList.add("landing-ui-card-library-uploader");
		this.iframe = BX.create("iframe", {props: {className: "landing-ui-card-library-uploader-iframe"}});
		this.iframe.src = "/bitrix/tools/landing/uploader.php";
		this.imageList.appendChild(this.iframe);
		BX.remove(this.search);
		BX.remove(this.loadMore);
	};

	BX.Landing.UI.Card.Uploader.prototype = {
		constructor: BX.Landing.UI.Card.Uploader,
		__proto__: BX.Landing.UI.Card.Library.prototype
	};
})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:54:"/bitrix/js/landing/ui/card/loader.min.js?1708115048617";s:6:"source";s:36:"/bitrix/js/landing/ui/card/loader.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Card");BX.Landing.UI.Card.Loader=function(){BX.Landing.UI.Card.BaseCard.apply(this,arguments);this.layout.classList.add("landing-ui-loader");this.inner=BX.create("div",{props:{className:"landing-ui-loader-inner"},html:'<svg class="main-grid-loader-circular" viewBox="25 25 50 50">\n'+'    <circle class="main-grid-loader-path" cx="50" cy="50" r="20" fill="none" stroke-miterlimit="10"/>\n'+"</svg>"});this.body.appendChild(this.inner)};BX.Landing.UI.Card.Loader.prototype={constructor:BX.Landing.UI.Card.Loader,__proto__:BX.Landing.UI.Card.BaseCard.prototype}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:53:"/bitrix/js/landing/ui/card/link_card.js?1708115048771";s:6:"source";s:39:"/bitrix/js/landing/ui/card/link_card.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
;(function() {
	"use strict";

	BX.namespace("BX.Landing.UI.Card");


	/**
	 * @extends {BX.Landing.UI.Card.BaseCard}
	 * @param {object} data
	 * @constructor
	 */
	BX.Landing.UI.Card.Link = function(data)
	{
		BX.Landing.UI.Card.BaseCard.apply(this, arguments);
		this.layout.classList.add("landing-ui-card-link");

		if (!!data && typeof data === "object" && "child" in data && data.child)
		{
			this.layout.classList.add("landing-ui-card-link-child");
		}

		this.body.appendChild((new BX.Landing.UI.Button.BaseButton(data.button.id.toString(), {
			text: data.button.text,
			onClick: data.button.onChange
		})).layout);
	};

	BX.Landing.UI.Card.Link.prototype = {
		constructor: BX.Landing.UI.Card.Link,
		__proto__: BX.Landing.UI.Card.BaseCard.prototype
	};
})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:63:"/bitrix/js/landing/ui/card/landing_preview.min.js?1708115048805";s:6:"source";s:45:"/bitrix/js/landing/ui/card/landing_preview.js";s:3:"min";s:49:"/bitrix/js/landing/ui/card/landing_preview.min.js";s:3:"map";s:49:"/bitrix/js/landing/ui/card/landing_preview.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Card");BX.Landing.UI.Card.LandingPreviewCard=function(i){BX.Landing.UI.Card.BaseCard.apply(this,arguments);this.layout.classList.add("landing-ui-card-landing-preview");this.onClickHandler=typeof i.onClick==="function"?i.onClick:function(){};if(!!i.preview&&typeof i.preview==="string"){this.body.style.backgroundImage="url("+i.preview+")"}else{this.body.hidden=true}if(!!i.description&&typeof i.description==="string"){this.footer=BX.create("div",{props:{className:"landing-ui-card-footer"},text:i.description})}};BX.Landing.UI.Card.LandingPreviewCard.prototype={constructor:BX.Landing.UI.Card.LandingPreviewCard,__proto__:BX.Landing.UI.Card.BaseCard.prototype,onClick:function(){this.onClickHandler()}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:62:"/bitrix/js/landing/ui/card/block_html_preview.js?1708115048990";s:6:"source";s:48:"/bitrix/js/landing/ui/card/block_html_preview.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
;(function() {
	"use strict";

	BX.namespace("BX.Landing.UI.Card");


	/**
	 * Implements interface of block html preview
	 * @extends {BX.Landing.UI.Card.BaseCard}
	 * @param {object} data
	 * @constructor
	 */
	BX.Landing.UI.Card.BlockHTMLPreview = function(data)
	{
		BX.Landing.UI.Card.BaseCard.apply(this, arguments);
		this.layout.classList.add("landing-ui-card-block-html-preview");
		this.onClickHandler = typeof data.onClick === "function" ? data.onClick : (function() {});
		this.block = BX.clone(document.querySelector("#block"+data.content+".block-wrapper"));

		[].slice.call(this.block.querySelectorAll(".landing-ui-panel")).forEach(BX.remove);

		this.body.appendChild(this.block);
		this.layout.addEventListener("click", this.onClick.bind(this));
	};


	BX.Landing.UI.Card.BlockHTMLPreview.prototype = {
		constructor: BX.Landing.UI.Card.BlockHTMLPreview,
		__proto__: BX.Landing.UI.Card.BaseCard.prototype,

		onClick: function()
		{
			this.onClickHandler();
		}
	};
})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:57:"/bitrix/js/landing/ui/card/tab_card.min.js?17081150482439";s:6:"source";s:38:"/bitrix/js/landing/ui/card/tab_card.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Card");var a=BX.Landing.Utils.addClass;var i=BX.Landing.Utils.removeClass;var t=BX.Landing.Utils.hasClass;var n=BX.Landing.Utils.append;var e=BX.Landing.Utils.create;var r=BX.Landing.Utils.data;var s=BX.Landing.Utils.slice;var d=BX.Landing.Utils.Show;var c=BX.Landing.Utils.Hide;var h=BX.Landing.Collection.BaseCollection;BX.Landing.UI.Card.TabCard=function(i){BX.Landing.UI.Card.BaseCard.apply(this,arguments);a(this.layout,"landing-ui-card-tabs");this.fields=new h;this.tabs=[];this.headersArea=e("div",{props:{className:"landing-ui-card-tabs-headers"}});this.tabsArea=e("div",{props:{className:"landing-ui-card-tabs-tabs"}});n(this.headersArea,this.layout);n(this.tabsArea,this.layout);i.tabs.forEach(this.addTab,this);this.render();var t=i.tabs.find(function(a){return a.active===true});if(!t){t=i.tabs[0]}this.activateTab(t.id)};BX.Landing.UI.Card.TabCard.prototype={constructor:BX.Landing.UI.Card.TabCard,__proto__:BX.Landing.UI.Card.BaseCard.prototype,addTab:function(a){this.tabs.push({id:a.id,name:a.name,fields:a.fields.map(function(a){return a.layout})});a.fields.forEach(function(a){this.fields.push(a)},this)},render:function(){this.headersArea.innerHTML="";this.tabsArea.innerHTML="";this.tabs.forEach(function(a,i){n(this.createHeader({id:a.id,name:a.name}),this.headersArea);n(this.createTab({id:a.id,fields:a.fields}),this.tabsArea)},this)},createHeader:function(a){return e("div",{props:{className:"landing-ui-card-tabs-headers-item"},text:a.name,attrs:{"data-id":a.id},events:{click:this.onHeaderClick.bind(this)}})},onHeaderClick:function(a){a.preventDefault();if(!this.isActive(a.currentTarget)){this.activateTab(r(a.currentTarget,"data-id"))}},isActive:function(a){return t(a,"landing-ui-active")},activateTab:function(t){s(this.headersArea.children).forEach(function(a){i(a,"landing-ui-active")});s(this.tabsArea.children).forEach(function(a){i(a,"landing-ui-active");c(a)});var n=this.getHeader(t);var e=this.getTab(t);if(n){a(n,"landing-ui-active")}if(e){d(e).then(function(){a(e,"landing-ui-active")})}},createTab:function(a){return e("div",{props:{className:"landing-ui-card-tabs-tabs-item landing-ui-hide"},children:a.fields,attrs:{"data-id":a.id}})},getHeader:function(a){return s(this.headersArea.children).find(function(i){return r(i,"data-id")===a})},getTab:function(a){return s(this.tabsArea.children).find(function(i){return r(i,"data-id")===a})}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:68:"/bitrix/js/landing/ui/card/dynamic_fields_group.min.js?1708115048633";s:6:"source";s:50:"/bitrix/js/landing/ui/card/dynamic_fields_group.js";s:3:"min";s:54:"/bitrix/js/landing/ui/card/dynamic_fields_group.min.js";s:3:"map";s:54:"/bitrix/js/landing/ui/card/dynamic_fields_group.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Card");BX.Landing.UI.Card.DynamicFieldsGroup=function(a){BX.Landing.UI.Card.BaseCard.apply(this,arguments);this.layout.classList.add("landing-ui-card-dynamic-fields-group");this.fields=new BX.Landing.Collection.BaseCollection;a.items.forEach(function(a){var i=BX.Landing.UI.Card.FieldGroup.createItem();i.appendChild(a.layout);this.body.appendChild(i);this.fields.add(a)},this)};BX.Landing.UI.Card.DynamicFieldsGroup.prototype={constructor:BX.Landing.UI.Card.DynamicFieldsGroup,__proto__:BX.Landing.UI.Card.BaseCard.prototype}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:62:"/bitrix/js/landing/ui/card/add_page_card.min.js?17081150482627";s:6:"source";s:43:"/bitrix/js/landing/ui/card/add_page_card.js";s:3:"min";s:47:"/bitrix/js/landing/ui/card/add_page_card.min.js";s:3:"map";s:47:"/bitrix/js/landing/ui/card/add_page_card.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Card");BX.Landing.UI.Card.AddPageCard=function(e){BX.Landing.UI.Card.BaseCard.apply(this,arguments);this.layout.classList.add("landing-ui-card-add-page");this.cache=new BX.Cache.MemoryCache;this.onSaveHandler=e.onSave||function(){};this.siteId=e.siteId;var t=BX.create("span",{props:{className:"landing-ui-card-add-page-icon"}});var a=BX.create("span",{props:{className:"landing-ui-card-add-page-text"},text:BX.Landing.Loc.getMessage("LANDING_LINK_PLACEHOLDER_NEW_PAGE")});var n=BX.create("div",{props:{className:"landing-ui-card-add-page-inner"},children:[t,a]});this.body.appendChild(n);BX.bind(this.layout,"click",this.onLayoutClick.bind(this))};BX.Landing.UI.Card.AddPageCard.prototype={constructor:BX.Landing.UI.Card.AddPageCard,__proto__:BX.Landing.UI.Card.BaseCard.prototype,onLayoutClick:function(e){e.preventDefault();BX.replace(this.layout,this.getFormLayout());var t=this.getTitleField();t.setValue("");setTimeout(function(){t.enableEdit();t.input.focus()})},getFormLayout:function(){return this.cache.remember("formLayout",function(){var e=BX.create("span",{props:{className:"ui-btn ui-btn-primary ui-btn-sm"},text:BX.Landing.Loc.getMessage("LANDING_LINK_NEW_PAGE_SAVE_BUTTON_LABEL"),events:{click:this.onSaveClick.bind(this)}});var t=BX.create("span",{props:{className:"ui-btn ui-btn-link ui-btn-sm"},text:BX.Landing.Loc.getMessage("LANDING_LINK_NEW_PAGE_CANCEL_BUTTON_LABEL"),events:{click:this.onCancelClick.bind(this)}});var a=BX.create("div",{props:{className:"landing-ui-card-add-page-form-buttons"},children:[e,t]});return BX.create("div",{props:{className:"landing-ui-card-add-page-form"},children:[this.getForm().layout,a]})}.bind(this))},onSaveClick:function(e){e.preventDefault();var t=BX.Landing.Backend.getInstance();var a=this.getTitleField().getValue();var n=BX.translit(a,{change_case:"L",replace_space:"-",replace_other:""});void t.createPage({title:a,code:n,siteId:this.siteId}).then(function(e){this.onSaveHandler(e);BX.replace(this.getFormLayout(),this.layout)}.bind(this))},onCancelClick:function(e){e.preventDefault();BX.replace(this.getFormLayout(),this.layout)},getTitleField:function(){return this.cache.remember("titleField",function(){return new BX.Landing.UI.Field.Text({title:BX.Landing.Loc.getMessage("LANDING_CREATE_PAGE_PANEL_FIELD_PAGE_TITLE"),textOnly:true})})},getForm:function(){return this.cache.remember("form",function(){return new BX.Landing.UI.Form.BaseForm({title:BX.Landing.Loc.getMessage("LANDING_LINK_PLACEHOLDER_NEW_PAGE"),fields:[this.getTitleField()]})}.bind(this))}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:61:"/bitrix/js/landing/ui/tool/color_picker.min.js?17081150493735";s:6:"source";s:42:"/bitrix/js/landing/ui/tool/color_picker.js";s:3:"min";s:46:"/bitrix/js/landing/ui/tool/color_picker.min.js";s:3:"map";s:46:"/bitrix/js/landing/ui/tool/color_picker.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Tool");BX.Landing.UI.Tool.ColorPicker=function(e,t){this.picker=new BX.ColorPicker({bindElement:e.layout,popupOptions:BX.Landing.UI.Tool.ColorPicker.getDefaultPopupOptions(e),onColorSelected:BX.delegate(this.onColorSelected,this),colors:BX.Landing.UI.Tool.ColorPicker.getDefaultColors()});this.button=e;this.onChangeHandler=t;this.pickerWindow=this.picker.getPopupWindow();this.contextDocument=document;this.range=this.contextDocument.createRange();BX.Landing.UI.Tool.ColorPicker.activePickers.add(this)};BX.Landing.UI.Tool.ColorPicker.getDefaultPopupOptions=function(e){return{angle:false,position:{top:0,left:0},zIndex:-678,overlay:{backgroundColor:"#ffffff",opacity:10}}};BX.Landing.UI.Tool.ColorPicker.activePickers=new BX.Landing.Collection.BaseCollection;BX.Landing.UI.Tool.ColorPicker.hideAll=function(){BX.Landing.UI.Tool.ColorPicker.activePickers.forEach((function(e){e.hide()}))};BX.Landing.UI.Tool.ColorPicker.getDefaultColors=function(){return[["#f5f5f5","#eeeeee","#e0e0e0","#9e9e9e","#757575","#616161","#212121"],["#cfd8dc","#b0bec5","#90a4ae","#607d8b","#546e7a","#455a64","#263238"],["#d7ccc8","#bcaaa4","#a1887f","#795548","#6d4c41","#5d4037","#3e2723"],["#ffccbc","#ffab91","#ff8a65","#ff5722","#f4511e","#e64a19","#bf360c"],["#ffe0b2","#ffcc80","#ffb74d","#ff9800","#fb8c00","#f57c00","#e65100"],["#ffecb3","#ffe082","#ffd54f","#ffc107","#ffb300","#ffa000","#ff6f00"],["#fff9c4","#fff59d","#fff176","#ffeb3b","#fdd835","#fbc02d","#f57f17"],["#f0f4c3","#e6ee9c","#dce775","#cddc39","#c0ca33","#afb42b","#827717"],["#dcedc8","#c5e1a5","#aed581","#8bc34a","#7cb342","#689f38","#33691e"],["#c8e6c9","#a5d6a7","#81c784","#4caf50","#43a047","#388e3c","#1b5e20"],["#b2dfdb","#80cbc4","#4db6ac","#009688","#00897b","#00796b","#004d40"],["#b2ebf2","#80deea","#4dd0e1","#00bcd4","#00acc1","#0097a7","#006064"],["#b3e5fc","#81d4fa","#4fc3f7","#03a9f4","#039be5","#0288d1","#01579b"],["#bbdefb","#90caf9","#64b5f6","#2196f3","#1e88e5","#1976d2","#0d47a1"],["#c5cae9","#9fa8da","#7986cb","#3f51b5","#3949ab","#303f9f","#1a237e"],["#d1c4e9","#b39ddb","#9575cd","#673ab7","#5e35b1","#512da8","#311b92"],["#e1bee7","#ce93d8","#ba68c8","#9c27b0","#8e24aa","#7b1fa2","#4a148c"],["#f8bbd0","#f48fb1","#f06292","#e91e63","#d81b60","#c2185b","#880e4f"],["#ffcdd2","#ef9a9a","#e57373","#f44336","#e53935","#d32f2f","#b71c1c"]].map((function(e,t,o){return o.map((function(e){return e[t]}))}))};BX.Landing.UI.Tool.ColorPicker.prototype={adjustPosition:function(e){BX.DOM.read(function(){var t=this.pickerWindow.popupContainer.getBoundingClientRect();var o=this.button.layout.parentNode.getBoundingClientRect();var n=Math.abs(t.width-o.width);var i={};i["left"]=o.left+n/2+"px";i["position"]="fixed";if(e==="fixed"){var c=this.button.layout.getBoundingClientRect();i["top"]=c.bottom+"px"}else{var f=BX.pos(this.button.layout);i["top"]=f.bottom+"px"}if(BX.Landing.Main.getInstance().isControlsExternal()){i["left"]="3px";i["height"]="210px"}BX.DOM.write(function(){for(var e in i){this.pickerWindow.popupContainer.style[e]=i[e]}}.bind(this))}.bind(this))},show:function(e){this.picker.open();this.adjustPosition(e);this.range=this.contextDocument.getSelection().getRangeAt(0)},hide:function(){this.picker.close()},isShown:function(){return this.pickerWindow.isShown()},onColorSelected:function(e,t){this.contextDocument.getSelection().removeAllRanges();this.contextDocument.getSelection().addRange(this.range);if(BX.type.isFunction(this.onChangeHandler)){this.onChangeHandler(e,t)}},setContextDocument:function(e){if(e.nodeType===Node.DOCUMENT_NODE){this.contextDocument=e;if(!this.isShown()){this.range=this.contextDocument.createRange()}}}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:64:"/bitrix/js/landing/ui/tool/auto-font-scale.min.js?17081150491240";s:6:"source";s:45:"/bitrix/js/landing/ui/tool/auto-font-scale.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Tool");var t=BX.Landing.Utils.bind;var n=BX.Landing.Utils.slice;var i=BX.Landing.Utils.onCustomEvent;var e=BX.width(window);function o(){return BX.width(window)<1100}function s(){var t=e!==BX.width(window);e=BX.width(window);return t}BX.Landing.UI.Tool.autoFontScale=function(n){this.entries=n.map(this.createEntry,this);t(window,"resize",this.onResize.bind(this,false));t(window,"orientationchange",this.onResize.bind(this,true));i("BX.Landing.Block:init",this.onAddBlock.bind(this));this.adjust(true)};BX.Landing.UI.Tool.autoFontScale.prototype={onResize:function(t){this.adjust(t);clearTimeout(this.falbackTimeoutId);this.falbackTimeoutId=setTimeout(function(){this.adjust(true)}.bind(this),250)},adjust:function(t){if(t===true||s()){var n=o();this.entries.forEach(function(t){if(n){t.adjust()}else{t.resetSize()}})}},createEntry:function(t){return new BX.Landing.UI.Tool.autoFontScaleEntry(t)},addElements:function(t){t.forEach(function(t){var n=this.entries.some(function(n){return n.element===t});if(!n){this.entries.push(this.createEntry(t))}},this)},onAddBlock:function(t){var i=n(t.block.querySelectorAll("h1, h2, h3, h4, h5, [data-auto-font-scale]"));this.addElements(i)}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:70:"/bitrix/js/landing/ui/tool/auto-font-scale-entry.min.js?17081150492175";s:6:"source";s:51:"/bitrix/js/landing/ui/tool/auto-font-scale-entry.js";s:3:"min";s:55:"/bitrix/js/landing/ui/tool/auto-font-scale-entry.min.js";s:3:"map";s:55:"/bitrix/js/landing/ui/tool/auto-font-scale-entry.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Tool");var t=BX.Landing.Utils.createRangeFromNode;var e=BX.Landing.Utils.isNumber;var i=BX.Landing.Utils.rect;BX.Landing.UI.Tool.autoFontScaleEntry=function(t){this.element=t;this.minSize=8;this.maxSize=parseInt(BX.style(t,"font-size"));this.maxLetterSpacing=parseFloat(BX.style(t,"letter-spacing"));this.maxLetterSpacing=e(this.maxLetterSpacing)?this.maxLetterSpacing:0;this.minLetterSpacing=0;this.paddings=30;this.changed=false};BX.Landing.UI.Tool.autoFontScaleEntry.prototype={setFontSize:function(t){t=Math.min(Math.max(t,this.minSize),this.maxSize);this.element.style.setProperty("font-size",t+"px","important")},setLetterSpacing:function(t){t=Math.min(Math.max(t,this.minLetterSpacing),this.maxLetterSpacing);this.element.style.setProperty("letterSpacing",t+"px")},resetSize:function(){this.element.style.setProperty("fontSize",null);this.element.style.setProperty("letterSpacing",null);this.element.style.setProperty("display",null)},adjust:function(){if(this.changed||this.getRangeWidth()>this.getParentWidth()){this.changed=true;var t=this.getParentWidth()*this.getFontSizeRatio();var e=this.getParentWidth()*this.getLetterSpacingRatio();this.setFontSize(t-e);this.setLetterSpacing(e)}if(!this.changed&&this.maxSize>40&&BX.width(window)<=600){this.setFontSize(this.getParentWidth()*this.getBaseFontSizeRatio())}},getCurrentSize:function(){return parseInt(BX.style(this.element,"font-size"))},getFontSizeRatio:function(){if(e(this.ratio)){return this.ratio}this.ratio=this.maxSize/this.getRangeWidth();return this.ratio},getLetterSpacingRatio:function(){if(e(this.letterSpacingRatio)){return this.letterSpacingRatio}this.letterSpacingRatio=this.maxLetterSpacing/this.getRangeWidth();return this.letterSpacingRatio},getBaseFontSizeRatio:function(){if(e(this.baseFontSizeRatio)){return this.baseFontSizeRatio}this.baseFontSizeRatio=this.getCurrentSize()/(600-this.paddings);return this.baseFontSizeRatio},getRangeWidth:function(){return i(t(this.element)).width},getParentWidth:function(){return Math.min(i(this.element).width,BX.width(window)-this.paddings)}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:57:"/bitrix/js/landing/ui/tool/suggests.min.js?17081150491716";s:6:"source";s:38:"/bitrix/js/landing/ui/tool/suggests.js";s:3:"min";s:42:"/bitrix/js/landing/ui/tool/suggests.min.js";s:3:"map";s:42:"/bitrix/js/landing/ui/tool/suggests.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Tool");var t=BX.Landing.Utils.isEmpty;var n=BX.Landing.Utils.isNumber;var i=BX.Landing.Utils.bind;var e=BX.Landing.Utils.unbind;var s=BX.Landing.Utils.proxy;var o=BX.Landing.Utils.create;BX.Landing.UI.Tool.Suggest=function(){this.lastElement=null;this.popup=null;this.popupTimeout=0;i(document,"mousedown",s(this.hide,this))};BX.Landing.UI.Tool.Suggest.instance=null;BX.Landing.UI.Tool.Suggest.getInstance=function(){return BX.Landing.UI.Tool.Suggest.instance||(BX.Landing.UI.Tool.Suggest.instance=new BX.Landing.UI.Tool.Suggest)};BX.Landing.UI.Tool.Suggest.prototype={createContent:function(n){var i=[];if(!t(n.name)){i.push(o("div",{props:{className:"landing-ui-field-link-media-help-popup-content-title"},html:n.name||n.title}))}if(!t(n.description)){i.push(o("div",{props:{className:"landing-ui-field-link-media-help-popup-content-content"},html:n.description}))}return o("div",{props:{className:"landing-ui-field-link-media-help-popup-content"},children:i})},show:function(t,e){if(this.popup===null){this.popup=new BX.Main.Popup({id:"landing_suggests_popup",autoHide:false,offsetLeft:-20,offsetTop:11,angle:{offset:74}})}if(!n(e.angleOffset)){e.angleOffset=74}this.popup.setBindElement(t);this.popup.setContent(this.createContent(e));this.lastElement=t;this.popupTimeout=o.apply(this);function o(){return setTimeout(function(){i(t,"mouseleave",s(this.hide,this));this.popup.show();this.popup.setAngle({offset:e.angleOffset,position:"top"})}.bind(this),200)}},hide:function(){if(this.popup&&this.popup.isShown()){e(this.lastElement,"mouseleave",s(this.hide,this));clearTimeout(this.popupTimeout);this.popup.close()}}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:61:"/bitrix/js/landing/ui/tool/font-manager.min.js?17081150492719";s:6:"source";s:42:"/bitrix/js/landing/ui/tool/font-manager.js";s:3:"min";s:46:"/bitrix/js/landing/ui/tool/font-manager.min.js";s:3:"map";s:46:"/bitrix/js/landing/ui/tool/font-manager.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Tool");var n=BX.Landing.Utils.slice;var t=BX.Landing.Utils.arrayUnique;var e=BX.Landing.Utils.data;var a=BX.Landing.Utils.isString;var o=BX.Landing.Utils.create;var r=BX.Landing.Utils.append;var i=BX.Landing.Utils.remove;BX.Landing.UI.Tool.FontManager=function(){};BX.Landing.UI.Tool.FontManager.getInstance=function(){return BX.Landing.UI.Tool.FontManager.instance||(BX.Landing.UI.Tool.FontManager.instance=new BX.Landing.UI.Tool.FontManager)};function s(n){return"g-font-"+n.toLowerCase().trim().replace(/ /g,"-")}function d(n,t){n=n.replaceAll("+"," ");var e={serif:'"#font#", serif',"sans-serif":'"#font#", sans-serif',display:'"#font#", cursive',handwriting:'"#font#", cursive',monospace:'"#font#", monospace'};return e[t]?e[t].replace("#font#",n):'"'+n+'"'}BX.Landing.UI.Tool.FontManager.prototype={getLoadedFonts:function(){var t=n(document.head.querySelectorAll('[data-font*="g-font-"]'));return t.map((function(n){return{className:e(n,"data-font"),element:n,CSSDeclaration:document.head.querySelector('[data-id*="'+e(n,"data-font")+'"]'),protected:e(n,"data-protected")||false}}))},getUsedLoadedFonts:function(){var n=[];var t=this.getLoadedFonts().filter((function(n){return!n.protected}));if(t.length){var e=this.getAllUsedFonts();t.forEach((function(t){var a=e.some((function(n){return t.className===n}));if(a){n.push(t)}}))}return n},getAllUsedFonts:function(e){e=e||document.body;var o=n(e.querySelectorAll("*:not(img)"));var r=[];o.forEach((function(n){var t=BX.style(n,"font-family");if(a(t)){t=t.replace(/['|"]/g,"");r.push(s(t.split(",")[0]))}}));return t(r)},isLoaded:function(n){return this.getLoadedFonts().some((function(t){return t.className===n}))},addFont:function(n,t){var e=!!t?t.document:document;return new Promise(function(t){if(!this.isLoaded(n.className)){let s=n.href;if(window.fontsProxyUrl){const n=new URL(s);n.host=window.fontsProxyUrl;s=n.href}var a=o("link",{attrs:{rel:"stylesheet",href:s,"data-font":n.className,media:"async@load"},events:{load:function(){this.media="all";t()},error:function(){t()}}});var i=o("style",{attrs:{"data-id":n.className},text:"."+n.className+" { font-family: "+d(n.family,n.category)+"; }"});r(a,e.head);r(i,e.head)}else{t()}}.bind(this))},getUnusedLoadedFonts:function(){var n=[];var t=this.getLoadedFonts().filter((function(n){return!n.protected}));if(t.length){var e=this.getAllUsedFonts();t.forEach((function(t){var a=e.some((function(n){return t.className===n}));if(!a){n.push(t)}}))}return n},removeUnusedFonts:function(){this.getUnusedLoadedFonts().forEach((function(n){if(n.element){i(n.element)}if(n.CSSDeclaration){i(n.CSSDeclaration)}}))}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:63:"/bitrix/js/landing/ui/adapter/css-property.min.js?1708115049408";s:6:"source";s:45:"/bitrix/js/landing/ui/adapter/css-property.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Adapter");BX.Landing.UI.Adapter.CSSProperty=function(){};function r(){return BX.browser.IsFirefox()}BX.Landing.UI.Adapter.CSSProperty.get=function(n){if(r()&&n in BX.Landing.UI.Adapter.CSSProperty.map){n=BX.Landing.UI.Adapter.CSSProperty.map[n]}return n};BX.Landing.UI.Adapter.CSSProperty.map={"border-color":r()?"border-bottom-color":"border-color"}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:57:"/bitrix/js/landing/ui/button/plus_button.js?1708115049662";s:6:"source";s:43:"/bitrix/js/landing/ui/button/plus_button.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
;(function() {
	"use strict";

	BX.namespace("BX.Landing.UI.Button");


	/**
	 * Implements concrete interface of plus button
	 *
	 * @extends {BX.Landing.UI.Button.BaseButton}
	 *
	 * @param {?string} id
	 * @param {?object} [options]
	 * @constructor
	 */
	BX.Landing.UI.Button.Plus = function(id, options)
	{
		BX.Landing.UI.Button.BaseButton.apply(this, arguments);
		this.buttonClass = "landing-ui-button-plus";
		this.init();
	};


	BX.Landing.UI.Button.Plus.prototype = {
		constructor: BX.Landing.UI.Button.Plus,
		__proto__: BX.Landing.UI.Button.BaseButton.prototype,

		init: function()
		{
			this.layout.classList.add(this.buttonClass);
		}
	};
})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:70:"/bitrix/js/landing/ui/button/editor_action_button.min.js?1708115049760";s:6:"source";s:52:"/bitrix/js/landing/ui/button/editor_action_button.js";s:3:"min";s:56:"/bitrix/js/landing/ui/button/editor_action_button.min.js";s:3:"map";s:56:"/bitrix/js/landing/ui/button/editor_action_button.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Button");BX.Landing.UI.Button.EditorAction=function(t,n){BX.Landing.UI.Button.BaseButton.apply(this,arguments);this.layout.classList.add("landing-ui-button-editor-action");this.init()};BX.Landing.UI.Button.EditorAction.prototype={constructor:BX.Landing.UI.Button.EditorAction,__proto__:BX.Landing.UI.Button.BaseButton.prototype,init:function(){this.on("click",this.onClick,this);this.contextDocument=document},onClick:function(t){t.preventDefault();t.stopPropagation();const n=this.contextDocument.execCommand(this.id);BX.Landing.UI.Tool.ColorPicker.hideAll()},setContextDocument:function(t){if(t.nodeType===Node.DOCUMENT_NODE){this.contextDocument=t}}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:64:"/bitrix/js/landing/ui/button/ai_text_button.min.js?1708115049342";s:6:"source";s:46:"/bitrix/js/landing/ui/button/ai_text_button.js";s:3:"min";s:50:"/bitrix/js/landing/ui/button/ai_text_button.min.js";s:3:"map";s:50:"/bitrix/js/landing/ui/button/ai_text_button.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Button");BX.Landing.UI.Button.AiText=function(t,n){BX.Landing.UI.Button.EditorAction.apply(this,arguments)};BX.Landing.UI.Button.AiText.prototype={constructor:BX.Landing.UI.Button.AiText,__proto__:BX.Landing.UI.Button.EditorAction.prototype}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:63:"/bitrix/js/landing/ui/button/design_button.min.js?1708115049299";s:6:"source";s:45:"/bitrix/js/landing/ui/button/design_button.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Button");BX.Landing.UI.Button.Design=function(n,t){BX.Landing.UI.Button.EditorAction.apply(this,arguments)};BX.Landing.UI.Button.Design.prototype={constructor:BX.Landing.UI.Button.Design,__proto__:BX.Landing.UI.Button.EditorAction.prototype}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:63:"/bitrix/js/landing/ui/button/color_button.min.js?17081150492396";s:6:"source";s:44:"/bitrix/js/landing/ui/button/color_button.js";s:3:"min";s:48:"/bitrix/js/landing/ui/button/color_button.min.js";s:3:"map";s:48:"/bitrix/js/landing/ui/button/color_button.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Button");BX.Landing.UI.Button.ColorAction=function(t,o){BX.Landing.UI.Button.EditorAction.apply(this,arguments);this.id=t;this.options=o;if(this.id!=="tableBgColor"){this.layout.classList.add("landing-ui-button-editor-action-color")}const n=BX.Landing.UI.Panel.EditorPanel.getInstance().isOutOfFrame()?window.parent:window;this.colorPicker=new n.BX.Landing.UI.Tool.ColorPicker(this,this.onColorSelected.bind(this));BX.Landing.UI.Button.ColorAction.instances.push(this)};BX.Landing.UI.Button.ColorAction.instances=[];BX.Landing.UI.Button.ColorAction.hideAll=function(){BX.Landing.UI.Button.ColorAction.instances.forEach((function(t){t.colorPicker.hide()}))};BX.Landing.UI.Button.ColorAction.prototype={constructor:BX.Landing.UI.Button.ColorAction,__proto__:BX.Landing.UI.Button.EditorAction.prototype,onClick:function(t){t.preventDefault();t.stopPropagation();var o=BX.Landing.UI.Panel.EditorPanel.getInstance().isFixed()?"fixed":"relative";if(!this.colorPicker.isShown()){this.colorPicker.show(o);if(BX.Landing.UI.Button.ChangeTag.menu){BX.Landing.UI.Button.ChangeTag.menu.close()}}else{this.colorPicker.hide()}},onColorSelected:function(t){if(this.id==="tableTextColor"){this.applyColorInTableCells(t)}if(this.id==="tableBgColor"){this.applyBgInTableCells(t)}this.contextDocument.execCommand(this.id,false,t)},applyColorInTableCells:function(t){var o=Array.from(this.options.setTd);o.forEach((function(o){if(o.nodeType===1){o.style.color=t}}));if(this.options.target==="table"){this.options.table.setAttribute("text-color",t)}BX.Landing.Block.Node.Text.currentNode.onChange(true)},prepareOptionsForApplyColorInTableCells:function(t,o){this.options=o;this.applyColorInTableCells(t)},applyBgInTableCells:function(t){var o=Array.from(this.options.setTd);o.forEach((function(o){if(o.nodeType===1){if(!o.classList.contains("landing-table-col-dnd")&&!o.classList.contains("landing-table-row-dnd")&&!o.classList.contains("landing-table-th-select-all")){o.style.setProperty("background-color",t,"important")}}}));if(this.options.target==="table"){this.options.table.setAttribute("bg-color",t)}BX.Landing.Block.Node.Text.currentNode.onChange(true)},setContextDocument:function(t){BX.Landing.UI.Button.EditorAction.prototype.setContextDocument.apply(this,arguments);this.colorPicker.setContextDocument(t)}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:67:"/bitrix/js/landing/ui/button/block_card_action.min.js?1708115049418";s:6:"source";s:49:"/bitrix/js/landing/ui/button/block_card_action.js";s:3:"min";s:53:"/bitrix/js/landing/ui/button/block_card_action.min.js";s:3:"map";s:53:"/bitrix/js/landing/ui/button/block_card_action.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Button");BX.Landing.UI.Button.CardAction=function(t,n){BX.Landing.UI.Button.ActionButton.apply(this,arguments);this.layout.classList.add("landing-ui-button-card-action")};BX.Landing.UI.Button.CardAction.prototype={constructor:BX.Landing.UI.Button.ActionButton,__proto__:BX.Landing.UI.Button.ActionButton.prototype}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:61:"/bitrix/js/landing/ui/button/create_link.min.js?1708115049733";s:6:"source";s:43:"/bitrix/js/landing/ui/button/create_link.js";s:3:"min";s:47:"/bitrix/js/landing/ui/button/create_link.min.js";s:3:"map";s:47:"/bitrix/js/landing/ui/button/create_link.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Button");BX.Landing.UI.Button.CreateLink=function(t,n){BX.Landing.UI.Button.EditorAction.apply(this,arguments);this.editPanel=null};BX.Landing.UI.Button.CreateLink.prototype={constructor:BX.Landing.UI.Button.CreateLink,__proto__:BX.Landing.UI.Button.EditorAction.prototype,onClick:function(t){t.preventDefault();t.stopPropagation();this.textNode=BX.Landing.Block.Node.Text.currentNode;this.textField=BX.Landing.UI.Field.BaseField.currentField;if(!!this.textField&&this.textField.isEditable()){this.textNode=this.textField}const n=BX.Landing.UI.Panel.Link.getInstance();n.setContextDocument(this.contextDocument);n.show(this.textNode)}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:63:"/bitrix/js/landing/ui/button/create_table.min.js?17081150493459";s:6:"source";s:44:"/bitrix/js/landing/ui/button/create_table.js";s:3:"min";s:48:"/bitrix/js/landing/ui/button/create_table.min.js";s:3:"map";s:48:"/bitrix/js/landing/ui/button/create_table.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Button");BX.Landing.UI.Button.CreateTable=function(t,e){BX.Landing.UI.Button.EditorAction.apply(this,arguments);this.editPanel=null;this.options=e;this.id=t};BX.Landing.UI.Button.CreateTable.prototype={constructor:BX.Landing.UI.Button.CreateTable,__proto__:BX.Landing.UI.Button.EditorAction.prototype,onClick:function(t){t.preventDefault();t.stopPropagation();var e="rgb(51, 51, 51)";var n="#333333";var a=this.contextDocument.createElement("div");a.classList.add("landing-table-container");var d=this.contextDocument.createElement("table");d.classList.add("landing-table","landing-table-style-1");d.setAttribute("text-color",n);var l=this.contextDocument.createElement("tr");l.classList.add("landing-table-tr");var i=this.contextDocument.createElement("tr");i.classList.add("landing-table-tr");var o=this.contextDocument.createElement("th");o.classList.add("landing-table-th","landing-table-row-dnd");var r=this.contextDocument.createElement("div");r.classList.add("landing-table-row-add");var c=this.contextDocument.createElement("div");c.classList.add("landing-table-row-add-line");var s=this.contextDocument.createElement("div");s.classList.add("landing-table-div-row-dnd");r.appendChild(c);var h=this.contextDocument.createElement("td");h.classList.add("landing-table-th","landing-table-td");var u=this.getCellWidth();h.style.width=u+"px";h.style.color=e;var v=this.contextDocument.createElement("th");v.classList.add("landing-table-th","landing-table-col-dnd");v.style.width=u+"px";var p=this.contextDocument.createElement("div");p.classList.add("landing-table-div-col-dnd");var m=this.contextDocument.createElement("div");m.classList.add("landing-table-col-resize");var g=this.contextDocument.createElement("div");g.classList.add("landing-table-col-add");var b=this.contextDocument.createElement("div");b.classList.add("landing-table-col-add-line");g.appendChild(b);var C=this.contextDocument.createElement("th");C.classList.add("landing-table-th","landing-table-th-select-all");C.style.width="16px";var x=this.contextDocument.createElement("div");x.classList.add("th-tech-icon");l.appendChild(C.cloneNode(true));for(var L=0;L<=3;L++){l.appendChild(v.cloneNode(true))}i.appendChild(o.cloneNode(true));for(var L=0;L<=3;L++){i.appendChild(h.cloneNode(true))}d.appendChild(l.cloneNode(true));for(var L=0;L<=3;L++){d.appendChild(i.cloneNode(true))}a.appendChild(d);var f=this.contextDocument.createElement("div");a.id="new-table";f.appendChild(a);this.contextDocument.execCommand("insertHTML",null,f.innerHTML);var E=this.contextDocument.getElementById("new-table");var D=E.querySelector(".landing-table-th-select-all");if(D.firstChild){D.firstChild.remove()}D.appendChild(x.cloneNode(true));var B=E.querySelectorAll(".landing-table-col-dnd");B.forEach((function(t){if(t.firstChild){t.firstChild.remove()}t.appendChild(p.cloneNode(true));t.appendChild(m.cloneNode(true));t.appendChild(g.cloneNode(true))}));var N=E.querySelectorAll(".landing-table-row-dnd");N.forEach((function(t){if(t.firstChild){t.firstChild.remove()}t.appendChild(r.cloneNode(true));t.appendChild(s.cloneNode(true))}));E.removeAttribute("id");BX.Landing.Block.Node.Text.currentNode.onChange(true)},getCellWidth:function(){var t=250;var e=1e3;var n=57;var a=4;var d=t;var l=BX.Landing.Block.Node.Text.currentNode.node.getBoundingClientRect().width;if(l<e){d=Math.floor((l-n)/a)}return d}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:61:"/bitrix/js/landing/ui/button/paste_table.min.js?1708115049932";s:6:"source";s:43:"/bitrix/js/landing/ui/button/paste_table.js";s:3:"min";s:47:"/bitrix/js/landing/ui/button/paste_table.min.js";s:3:"map";s:47:"/bitrix/js/landing/ui/button/paste_table.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Button");BX.Landing.UI.Button.PasteTable=function(t,n){BX.Landing.UI.Button.EditorAction.apply(this,arguments);this.editPanel=null;this.options=n};BX.Landing.UI.Button.PasteTable.prototype={constructor:BX.Landing.UI.Button.PasteTable,__proto__:BX.Landing.UI.Button.EditorAction.prototype,onClick:function(t){t.preventDefault();t.stopPropagation();if(top.window.copiedTable){var n=this.contextDocument.createElement("div");n.appendChild(top.window.copiedTable.cloneNode(true));n.querySelector(".landing-table-container").classList.add("landing-table-pasted");this.contextDocument.execCommand("insertHTML",null,n.innerHTML);var e=this.contextDocument.querySelector(".landing-table-pasted");e.innerHTML="";e.appendChild(top.window.copiedTable.querySelector(".landing-table").cloneNode(true));e.classList.remove("landing-table-pasted")}}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:70:"/bitrix/js/landing/ui/button/delete_element_table.min.js?1708115049826";s:6:"source";s:52:"/bitrix/js/landing/ui/button/delete_element_table.js";s:3:"min";s:56:"/bitrix/js/landing/ui/button/delete_element_table.min.js";s:3:"map";s:56:"/bitrix/js/landing/ui/button/delete_element_table.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Button");BX.Landing.UI.Button.DeleteElementTable=function(t,e){BX.Landing.UI.Button.EditorAction.apply(this,arguments);this.editPanel=null;this.options=e;this.id=t};BX.Landing.UI.Button.DeleteElementTable.prototype={constructor:BX.Landing.UI.Button.DeleteElementTable,__proto__:BX.Landing.UI.Button.EditorAction.prototype,onClick:function(t){t.preventDefault();t.stopPropagation();if(this.id==="deleteRow"){var e=this.options.setTd[0].parentNode;e.remove()}if(this.id==="deleteCol"){this.options.setTd.forEach((function(t){t.remove()}))}BX.Event.EventEmitter.emit("BX.Landing.TableEditor:onDeleteElementTable");BX.Landing.UI.Panel.EditorPanel.getInstance().hide();BX.Landing.Block.Node.Text.currentNode.onChange(true)}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:62:"/bitrix/js/landing/ui/button/align_table.min.js?17081150491082";s:6:"source";s:43:"/bitrix/js/landing/ui/button/align_table.js";s:3:"min";s:47:"/bitrix/js/landing/ui/button/align_table.min.js";s:3:"map";s:47:"/bitrix/js/landing/ui/button/align_table.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Button");BX.Landing.UI.Button.AlignTable=function(t,i){BX.Landing.UI.Button.EditorAction.apply(this,arguments);this.editPanel=null;this.options=i;this.id=t};BX.Landing.UI.Button.AlignTable.prototype={constructor:BX.Landing.UI.Button.AlignTable,__proto__:BX.Landing.UI.Button.EditorAction.prototype,onClick:function(t){t.preventDefault();t.stopPropagation();var i=this.id;var n="landing-ui-active";this.options.alignButtons.forEach(function(t){if(t.id===i){t.layout.classList.add(n)}else{t.layout.classList.remove(n)}});if(this.options.table){var e=null;var a=["text-left","text-center","text-right","text-justify"];switch(this.id){case"alignLeft":e="text-left";break;case"alignCenter":e="text-center";break;case"alignRight":e="text-right";break;case"alignJustify":e="text-justify";break}this.options.setTd.forEach(function(t){if(t.nodeType===1){a.forEach(function(i){if(i===e){t.classList.add(i)}else{t.classList.remove(i)}})}})}BX.Landing.Block.Node.Text.currentNode.onChange(true)}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:62:"/bitrix/js/landing/ui/button/style_table.min.js?17081150494266";s:6:"source";s:43:"/bitrix/js/landing/ui/button/style_table.js";s:3:"min";s:47:"/bitrix/js/landing/ui/button/style_table.min.js";s:3:"map";s:47:"/bitrix/js/landing/ui/button/style_table.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Button");BX.Landing.UI.Button.StyleTable=function(t,e){BX.Landing.UI.Button.EditorAction.apply(this,arguments);this.options=e};BX.Landing.UI.Button.StyleTable.prototype={constructor:BX.Landing.UI.Button.StyleTable,__proto__:BX.Landing.UI.Button.EditorAction.prototype,onClick:function(t){t.preventDefault();t.stopPropagation();var e=this.options.table;var n=[];n.table=e;n.setTd=this.options.setTd;n.target=this.options.target;if(!this.menu){this.menu=new BX.PopupMenuWindow({id:"change-table-style-menu-"+BX.Text.getRandom(),bindElement:this.layout,zIndex:-678,items:[new BX.PopupMenuItem({id:"style1",text:BX.Landing.Loc.getMessage("LANDING_TABLE_STYLE_1"),onclick:this.onChange,table:e,options:n}),new BX.PopupMenuItem({id:"style2",text:BX.Landing.Loc.getMessage("LANDING_TABLE_STYLE_2"),onclick:this.onChange,table:e,options:n}),new BX.PopupMenuItem({id:"style3",text:BX.Landing.Loc.getMessage("LANDING_TABLE_STYLE_3"),onclick:this.onChange,table:e,options:n}),new BX.PopupMenuItem({id:"style4",text:BX.Landing.Loc.getMessage("LANDING_TABLE_STYLE_4"),onclick:this.onChange,table:e,options:n}),new BX.PopupMenuItem({id:"style5",text:BX.Landing.Loc.getMessage("LANDING_TABLE_STYLE_5"),onclick:this.onChange,table:e,options:n}),new BX.PopupMenuItem({id:"style6",text:BX.Landing.Loc.getMessage("LANDING_TABLE_STYLE_6"),onclick:this.onChange,table:e,options:n}),new BX.PopupMenuItem({id:"style7",text:BX.Landing.Loc.getMessage("LANDING_TABLE_STYLE_7"),onclick:this.onChange,table:e,options:n}),new BX.PopupMenuItem({id:"style8",text:BX.Landing.Loc.getMessage("LANDING_TABLE_STYLE_8"),onclick:this.onChange,table:e,options:n}),new BX.PopupMenuItem({id:"style9",text:BX.Landing.Loc.getMessage("LANDING_TABLE_STYLE_9"),onclick:this.onChange,table:e,options:n}),new BX.PopupMenuItem({id:"style10",text:BX.Landing.Loc.getMessage("LANDING_TABLE_STYLE_10"),onclick:this.onChange,table:e,options:n})]})}var o=this.menu.menuItems;o.forEach((function(t){t.menuItems=o}));if(e.classList.contains("landing-table-style-1")){o[0].layout.item.style.fontWeight="bold"}if(e.classList.contains("landing-table-style-2")){o[1].layout.item.style.fontWeight="bold"}if(e.classList.contains("landing-table-style-3")){o[2].layout.item.style.fontWeight="bold"}if(e.classList.contains("landing-table-style-4")){o[3].layout.item.style.fontWeight="bold"}if(e.classList.contains("landing-table-style-5")){o[4].layout.item.style.fontWeight="bold"}if(e.classList.contains("landing-table-style-6")){o[5].layout.item.style.fontWeight="bold"}if(e.classList.contains("landing-table-style-7")){o[6].layout.item.style.fontWeight="bold"}if(e.classList.contains("landing-table-style-8")){o[7].layout.item.style.fontWeight="bold"}if(e.classList.contains("landing-table-style-9")){o[8].layout.item.style.fontWeight="bold"}if(e.classList.contains("landing-table-style-10")){o[9].layout.item.style.fontWeight="bold"}if(this.menu.popupWindow.isShown()){this.menu.close()}else{this.menu.show()}},onChange:function(t,e){t.stopPropagation();e.menuWindow.close();var n;var o;var s=["landing-table-style-1","landing-table-style-2","landing-table-style-3","landing-table-style-4","landing-table-style-5","landing-table-style-6","landing-table-style-7","landing-table-style-8","landing-table-style-9","landing-table-style-10"];switch(e.id){case"style1":n=s[0];o=0;break;case"style2":n=s[1];o=1;break;case"style3":n=s[2];o=2;break;case"style4":n=s[3];o=3;break;case"style5":n=s[4];o=4;break;case"style6":n=s[5];o=5;break;case"style7":n=s[6];o=6;break;case"style8":n=s[7];o=7;break;case"style9":n=s[8];o=8;break;case"style10":n=s[9];o=9;break}if(n!==undefined){var i=0;e.menuItems.forEach((function(t){if(i===o){t.layout.item.style.fontWeight="bold"}else{t.layout.item.style.fontWeight="normal"}i++}));s.forEach((function(t){if(t===n){e.table.classList.add(t);var s="#cccccc";var i="#333333";if(o>=5){BX.Landing.UI.Button.ColorAction.prototype.prepareOptionsForApplyColorInTableCells(s,e.options.options.options)}else{BX.Landing.UI.Button.ColorAction.prototype.prepareOptionsForApplyColorInTableCells(i,e.options.options.options)}}else{e.table.classList.remove(t)}}))}BX.Landing.Block.Node.Text.currentNode.onChange(true)}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:60:"/bitrix/js/landing/ui/button/copy_table.min.js?1708115049893";s:6:"source";s:42:"/bitrix/js/landing/ui/button/copy_table.js";s:3:"min";s:46:"/bitrix/js/landing/ui/button/copy_table.min.js";s:3:"map";s:46:"/bitrix/js/landing/ui/button/copy_table.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Button");BX.Landing.UI.Button.CopyTable=function(t,n){BX.Landing.UI.Button.EditorAction.apply(this,arguments);this.editPanel=null;this.options=n};BX.Landing.UI.Button.CopyTable.prototype={constructor:BX.Landing.UI.Button.CopyTable,__proto__:BX.Landing.UI.Button.EditorAction.prototype,onClick:function(t){t.preventDefault();t.stopPropagation();var n=false;if(this.options){BX.Event.EventEmitter.emit("BX.Landing.TableEditor:onCopyTable");top.window.copiedTable=this.options.table.parentElement.cloneNode(true);if(top.window.copiedTable){n=true}}if(n){BX.UI.Notification.Center.notify({content:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_TABLE_COPIED")})}else{BX.UI.Notification.Center.notify({content:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_TABLE_NOT_COPIED")})}}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:62:"/bitrix/js/landing/ui/button/delete_table.min.js?1708115049599";s:6:"source";s:44:"/bitrix/js/landing/ui/button/delete_table.js";s:3:"min";s:48:"/bitrix/js/landing/ui/button/delete_table.min.js";s:3:"map";s:48:"/bitrix/js/landing/ui/button/delete_table.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Button");BX.Landing.UI.Button.DeleteTable=function(t,n){BX.Landing.UI.Button.EditorAction.apply(this,arguments);this.editPanel=null;this.options=n};BX.Landing.UI.Button.DeleteTable.prototype={constructor:BX.Landing.UI.Button.DeleteTable,__proto__:BX.Landing.UI.Button.EditorAction.prototype,onClick:function(t){t.preventDefault();t.stopPropagation();this.options.table.parentElement.remove();BX.Landing.UI.Panel.EditorPanel.getInstance().hide();BX.Landing.Block.Node.Text.currentNode.onChange(true)}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:61:"/bitrix/js/landing/ui/button/change_tag.min.js?17081150491933";s:6:"source";s:42:"/bitrix/js/landing/ui/button/change_tag.js";s:3:"min";s:46:"/bitrix/js/landing/ui/button/change_tag.min.js";s:3:"map";s:46:"/bitrix/js/landing/ui/button/change_tag.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Button");var n=BX.Landing.Utils.proxy;BX.Landing.UI.Button.ChangeTag=function(t,e){BX.Landing.UI.Button.EditorAction.apply(this,arguments);this.layout.classList.add("landing-ui-button-editor-change-tag");this.onChangeHandler=e.onChange;this.value=e.html;this.onChange=n(this.onChange,this)};BX.Landing.UI.Button.ChangeTag.prototype={constructor:BX.Landing.UI.Button.ChangeTag,__proto__:BX.Landing.UI.Button.EditorAction.prototype,onClick:function(n){n.preventDefault();n.stopPropagation();if(!this.menu){this.menu=new BX.PopupMenuWindow({id:"change-tag-name-menu-"+BX.Text.getRandom(),bindElement:this.layout,zIndex:-678,items:[new BX.PopupMenuItem({id:"H1",text:"H1",onclick:this.onChange}),new BX.PopupMenuItem({id:"H2",text:"H2",onclick:this.onChange}),new BX.PopupMenuItem({id:"H3",text:"H3",onclick:this.onChange}),new BX.PopupMenuItem({id:"H4",text:"H4",onclick:this.onChange}),new BX.PopupMenuItem({id:"H5",text:"H5",onclick:this.onChange}),new BX.PopupMenuItem({id:"H6",text:"H6",onclick:this.onChange})]});this.activateItem(this.value)}BX.Landing.UI.Button.ChangeTag.menu=this.menu;this.menu.popupWindow.adjustPosition({forceTop:true});if(this.menu.popupWindow.isShown()){this.menu.close()}else{this.menu.show()}BX.Landing.UI.Tool.ColorPicker.hideAll()},activateItem:function(n){if(this.menu){var t=this.menu.menuItems.find(function(n){return n.layout.text.innerHTML.includes("strong")},this);var e=this.menu.menuItems.find(function(t){return t.id===n},this);if(t){t.layout.text.innerHTML=t.layout.text.innerText}if(e){e.layout.text.innerHTML="<strong>"+e.layout.text.innerText+"</strong>";this.layout.innerHTML='<span class="landing-ui-icon-editor-'+e.id.toLowerCase()+'"></span>'}}},onChange:function(n,t){n.stopPropagation();this.activateItem(t.id);t.menuWindow.close();if(this.onChangeHandler){this.onChangeHandler(t.id)}}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:71:"/bitrix/js/landing/ui/button/text_background_color.min.js?1708115049531";s:6:"source";s:53:"/bitrix/js/landing/ui/button/text_background_color.js";s:3:"min";s:57:"/bitrix/js/landing/ui/button/text_background_color.min.js";s:3:"map";s:57:"/bitrix/js/landing/ui/button/text_background_color.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Button");BX.Landing.UI.Button.TextBackgroundAction=function(t,n){BX.Landing.UI.Button.ColorAction.apply(this,arguments);this.layout.classList.remove("landing-ui-button-editor-action-color");this.layout.classList.add("landing-ui-button-editor-action-background")};BX.Landing.UI.Button.TextBackgroundAction.prototype={constructor:BX.Landing.UI.Button.TextBackgroundAction,__proto__:BX.Landing.UI.Button.ColorAction.prototype}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:61:"/bitrix/js/landing/ui/button/create_page.min.js?1708115049624";s:6:"source";s:43:"/bitrix/js/landing/ui/button/create_page.js";s:3:"min";s:47:"/bitrix/js/landing/ui/button/create_page.min.js";s:3:"map";s:47:"/bitrix/js/landing/ui/button/create_page.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Button");BX.Landing.UI.Button.CreatePage=function(t,n){BX.Landing.UI.Button.EditorAction.apply(this,arguments);this.editPanel=null};BX.Landing.UI.Button.CreatePage.prototype={constructor:BX.Landing.UI.Button.CreatePage,__proto__:BX.Landing.UI.Button.EditorAction.prototype,onClick:function(t){t.preventDefault();t.stopPropagation();const n=this.contextDocument.getSelection().getRangeAt(0);const e=n.toString();const o=BX.Landing.UI.Panel.CreatePage.getInstance();o.setContextDocument(this.contextDocument);o.show({title:e})}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:66:"/bitrix/js/landing/ui/panel/base_button_panel.min.js?1708115049874";s:6:"source";s:48:"/bitrix/js/landing/ui/panel/base_button_panel.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Panel");BX.Landing.UI.Panel.BaseButtonPanel=function(t,n){BX.Landing.UI.Panel.BasePanel.apply(this,arguments);this.layout.classList.add(n);this.buttons=new BX.Landing.UI.Collection.ButtonCollection};BX.Landing.UI.Panel.BaseButtonPanel.prototype={constructor:BX.Landing.UI.Panel.BaseButtonPanel,__proto__:BX.Landing.UI.Panel.BasePanel.prototype,addButton:function(t){if(!!t&&t instanceof BX.Landing.UI.Button.BaseButton){if(!this.getButton(t.id)){this.buttons.push(t);this.appendContent(t.layout)}}},prependButton:function(t){if(!!t&&t instanceof BX.Landing.UI.Button.BaseButton){if(!this.getButton(t.id)){this.buttons.unshift(t);this.prependContent(t.layout)}}},removeButton:function(t){var n=this.buttons.get(t);if(!!n){this.buttons.remove(n);BX.remove(n.layout)}},getButton:function(t){return this.buttons.get(t)}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:63:"/bitrix/js/landing/ui/panel/editor_panel.min.js?170811504913898";s:6:"source";s:43:"/bitrix/js/landing/ui/panel/editor_panel.js";s:3:"min";s:47:"/bitrix/js/landing/ui/panel/editor_panel.min.js";s:3:"map";s:47:"/bitrix/js/landing/ui/panel/editor_panel.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Panel");var t=BX.Landing.Utils.proxy;var n=BX.Landing.Utils.getSelectedElement;BX.Landing.UI.Panel.EditorPanel=function(){BX.Landing.UI.Panel.BaseButtonPanel.apply(this,arguments);this.layout.classList.add("landing-ui-panel-editor");this.position="absolute";this.currentElement=null;this.outOfFrame=true;this.onKeydown=this.onKeydown.bind(this);this.onTabDown=this.onTabDown.bind(this);this.onScroll=this.onScroll.bind(this)};BX.Landing.UI.Panel.EditorPanel.instance=null;BX.Landing.UI.Panel.EditorPanel.getInstance=function(){if(!BX.Landing.UI.Panel.EditorPanel.instance){BX.Landing.UI.Panel.EditorPanel.instance=new BX.Landing.UI.Panel.EditorPanel;BX.Landing.UI.Panel.EditorPanel.instance.init()}return BX.Landing.UI.Panel.EditorPanel.instance};var e=null;var i=null;function o(t){var n=new BX.Landing.UI.Button.EditorAction("drag",{html:'<strong class="landing-ui-drag">&nbsp;</strong>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_DRAG")}});n.layout.onbxdrag=a.bind(this);n.layout.onbxdragstop=s.bind(this);jsDD.registerObject(n.layout);t.prependButton(n);var e;var i;var o;function a(n,a){if(!e){var s=BX.pos(jsDD.current_node);i=Math.max(Math.abs(n-s.left),0);o=Math.max(Math.abs(a-s.top),0);if(t.currentElement.closest(".landing-ui-panel")){o+=BX.Landing.PageObject.getEditorWindow().scrollY}e=true}BX.DOM.write(function(){t.layout.classList.remove("landing-ui-transition");t.layout.style.top=a-o+"px";t.layout.style.left=n-i+"px"}.bind(this))}function s(){e=false;t.layout.classList.add("landing-ui-transition")}}function a(n){n.addButton(new BX.Landing.UI.Button.EditorAction("bold",{html:'<span class="landing-ui-icon-editor-bold"></span>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_BOLD")},onClick:t(n.adjustButtonsState,n)}));n.addButton(new BX.Landing.UI.Button.EditorAction("italic",{html:'<span class="landing-ui-icon-editor-italic"></span>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_ITALIC")},onClick:t(n.adjustButtonsState,n)}));n.addButton(new BX.Landing.UI.Button.EditorAction("underline",{html:'<span class="landing-ui-icon-editor-underline"></span>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_UNDERLINE")},onClick:t(n.adjustButtonsState,n)}));n.addButton(new BX.Landing.UI.Button.EditorAction("strikeThrough",{html:'<span class="landing-ui-icon-editor-strike"></span>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_STRIKE")},onClick:t(n.adjustButtonsState,n)}));n.addButton(new BX.Landing.UI.Button.EditorAction("justifyLeft",{html:'<span class="landing-ui-icon-editor-left"></span>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_ALIGN_LEFT")},onClick:t(n.adjustButtonsState,n)}));n.addButton(new BX.Landing.UI.Button.EditorAction("justifyCenter",{html:'<span class="landing-ui-icon-editor-center"></span>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_ALIGN_CENTER")},onClick:t(n.adjustButtonsState,n)}));n.addButton(new BX.Landing.UI.Button.EditorAction("justifyRight",{html:'<span class="landing-ui-icon-editor-right"></span>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_ALIGN_RIGHT")},onClick:t(n.adjustButtonsState,n)}));n.addButton(new BX.Landing.UI.Button.EditorAction("justifyFull",{html:'<span class="landing-ui-icon-editor-justify"></span>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_ALIGN_JUSTIFY")},onClick:t(n.adjustButtonsState,n)}));n.addButton(new BX.Landing.UI.Button.CreateLink("createLink",{html:'<span class="landing-ui-icon-editor-link"></span>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_CREATE_LINK")},onClick:t(n.adjustButtonsState,n)}));var e=BX.Landing.Env.getInstance().getOptions().rights;if(e&&e.includes("edit")){n.addButton(new BX.Landing.UI.Button.CreatePage("createPage",{html:'<span class="landing-ui-icon-editor-new-page"></span>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_CREATE_PAGE")},onClick:t(n.adjustButtonsState,n)}))}n.addButton(new BX.Landing.UI.Button.EditorAction("unlink",{html:'<span class="landing-ui-icon-editor-unlink"></span>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_UNLINK")},onClick:t(n.adjustButtonsState,n)}));n.addButton(new BX.Landing.UI.Button.EditorAction("insertUnorderedList",{html:'<span class="fa fa-list-ul"></span>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_UL")},onClick:t(n.adjustButtonsState,n)}));n.addButton(new BX.Landing.UI.Button.EditorAction("insertOrderedList",{html:'<span class="fa fa-list-ol"></span>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_OL")},onClick:t(n.adjustButtonsState,n)}));n.addButton(new BX.Landing.UI.Button.EditorAction("removeFormat",{html:'<span class="landing-ui-icon-editor-eraser"></span>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_CLEAR")},onClick:t(n.adjustButtonsState,n)}));n.addButton(new BX.Landing.UI.Button.ColorAction("foreColor",{text:BX.Landing.Loc.getMessage("EDITOR_ACTION_SET_FORE_COLOR"),attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_COLOR")},onClick:t(n.adjustButtonsState,n)}));n.addButton(new BX.Landing.UI.Button.TextBackgroundAction("hiliteColor",{html:'<span class="landing-ui-icon-editor-text-background"></span>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_TEXT_BACKGROUND")},onClick:t(n.adjustButtonsState,n)}));n.addButton(new BX.Landing.UI.Button.CreateTable("createTable",{html:'<span class="landing-ui-icon-editor-table"></span>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_CREATE_TABLE")},onClick:t(n.adjustButtonsState,n)}));n.addButton(new BX.Landing.UI.Button.PasteTable("pasteTable",{html:'<span class="landing-ui-icon-editor-copy"></span>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_PASTE_TABLE")},onClick:t(n.adjustButtonsState,n)}))}var s={top:0,left:0};function d(t,n,e){var i=n.getBoundingClientRect();var o=i.left+i.width/2-t.rect.width/2;var a=i.top-t.rect.height-4;var d="absolute";var l=t.outOfFrame?window.parent:window;var u=n.closest(".landing-ui-panel-content-body-content");if(u){if(n.classList.contains("landing-ui-field")){a+=l.pageYOffset}else{a=u.getBoundingClientRect().top+5;d="fixed"}}else if(BX.Landing.Main.getInstance().isControlsExternal()){a+=71}else{if(a<=5&&(i.bottom>l.innerHeight||i.height>l.innerHeight/1.5)){a=5;d="fixed"}else{if(a>5){a+=l.pageYOffset+66}else{a=i.bottom+4+l.pageYOffset}}}if(o+t.rect.width>l.innerWidth-20){o-=o+t.rect.width-(l.innerWidth-20)}o=Math.max(20,o);if(s.top!==a||s.left!==o||e){BX.DOM.write((function(){t.layout.style.position=d;t.layout.style.top=a+"px";t.layout.style.left=o+"px"}));s.top=a;s.left=o;L(t)}}function l(t){if(t.outOfFrame){window.parent.document.body.appendChild(t.layout)}else{window.document.body.appendChild(t.layout)}}var u=null;function r(t){u=t.target}var c=false;function g(t){c=u!==t.target}function h(t){if(c){t.preventDefault();t.stopPropagation()}}function B(t){if(t.popup){t.popup.close()}if(t.menu){t.menu.close()}}function L(t){t.buttons.forEach(B);if(t.additionalButtons){t.additionalButtons.forEach(B)}BX.Landing.UI.Tool.ColorPicker.hideAll()}BX.Landing.UI.Panel.EditorPanel.prototype={constructor:BX.Landing.UI.Panel.EditorPanel,__proto__:BX.Landing.UI.Panel.BaseButtonPanel.prototype,init:function(){o(this);a(this);l(this);this.rect=this.layout.getBoundingClientRect()},show:function(n,e,i,o,a){if(!o){this.showBaseButtons()}else{if(a){if(a.length>0){this.showBaseButtons();this.hideBaseButtons(a)}else{this.hideAllBaseButtons()}}else{this.hideAllBaseButtons()}}this.currentElement=n;this.setContextDocument(this.currentElement?this.currentElement.ownerDocument:document);if(this.additionalButtons){this.additionalButtons.forEach((function(t){this.buttons.remove(t);B(t);BX.remove(t.layout)}),this);this.additionalButtons=null}if(i){this.additionalButtons=i;this.additionalButtons.forEach((function(t){if(t.insertAfter){var n=this.layout.querySelector('[data-id="'+t.insertAfter+'"]');if(n){BX.insertAfter(t.layout,n);this.buttons.add(t)}}else{this.addButton(t)}}),this)}if(!this.isShown()){BX.onCustomEvent("BX.Landing.Editor:enable",[n]);this.contextDocument.addEventListener("mousedown",r,true);this.contextDocument.addEventListener("mouseup",g,true);this.contextDocument.addEventListener("click",h,true);this.currentElement.addEventListener("click",t(this.adjustButtonsState,this),true);setTimeout(function(){this.layout.classList.add("landing-ui-transition")}.bind(this),100)}BX.Landing.UI.Panel.BaseButtonPanel.prototype.show.call(this,arguments);BX.DOM.write(function(){this.rect=this.layout.getBoundingClientRect();this.adjustPosition(n,e,true)}.bind(this));this.onShow(n);this.adjustButtonsState();this.adjustButtonsContextDocument()},onShow:function(t){i=t;e=e||this.onScroll.bind(null,t);this.contextDocument.addEventListener("keydown",this.onKeydown);this.contextWindow.addEventListener("resize",e);try{this.contextDocument.addEventListener("scroll",e,{passive:true})}catch(t){this.contextDocument.addEventListener("scroll",e)}},hide:function(){if(this.isShown()){BX.onCustomEvent("BX.Landing.Editor:disable",[null]);this.contextDocument.removeEventListener("mousedown",r,true);this.contextDocument.removeEventListener("mouseup",g,true);this.contextDocument.removeEventListener("click",h,true);this.currentElement.removeEventListener("click",t(this.adjustButtonsState,this),true);setTimeout(function(){this.rect=this.layout.getBoundingClientRect();this.layout.classList.remove("landing-ui-transition")}.bind(this),100)}BX.Landing.UI.Panel.BaseButtonPanel.prototype.hide.call(this,arguments);this.onHide()},onHide:function(){this.contextDocument.removeEventListener("keydown",this.onKeydown);this.contextWindow.removeEventListener("resize",e);try{this.contextDocument.removeEventListener("scroll",e,{passive:true})}catch(t){this.contextDocument.removeEventListener("scroll",e)}},onKeydown:function(t){if(t.key==="Tab"&&t.target.nodeName!=="LI"){t.preventDefault();if(!t.shiftKey){if(t.code==="Tab"){this.onTabDown()}else{this.contextDocument.execCommand("indent")}}else{this.contextDocument.execCommand("outdent")}}if(t.key==="Enter"&&t.target.nodeName!=="LI"&&t.target.nodeName!=="UL"&&t.metaKey===true){t.preventDefault();const n=this.contextWindow.getSelection().getRangeAt(0);const e=BX.create("br");n.deleteContents();n.insertNode(e);const i=this.contextDocument.createRange();i.setStartAfter(e);i.collapse(true);const o=this.contextWindow.getSelection();o.removeAllRanges();o.addRange(i)}setTimeout((function(){BX.Landing.UI.Panel.EditorPanel.getInstance().adjustPosition(i)}),10)},onTabDown:function(){var t=10;var n=true;var e=this.contextWindow.getSelection().focusNode.parentNode.parentNode;while(e.tagName==="DIV"){e=e.parentNode}var i=0;var o=[];var a=["UL","LI","BLOCKQUOTE","DIV"];while(a.indexOf(e.tagName)!==-1){if(e.tagName!=="DIV"){i++;o.push(e)}e=e.parentNode}if(i>t){if(o[o.length-1].tagName==="BLOCKQUOTE"){var s=o[o.length-1].previousSibling;while(s!==null&&s.nodeType!==1){s=s.previousSibling}var d=0;while(s&&s.tagName==="BLOCKQUOTE"){s=s.firstChild;d++}if(i-d>0){n=false}}else{for(var l=1;l<o.length;l++){if(o[l].childNodes.length<2){n=false;break}}if(o[0].firstChild.nextSibling===null){n=false}}}if(n){this.contextDocument.execCommand("indent")}},onScroll:function(){BX.Landing.UI.Panel.EditorPanel.getInstance().adjustPosition(i)},adjustButtonsState:function(){var t=function(t){return(!t?"de":"")+"activate"};var n=function(t){return this.buttons.get(t)}.bind(this);requestAnimationFrame(function(){var e=this.getFormat();void(n("bold")&&n("bold")[t(e.bold)]());void(n("italic")&&n("italic")[t(e.italic)]());void(n("underline")&&n("underline")[t(e.underline)]());void(n("strikeThrough")&&n("strikeThrough")[t(e.strike)]());void(n("justifyLeft")&&n("justifyLeft")[t(e.align==="left")]());void(n("justifyCenter")&&n("justifyCenter")[t(e.align==="center")]());void(n("justifyRight")&&n("justifyRight")[t(e.align==="right")]());void(n("justifyFull")&&n("justifyFull")[t(e.align==="justify")]())}.bind(this))},adjustButtonsContextDocument:function(){this.buttons.forEach((t=>{if("setContextDocument"in t){t.setContextDocument(this.contextDocument)}}))},getFormat:function(){var t=n(this.contextDocument);var e={};if(t){var i=getComputedStyle(t);switch(i.getPropertyValue("font-weight")){case"bold":case"bolder":case"500":case"600":case"700":case"800":case"900":e["bold"]=true;break}if(t.tagName==="B"){e["bold"]=true}if(i.getPropertyValue("font-style")==="italic"){e["italic"]=true}if(i.getPropertyValue("text-decoration").includes("underline")||i.getPropertyValue("text-decoration-line").includes("underline")){e["underline"]=true}if(i.getPropertyValue("text-decoration").includes("line-through")||i.getPropertyValue("text-decoration-line").includes("line-through")){e["strike"]=true}var o=i.getPropertyValue("text-align")||"left";if(o.match(/[left|center|rigth|custiffy]/)){e["align"]=o}if(this.currentElement.nodeName==="A"||this.currentElement.closest("a")){e["link"]=true}}return e},adjustPosition:function(t,n,e){d(this,t,e)},isFixed:function(){return this.position==="fixed-top"||this.position==="fixed-right"},hideAllBaseButtons:function(){this.layout.childNodes.forEach((function(t){if(t.dataset.id!=="drag"){t.hidden=true}}))},hideBaseButtons:function(t){this.layout.childNodes.forEach((function(n){if(t.indexOf(n.dataset.id)!==-1){n.hidden=true}}))},showBaseButtons:function(){this.layout.childNodes.forEach((t=>{if(t.dataset.id==="pasteTable"){if(top.window.copiedTable){t.hidden=false}else{t.hidden=true}}else{t.hidden=false}}))},isOutOfFrame:function(){return this.outOfFrame}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:64:"/bitrix/js/landing/ui/panel/small_editor_panel.js?17081150491474";s:6:"source";s:49:"/bitrix/js/landing/ui/panel/small_editor_panel.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
;(function() {
	"use strict";

	BX.namespace("BX.Landing.UI.Panel");


	BX.Landing.UI.Panel.SmallEditorPanel = function()
	{
		BX.Landing.UI.Panel.EditorPanel.apply(this, arguments);
		this.layout.classList.remove("landing-ui-hide");
		this.layout.classList.add("landing-ui-panel-small-content-edit");
	};


	/**
	 * Shows panel for text node
	 * @static
	 * @param {BX.Landing.Block.Node} [node]
	 */
	BX.Landing.UI.Panel.SmallEditorPanel.show = function(node)
	{
		BX.Landing.UI.Panel.SmallEditorPanel.getInstance().show(node);
	};


	/**
	 * Hides panel
	 * @static
	 */
	BX.Landing.UI.Panel.SmallEditorPanel.hide = function()
	{
		BX.Landing.UI.Panel.SmallEditorPanel.getInstance().hide();
	};


	/**
	 * Stores instance of BX.Landing.UI.Panel.SmallEditorPanel
	 * @static
	 * @type {?BX.Landing.UI.Panel.SmallEditorPanel}
	 */
	BX.Landing.UI.Panel.SmallEditorPanel.instance = null;


	/**
	 * Gets instance on BX.Landing.UI.Panel.SmallEditorPanel
	 * @static
	 * @return {BX.Landing.UI.Panel.SmallEditorPanel}
	 */
	BX.Landing.UI.Panel.SmallEditorPanel.getInstance = function()
	{
		if (!BX.Landing.UI.Panel.SmallEditorPanel.instance)
		{
			BX.Landing.UI.Panel.SmallEditorPanel.instance = new BX.Landing.UI.Panel.SmallEditorPanel();
		}

		return BX.Landing.UI.Panel.SmallEditorPanel.instance;
	};


	BX.Landing.UI.Panel.SmallEditorPanel.prototype = {
		constructor: BX.Landing.UI.Panel.SmallEditorPanel,
		__proto__: BX.Landing.UI.Panel.EditorPanel.prototype
	}
})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:64:"/bitrix/js/landing/ui/panel/edit_content_panel.js?17081150494274";s:6:"source";s:49:"/bitrix/js/landing/ui/panel/edit_content_panel.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
;(function() {
	"use strict";

	BX.namespace("BX.Landing.UI.Panel");

	var SidebarButton = BX.Landing.UI.Button.SidebarButton;

	/**
	 * Implements interface for works with content edit panel
	 *
	 * @extends {BX.Landing.UI.Panel.Content}
	 *
	 * @param {string} id - Panel id
	 * @param {object} data
	 * @constructor
	 */
	BX.Landing.UI.Panel.ContentEdit = function(id, data)
	{
		BX.Landing.UI.Panel.Content.apply(this, arguments);
		this.layout.classList.add("landing-ui-panel-content-edit");

		this.appendFooterButton(
			new BX.Landing.UI.Button.BaseButton("save_block_content", {
				text: BX.Landing.Loc.getMessage("BLOCK_SAVE"),
				onClick: BX.Type.isFunction(data.onSaveHandler) ? data.onSaveHandler : () => {},
				className: "landing-ui-button-content-save",
				attrs: {title: BX.Landing.Loc.getMessage("LANDING_TITLE_OF_SLIDER_SAVE")}
			})
		);
		this.appendFooterButton(
			new BX.Landing.UI.Button.BaseButton("cancel_block_content", {
				text: BX.Landing.Loc.getMessage("BLOCK_CANCEL"),
				onClick: BX.Type.isFunction(data.onCancelHandler) ? data.onCancelHandler : () => {},
				className: "landing-ui-button-content-cancel",
				attrs: {title: BX.Landing.Loc.getMessage("LANDING_TITLE_OF_SLIDER_CANCEL")}
			})
		);
	};

	BX.Landing.UI.Panel.ContentEdit.showedPanel = null;


	BX.Landing.UI.Panel.ContentEdit.prototype = {
		constructor: BX.Landing.UI.Panel.ContentEdit,
		__proto__: BX.Landing.UI.Panel.Content.prototype,

		show: function()
		{
			BX.Landing.UI.Panel.ContentEdit.showedPanel = this;

			if (BX.Landing.UI.Panel.StylePanel.getInstance().isShown())
			{
				BX.Landing.UI.Panel.StylePanel.getInstance().hide().then(function() {
					BX.Landing.UI.Panel.Content.prototype.show.call(this);
				}.bind(this));
			}
			else
			{
				BX.Landing.UI.Panel.Content.prototype.show.call(this);
			}
		},

		/**
		 * Appends form to panel body
		 * @param {BX.Landing.UI.Form.BaseForm} form
		 */
		appendForm: function(form)
		{
			this.forms.add(form);
			this.content.appendChild(form.getNode());
			this.checkReadyToSave();

			if (form.title)
			{
				var formButton = new SidebarButton(form.code, {
					text: form.title,
					empty: !form.fields.length,
					onClick: function()
					{
						this.scrollTo(form.layout);
						this.highlightItem(form.layout);
					}.bind(this)
				});

				this.sidebarButtons.add(formButton);
				this.sidebar.appendChild(formButton.layout);
			}

			form.fields.forEach(function(field) {
				if (field.title)
				{
					var fieldButton = new SidebarButton(field.selector, {
						text: field.title,
						child: true,
						onClick: function(event)
						{
							event.preventDefault();
							event.stopPropagation();
							this.scrollTo(field.layout);
							this.highlightItem(field.layout);
						}.bind(this)
					});
					this.sidebarButtons.add(fieldButton);
					this.sidebar.appendChild(fieldButton.layout);
				}
			}, this);
		},

		replaceForm: function(oldForm, newForm)
		{
			this.forms.remove(oldForm);
			this.forms.add(newForm);
			this.checkReadyToSave();

			BX.replace(oldForm.getNode(), newForm.getNode());

			var formButton = this.sidebarButtons.get(oldForm.code);

			if (formButton)
			{
				var newFormButton = new SidebarButton(newForm.code, {
					text: newForm.title,
					empty: newForm.type === 'dynamicCards' || !newForm.fields.length,
					onClick: function()
					{
						this.scrollTo(newForm.layout);
					}.bind(this)
				});

				BX.replace(formButton.layout, newFormButton.layout);
				this.sidebarButtons.remove(formButton);
				this.sidebarButtons.add(newFormButton);
			}
		},

		compact: function(enable)
		{
			this.layout.classList[enable?"add":"remove"]("landing-ui-panel-content-edit-compact");
		},

		highlightItem: function(element)
		{
			var highlightClass = 'landing-ui-panel-highlight';
			this.removeHighlights(this.layout, highlightClass);
			BX.Dom.addClass(element, highlightClass);
			setTimeout(() => {
				BX.Dom.removeClass(element, highlightClass);
			}, 1500);
		},

		removeHighlights: function(element, highlightClass)
		{
			var nodeList = element.querySelectorAll('.' + highlightClass);
			if (nodeList.length >= 1)
			{
				nodeList.forEach(function(node) {
					BX.Dom.removeClass(node, highlightClass);
				});
			}
		},
	};
})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:59:"/bitrix/js/landing/ui/panel/preview_panel.js?17081150494501";s:6:"source";s:44:"/bitrix/js/landing/ui/panel/preview_panel.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
;(function() {
	"use strict";

	BX.namespace("BX.Landing.UI.Panel");


	/**
	 * Implements preview panel interface
	 *
	 * @extends {BX.Landing.UI.Panel.Content}
	 *
	 * @inheritDoc
	 * @constructor
	 */
	BX.Landing.UI.Panel.Preview = function(id, data)
	{
		this.size = null;
		this.headerButtons = new BX.Landing.UI.Collection.ButtonCollection();
		this.iframe = BX.Landing.UI.Panel.Preview.createIframe();
		this.iframe.dataset.postfix = "";
		BX.Landing.UI.Panel.Content.apply(this, arguments);

		// Add class names
		this.layout.classList.add("landing-ui-panel-preview");
		this.overlay.classList.add("landing-ui-panel-preview-overlay");

		// Bind on iFrame events
		this.iframe.addEventListener("load", this.onFrameLoad.bind(this));
		this.iframe.style.opacity = 0;

		BX.remove(this.footer);
	};


	BX.Landing.UI.Panel.Preview.createIframe = function()
	{
		return BX.create("iframe", {props: {
			className: "landing-ui-panel-preview-iframe",
			src: BX.util.add_url_param(window.location.toString(), {"landing_mode": "style"})
		}});
	};


	BX.Landing.UI.Panel.Preview.prototype = {
		constructor: BX.Landing.UI.Panel.Preview,
		__proto__: BX.Landing.UI.Panel.Content.prototype,
		superclass: BX.Landing.UI.Panel.Content.prototype,

		init: function()
		{
			// Init super class
			this.superclass.init.call(this);

			// Add desktop button
			this.addHeaderButton(new BX.Landing.UI.Button.BaseButton("desktop_button", {
				className: ["landing-ui-button-desktop", "active"],
				onClick: this.onDesktopSizeChange.bind(this)
			}));

			// Add tablet button
			this.addHeaderButton(new BX.Landing.UI.Button.BaseButton("tablet_button", {
				className: "landing-ui-button-tablet",
				onClick: this.onTabletSizeChange.bind(this)
			}));

			// Add mobile button
			this.addHeaderButton(new BX.Landing.UI.Button.BaseButton("mobile_button", {
				className: "landing-ui-button-mobile",
				onClick: this.onMobileSizeChange.bind(this)
			}));


			// Create custom size field
			this.size = new BX.Landing.UI.Field.Unit({
				selector: "size",
				content: "0",
				unit: "px",
				onInput: this.onSizeInput.bind(this),
				className: "landing-ui-panel-preview-size",
				min: 320,
				max: 12000,
				step: 1
			});

			this.title.appendChild(this.size.layout);

			// Add iFrame to content area of panel
			this.content.appendChild(this.iframe);
		},


		/**
		 * Handles size input event
		 */
		onSizeInput: function(field)
		{
			requestAnimationFrame(function() {
				this.iframe.style.width = field.getValue() + "px";
			}.bind(this));
		},


		/**
		 * Handles iFrame load event
		 */
		onFrameLoad: function()
		{
			this.size.setValue(this.body.getBoundingClientRect().width);
			this.iframe.contentWindow.scrollTo(0, window.scrollY);
			requestAnimationFrame(function() {
				this.iframe.style.opacity = 1;
			}.bind(this));
		},


		/**
		 * Handles desktop size change event
		 */
		onDesktopSizeChange: function()
		{
			this.headerButtons.forEach(function(button) {
				button.layout.classList.remove("active");
			});

			this.headerButtons.get("desktop_button").layout.classList.add("active");
			this.size.setValue(this.body.getBoundingClientRect().width);
			this.iframe.dataset.postfix = "";
		},


		/**
		 * Handles tablet size change event
		 */
		onTabletSizeChange: function()
		{
			this.headerButtons.forEach(function(button) {
				button.layout.classList.remove("active");
			});

			this.headerButtons.get("tablet_button").layout.classList.add("active");
			this.size.setValue(767);
			this.iframe.dataset.postfix = "--md";
		},


		/**
		 * Handles mobile size change event
		 */
		onMobileSizeChange: function()
		{
			this.headerButtons.forEach(function(button) {
				button.layout.classList.remove("active");
			});

			this.headerButtons.get("mobile_button").layout.classList.add("active");
			this.size.setValue(479);
			this.iframe.dataset.postfix = "--sm";
		},


		/**
		 * Shows preview panel
		 */
		show: function()
		{
			this.superclass.show.call(this);
			document.documentElement.style.overflow = "hidden";
			this.iframe.contentWindow.scrollTo(0, window.scrollY);
		},


		/**
		 * Hides preview panel
		 */
		hide: function()
		{
			this.superclass.hide.call(this);
			document.documentElement.style.overflow = null;
		},


		/**
		 * Appends header button
		 * @param {BX.Landing.UI.Button.BaseButton} button
		 */
		addHeaderButton: function(button)
		{
			this.title.appendChild(button.layout);
			this.headerButtons.add(button);
		}
	};
})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:60:"/bitrix/js/landing/ui/panel/unsplash_panel.js?17081150494349";s:6:"source";s:45:"/bitrix/js/landing/ui/panel/unsplash_panel.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
;(function() {
	"use strict";

	BX.namespace("BX.Landing.UI.Panel");


	/**
	 * Implements interface for works with image library
	 *
	 * @extends {BX.Landing.UI.Panel.Content}
	 *
	 * @param {string} id - Panel id
	 * @constructor
	 */
	BX.Landing.UI.Panel.Unsplash = function(id)
	{
		if (BX.Landing.UI.Panel.Unsplash.instance)
		{
			return BX.Landing.UI.Panel.Unsplash.instance;
		}

		BX.Landing.UI.Panel.Content.apply(this, arguments);
		this.onChangeHandler = null;
		this.onSearchWithDebounce = BX.debounce(this.onSearchWithDebounce, 1000, this);
		this.layout.classList.add("landing-ui-panel-unsplash");
		this.searchContainer = BX.create("div", {props: {className: "landing-ui-panel-unsplash-search-container"}});
		this.loader = BX.create("div", {props: {className: "landing-ui-panel-unsplash-search-loader-container"}});
		this.loader.appendChild(BX.create("div", {props: {className: "landing-ui-panel-unsplash-search-loader"}}));
		(this.searchInputField = new BX.Landing.UI.Field.Unit({
			onInput: this.onSearchInput.bind(this),
			className: "landing-ui-panel-unsplash-search-field",
			placeholder: BX.Landing.Loc.getMessage("UNSPLASH_SEARCH_FIELD_PLACEHOLDER"),
			title: BX.Landing.Loc.getMessage("UNSPLASH_SEARCH_FIELD_LABEL")
		})).enableTextOnly();
		this.searchContainer.appendChild(this.searchInputField.layout);
		this.content.appendChild(this.searchContainer);


		this.searchInputField.input.type = "text";
		this.searchInputField.input.min = null;
		this.searchInputField.input.max = null;

		this.content.appendChild(this.loader);

		this.imagesList = BX.create("div", {props: {className: "landing-ui-panel-unsplash-images-list"}});
		this.content.appendChild(this.imagesList);

		document.body.appendChild(this.layout);

		this.makeLayouts();
	};


	/**
	 * Stores instance
	 * @static
	 * @type {BX.Landing.UI.Panel.Unsplash}
	 */
	BX.Landing.UI.Panel.Unsplash.instance = null;


	/**
	 * Gets panel instance
	 * @static
	 * @returns {BX.Landing.UI.Panel.Unsplash}
	 */
	BX.Landing.UI.Panel.Unsplash.getInstance = function()
	{
		if (!BX.Landing.UI.Panel.Unsplash.instance)
		{
			BX.Landing.UI.Panel.Unsplash.instance = new BX.Landing.UI.Panel.Unsplash("unsplash");
		}

		return BX.Landing.UI.Panel.Unsplash.instance;
	};


	BX.Landing.UI.Panel.Unsplash.prototype = {
		constructor: BX.Landing.UI.Panel.Unsplash,
		__proto__: BX.Landing.UI.Panel.Content.prototype,

		show: function(onChange)
		{
			BX.Landing.UI.Panel.Content.prototype.show.call(this);
			this.onChangeHandler = onChange;
		},

		hide: function()
		{
			BX.Landing.UI.Panel.Content.prototype.hide.call(this);
			this.onChangeHandler = null;
		},

		showLoader: function()
		{
			this.imagesList.innerHTML = "";
			this.loader.classList.add(this.classShow);
		},

		hideLoader: function()
		{
			this.loader.classList.remove(this.classShow);
		},

		isLoaderShown: function()
		{
			return this.loader.classList.contains(this.classShow);
		},

		onSearchInput: function(field)
		{
			var query = field.getValue();
			if (!!query && query.length)
			{
				this.showLoader();
				this.onSearchWithDebounce(query);

			}
			else
			{
				this.makeLayouts();
			}
		},

		onSearchWithDebounce: function(query)
		{
			var unsplash = new BX.Landing.Client.Unsplash.getInstance();
			unsplash.search(query).then(function(res) {
				this.hideLoader();
				this.imagesList.innerHTML = "";
				res.forEach(function(item) {
					var card = new BX.Landing.UI.Card.ImagePreview({
						image: item.urls.small,
						onClick: function() {
							this.onChange(item.urls.full);
						}.bind(this)
					});

					this.imagesList.appendChild(card.layout);
				}, this);
			}.bind(this));
		},

		makeLayouts: function()
		{
			var unsplash = new BX.Landing.Client.Unsplash.getInstance();

			this.showLoader();

			unsplash.popular().then(function(res) {
				this.hideLoader();
				this.imagesList.innerHTML = "";
				res.forEach(function(item) {
					var card = new BX.Landing.UI.Card.ImagePreview({
						image: item.urls.small,
						onClick: function() {
							this.onChange(item.urls.full);
						}.bind(this)
					});

					this.imagesList.appendChild(card.layout);
				}, this);
			}.bind(this));
		},

		onChange: function(path)
		{
			if (typeof this.onChangeHandler === "function")
			{
				this.onChangeHandler(path);
			}

			this.hide();
		}
	};
})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:61:"/bitrix/js/landing/ui/panel/image_panel.min.js?17081150493651";s:6:"source";s:42:"/bitrix/js/landing/ui/panel/image_panel.js";s:3:"min";s:46:"/bitrix/js/landing/ui/panel/image_panel.min.js";s:3:"map";s:46:"/bitrix/js/landing/ui/panel/image_panel.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Panel");BX.Landing.UI.Panel.Image=function(n){BX.Landing.UI.Panel.Content.apply(this,arguments);this.layout.classList.add("landing-ui-panel-image");this.onChangeHandler=function(){};this.headerButtonsField=this.createHeaderButtons();this.cards=new BX.Landing.Collection.BaseCollection;this.overlay.classList.add("landing-ui-panel-image");this.title.appendChild(this.headerButtonsField.layout);this.title.innerText=BX.Landing.Loc.getMessage("LANDING_IMAGE_LIBRARY_PANEL_TITLE");if(BX.Landing.Main.isEditorMode()){if(BX.Landing.Main.isExternalControlsEnabled()||window.parent&&window.parent!==top){window.parent.document.body.appendChild(this.layout);return}}this.overlay.parentNode.removeChild(this.overlay);document.body.appendChild(this.overlay);document.body.appendChild(this.layout)};BX.Landing.UI.Panel.Image.getInstance=function(){if(!BX.Landing.UI.Panel.Image.instance){BX.Landing.UI.Panel.Image.instance=new BX.Landing.UI.Panel.Image("image_panel")}return BX.Landing.UI.Panel.Image.instance};BX.Landing.UI.Panel.Image.instance=null;BX.Landing.UI.Panel.Image.prototype={constructor:BX.Landing.UI.Panel.Image,__proto__:BX.Landing.UI.Panel.Content.prototype,onChangeView:function(n){if(n==="unsplash"){this.showUnsplash()}if(n==="google"){this.showGoogle()}if(n==="disk"){this.showUploader()}},showUploader:function(){var n=this.cards.get("uploader");if(!n){n=new BX.Landing.UI.Card.Uploader({id:"uploader"});this.appendCard(n);this.cards.add(n)}this.hideAll();n.show()},showGoogle:function(){var n=this.cards.get("google");if(!n){n=new BX.Landing.UI.Card.Google({id:"google",searchLabel:BX.Landing.Loc.getMessage("GOOGLE_SEARCH_FIELD_LABEL"),searchTips:[{name:"Nature",value:"Nature"},{name:"People",value:"People"},{name:"Buildings",value:"Buildings"},{name:"Sunset",value:"Sunset"}],description:BX.Landing.Loc.getMessage("LANDING_IMAGE_GOOGLE_DESCRIPTION"),onChange:this.onChange.bind(this),params:this.uploadParams});this.appendCard(n);this.cards.add(n)}this.hideAll();n.showPopular();n.show()},showUnsplash:function(){var n=this.cards.get("unsplash");if(!n){n=new BX.Landing.UI.Card.Unsplash({id:"unsplash",searchLabel:BX.Landing.Loc.getMessage("UNSPLASH_SEARCH_FIELD_LABEL"),searchTips:[{name:"Nature",value:"Nature"},{name:"People",value:"People"},{name:"Buildings",value:"Buildings"},{name:"Sunset",value:"Sunset"}],description:BX.Landing.Loc.getMessage("LANDING_IMAGE_UNSPLASH_DESCRIPTION"),onChange:this.onChange.bind(this)});this.appendCard(n);this.cards.add(n)}this.hideAll();n.show()},hideAll:function(){this.cards.forEach((function(n){n.layout.hidden=true}))},createHeaderButtons:function(){return new BX.Landing.UI.Field.ButtonGroup({items:[{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_EDIT_IMAGE_HEADER_BUTTON_UNSPLASH"),value:"unsplash",active:true},{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_EDIT_IMAGE_HEADER_BUTTON_GOOGLE"),value:"google"},{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_EDIT_IMAGE_HEADER_BUTTON_FROM_DISK"),value:"disk"}],onChange:this.onChangeView.bind(this)})},show:function(n,e,a,i){this.uploadParams=i||{};this.externalLoader=a;this.params=e;this.onChangeView(n);BX.Landing.UI.Panel.Content.prototype.show.call(this);return new Promise(function(n){this.promiseResolve=n}.bind(this))},hide:function(){this.params=null;BX.Landing.UI.Panel.Content.prototype.hide.call(this)},onChange:function(n){this.externalLoader.show();BX.Landing.Utils.urlToBlob(n.link).then((function(e){e.lastModifiedDate=new Date;e.name=(n.name+"").split("?")[0];return e})).then(this.promiseResolve.bind(this));this.hide()}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:59:"/bitrix/js/landing/ui/panel/url_list.min.js?170811504911600";s:6:"source";s:39:"/bitrix/js/landing/ui/panel/url_list.js";s:3:"min";s:43:"/bitrix/js/landing/ui/panel/url_list.min.js";s:3:"map";s:43:"/bitrix/js/landing/ui/panel/url_list.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Panel");var e=BX.Landing.Utils.addClass;var t=BX.Landing.Utils.removeClass;var n=BX.Landing.Utils.append;var i=BX.Landing.Utils.onCustomEvent;var a=BX.Landing.Utils.setTextContent;var r=BX.Landing.Utils.create;var s=BX.Landing.Utils.style;var o=BX.Landing.Utils.isNumber;var d=BX.Landing.Utils.isString;var c=BX.Landing.Utils.isPlainObject;var l=BX.Landing.Utils.isArray;var h=BX.Landing.Utils.addQueryParams;var u="landing";var g="block";var L="system";var f="crmFormPopup";var p="crmPhone";var I="user";var v=BX.Landing.UI.Button.SidebarButton;BX.Landing.UI.Panel.URLList=function(t,a){BX.Landing.UI.Panel.Content.apply(this,arguments);e(this.layout,"landing-ui-panel-url-list");e(this.overlay,"landing-ui-panel-url-list-overlay");e(this.overlay,"landing-ui-hide");this.overlay.hidden=true;this.overlay.dataset.isShown="false";i("BX.Landing.Block:init",this.refresh.bind(this));i("BX.Landing.Block:remove",this.refresh.bind(this));if(BX.Landing.Main.isEditorMode()){n(this.layout,window.parent.document.body)}else{this.overlay.parentNode.removeChild(this.overlay);document.body.appendChild(this.overlay);n(this.layout,document.body);this.layout.style.marginTop=0;this.overlay.style.marginTop=0}this.loader=new BX.Loader({target:this.content});this.promiseResolve=function(){};this.layout.hidden=true;this.isNeedLoad=true;this.cache=new BX.Cache.MemoryCache};BX.Landing.UI.Panel.URLList.getInstance=function(){if(!BX.Landing.UI.Panel.URLList.instance){BX.Landing.UI.Panel.URLList.instance=new BX.Landing.UI.Panel.URLList("url_list")}return BX.Landing.UI.Panel.URLList.instance};BX.Landing.UI.Panel.URLList.instance=null;BX.Landing.UI.Panel.URLList.prototype={constructor:BX.Landing.UI.Panel.URLList,__proto__:BX.Landing.UI.Panel.Content.prototype,refresh:function(){this.isNeedLoad=true},showLoader:function(){this.loader.show(this.content)},show:function(e,n){this.showOptions=n;BX.Landing.UI.Panel.Content.prototype.show.call(this);this.clear();this.showLoader();if(e===u){t(this.layout,"landing-ui-panel-url-list-blocks");a(this.title,n.panelTitle||BX.Landing.Loc.getMessage("LANDING_LINKS_LANDINGS_TITLE"));this.showSites(n)}else if(e===g){a(this.title,n.panelTitle||BX.Landing.Loc.getMessage("LANDING_LINKS_BLOCKS_TITLE"));this.showBlocks(n)}else if(e===f){a(this.title,n.panelTitle||BX.Landing.Loc.getMessage("LANDING_LINKS_CRM_FORMS_TITLE"));this.showForms(n)}else if(e===p){a(this.title,n.panelTitle||BX.Landing.Loc.getMessage("LANDING_LINKS_CRM_PHONES_TITLE"));this.showPhones(n)}else if(e===I){a(this.title,n.panelTitle||BX.Landing.Loc.getMessage("LANDING_LINKS_CRM_PHONES_USERS"))}return new Promise(function(e){this.promiseResolve=e}.bind(this))},showSites:function(e){let t=e.siteId;void s(this.layout,{width:null});if(!BX.Type.isPlainObject(e.filter)){e.filter={}}var n=BX.Landing.Env.getInstance();if(BX.Type.isNil(e.filter.ID)&&n.getType()==="GROUP"){e.filter.ID=n.getSiteId()}if(e.filter.ID===-1){delete e.filter.ID}e.filter.SPECIAL="N";void BX.Landing.Backend.getInstance().getSites(e).then((n=>{n.forEach((n=>{if(parseInt(n.ID)==t){this.appendSidebarButton(this.createCurrentSiteButton());this.currentSiteButton=new v(n.ID,{text:n.TITLE,onClick:!e.currentSiteOnly?this.onSiteClick.bind(this,n.ID,e.enableAreas):null,child:true,active:true});this.appendSidebarButton(this.currentSiteButton)}}));if(!e.currentSiteOnly){this.appendSidebarButton(new v("my_sites",{text:BX.Landing.Loc.getMessage("LANDING_LINKS_PANEL_MY_SITES")}));n.forEach((n=>{const i=new v(n.ID,{text:n.TITLE,onClick:this.onSiteClick.bind(this,n.ID,e.enableAreas),child:true,active:!this.currentSiteButton});if(!this.currentSiteButton){this.currentSiteButton=i;t=n.ID}this.appendSidebarButton(i)}))}BX.Landing.Backend.getInstance().getLandings({siteId:t},e.filterLanding).then((n=>{const i={currentTarget:this.currentSiteButton.layout};const a=this.onSiteClick.bind(this,t,e.enableAreas,i);if(!e.disableAddPage){this.appendCard(new BX.Landing.UI.Card.AddPageCard({siteId:t,onSave:this.addPageSave.bind(this,a,t)}))}n.forEach((t=>{if(!t.IS_AREA||t.IS_AREA&&e.enableAreas){this.appendCard(new BX.Landing.UI.Card.LandingPreviewCard({title:t.TITLE,description:t.DESCRIPTION,preview:t.PREVIEW,onClick:this.onLandingClick.bind(this,t.ID,t.TITLE)}))}}));this.loader.hide()}))}))},createCurrentSiteButton:function(){return new v("current_site",{text:BX.Landing.Loc.getMessage("LANDING_LINKS_PANEL_CURRENT_SITE")})},showBlocks:function(e){var t=e.landingId;var n=e.siteId;void s(this.layout,{width:"880px"});if(!BX.Type.isPlainObject(e.filter)){e.filter={SPECIAL:"N"}}else{e.filter.SPECIAL="N"}BX.Landing.Backend.getInstance().getSites(e).then(function(e){const t=e.map((function(e){return e.ID}),this);return BX.Landing.Backend.getInstance().getLandings({siteId:t}).then((function(t){return e.reduce((function(e,n,i){const a=t.filter((function(e){return n.ID===e.SITE_ID&&!e.IS_AREA}));e[n.ID]={site:n,landings:a};return e}),{})}))}.bind(this)).then(function(i){let a=null;if(i[n]){this.appendSidebarButton(this.createCurrentSiteButton());i[n].landings.forEach((function(n){const i=parseInt(n.ID)===parseInt(t);if(!e.currentPageOnly||i){const e=this.createLandingSidebarButton(n,i);this.appendSidebarButton(e);if(i){a=e}}}),this)}if(!e.currentPageOnly){Object.keys(i).forEach((function(e){if(parseInt(e)!==parseInt(n)){var t=i[e].site;this.appendSidebarButton(this.createSiteSidebarButton(t));i[e].landings.forEach((function(e){const t=this.createLandingSidebarButton(e);this.appendSidebarButton(t);if(!a){a=t}}),this)}}),this)}if(a){a.layout.click()}}.bind(this))},showForms:function(){void s(this.layout,{width:"500px"});BX.Landing.Backend.getInstance().action("Form::getList").then(function(e){e.forEach(function(e){var t={title:e.NAME,className:"landing-ui-card-form-preview",onClick:this.onFormChange.bind(this,e)};if(e.IS_CALLBACK_FORM==="Y"){t.className+=" landing-ui-card-form-preview--callback"}this.appendCard(new BX.Landing.UI.Card.BaseCard(t))}.bind(this));this.loader.hide()}.bind(this))},onFormChange:function(e){this.hide();this.promiseResolve({id:e.ID,type:"crmFormPopup",name:e.NAME})},showPhones:function(){void s(this.layout,{width:"500px"});BX.Landing.Env.getInstance().getOptions().references.forEach(function(e){this.appendCard(new BX.Landing.UI.Card.BaseCard({title:e.text,className:"landing-ui-card-form-preview",onClick:this.onPhoneChange.bind(this,e)}))}.bind(this));this.loader.hide()},onPhoneChange:function(e){this.hide();this.promiseResolve({id:e.value,type:"crmPhone",name:e.text})},createLandingSidebarButton:function(e,t){return new v(e.ID,{text:e.TITLE,onClick:this.onLandingChange.bind(this,e),child:true,active:t})},createSiteSidebarButton:function(e){return new v(e.ID,{text:e.TITLE,child:false,active:false})},onLandingChange:function(e,t){this.currentSelectedLanding=e;this.sidebarButtons.forEach((function(e){if(e.layout===t.currentTarget){e.activate();return}e.deactivate()}));this.showPreviewLoader().then(this.createIframeIfNeed()).then(this.loadPreviewSrc(this.buildLandingPreviewUrl(e))).then(this.hidePreviewLoader())},buildLandingPreviewUrl:function(e){var t=BX.Landing.Main.getInstance().options.params.sef_url.landing_view;t=t.replace("#site_show#",e.SITE_ID);t=t.replace("#landing_edit#",e.ID);return h(t,{landing_mode:"edit"})},loadPreviewSrc:function(e){return function(){return new Promise(function(t){if(this.previewFrame.src!==e){this.previewFrame.src=e;this.previewFrame.onload=function(){var e=this.previewFrame.contentDocument;BX.Landing.Utils.removePanels(e);[].slice.call(e.querySelectorAll(".landing-main .block-wrapper")).forEach((function(e){e.setAttribute("data-selectable",1);e.classList.add("landing-ui-block-selectable-overlay");e.addEventListener("click",function(t){t.preventDefault();var n=e.closest("[data-landing]");var i=BX.Dom.attr(n,"data-landing");this.onBlockClick(parseInt(e.id.replace("block","")),t,i)}.bind(this))}),this);[].slice.call(e.querySelectorAll(".block-wrapper")).forEach((function(e){if(!e.getAttribute("data-selectable")){e.style.display="none"}}),this);[].slice.call(e.querySelectorAll(".landing-empty")).forEach((function(e){e.style.display="none"}),this);t(this.previewFrame)}.bind(this);return}t(this.previewFrame)}.bind(this))}.bind(this)},showPreviewLoader:function(){if(!this.loader){this.loader=new BX.Loader}if(this.previewFrameWrapper){void s(this.previewFrameWrapper,{opacity:0})}return new Promise(function(e){void this.loader.show(this.content);e()}.bind(this))},hidePreviewLoader:function(){return function(){void s(this.previewFrameWrapper,{opacity:null});return this.loader.hide()}.bind(this)},createIframeIfNeed:function(){return function(){new Promise(function(e){if(!this.previewFrame){this.previewFrame=r("iframe",{});this.previewFrameWrapper=r("div",{attrs:{style:"width: 100%; height: 100%; overflow: hidden;"}});this.previewFrameWrapper.appendChild(this.previewFrame);this.content.innerHTML="";this.content.appendChild(this.previewFrameWrapper);this.showPreviewLoader();requestAnimationFrame(function(){var e=this.content.clientWidth-40;void s(this.previewFrame,{width:"1000px",height:"calc((100vh - 113px) * (100 / "+e/1e3*100+"))",transform:"scale("+e/1e3+") translateZ(0)","transform-origin":"top left",border:"none"})}.bind(this))}e(this.previewFrame)}.bind(this))}.bind(this)},onBlockClick:function(e,t,n){if(t.isTrusted){void BX.Landing.Backend.getInstance().getBlocks({landingId:n}).then(function(t){var n=t.find((function(t){return t.id===e}));if(n){this.onChange({type:g,id:n.id,name:n.name,alias:n.alias})}}.bind(this))}},onLandingClick:function(e,t){this.onChange({type:u,id:e,name:t})},onSystemClick:function(e,t){this.onChange({type:L,id:"_"+e,name:t})},onSiteClick:function(e,t,n){this.sidebarButtons.forEach((function(e){if(e.layout===n.currentTarget||!!n.target&&e.layout===n.target.closest(".landing-ui-button")){this.currentSiteButton=e;e.activate()}else{e.deactivate()}}),this);this.content.innerHTML="";this.showLoader();BX.Landing.Backend.getInstance().getLandings({siteId:e}).then(function(i){var a=this.onSiteClick.bind(this,e,t,n);this.appendCard(new BX.Landing.UI.Card.AddPageCard({siteId:e,onSave:this.addPageSave.bind(this,a,e)}));i.forEach((function(e){if(!e.IS_AREA||e.IS_AREA&&t){this.appendCard(this.createLandingPreview(e))}}),this);this.loader.hide()}.bind(this))},addPageSave:function(e,t){this.cache=new BX.Cache.MemoryCache;var n=BX.Landing.Backend.getInstance();n.cache.delete("landings+["+t+"]");n.cache.delete('landings+["'+t+'"]');n.cache.delete("landing+"+t);e()},createLandingPreview:function(e){return new BX.Landing.UI.Card.LandingPreviewCard({title:e.TITLE,description:e.DESCRIPTION,preview:e.PREVIEW,onClick:this.onLandingClick.bind(this,e.ID,e.TITLE)})},createBlockPreview:function(e){return new BX.Landing.UI.Card.BlockHTMLPreview({content:e.id,onClick:this.onBlockClick.bind(this,e.id,e.name,e.alias)})},getLanding:function(e,t){var n=JSON.stringify(["getLanding"+e,t]);return this.cache.remember(n,function(){return BX.Landing.Backend.getInstance().action("Landing::getList",{params:{filter:{ID:e},get_preview:true}}).then(function(e){return e}.bind(this))}.bind(this))},getBlock:function(e){var t="getBlocks"+e;return this.cache.remember(t,function(){return BX.Landing.Backend.getInstance().action("Block::getById",{block:e,params:{edit_mode:true}}).then(function(e){return e}.bind(this))}.bind(this))},onChange:function(e){this.promiseResolve(e);this.hide()},hide:function(){this.previewFrame=null;return BX.Landing.UI.Panel.Content.prototype.hide.call(this)}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:60:"/bitrix/js/landing/ui/panel/top_panel.min.js?170811504911370";s:6:"source";s:40:"/bitrix/js/landing/ui/panel/top_panel.js";s:3:"min";s:44:"/bitrix/js/landing/ui/panel/top_panel.min.js";s:3:"map";s:44:"/bitrix/js/landing/ui/panel/top_panel.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Panel");var t=BX.Landing.Utils.removeClass;var n=BX.Landing.Utils.addClass;var e=BX.Landing.Utils.onCustomEvent;var i=BX.Landing.Utils.bind;var a=BX.Landing.Utils.makeFilterablePopupMenu;var s=BX.Landing.Utils.makeSelectablePopupMenu;var o=BX.Landing.Utils.style;var d=BX.Landing.Utils.encodeDataValue;BX.Landing.UI.Panel.Top=function(t,n){BX.Landing.UI.Panel.BasePanel.apply(this,arguments);this.layout=document.querySelector(".landing-ui-panel-top");this.siteButton=this.layout.querySelector(".landing-ui-panel-top-chain-link-site");this.pageButton=this.layout.querySelector(".landing-ui-panel-top-chain-link-page");this.undoButton=this.layout.querySelector(".landing-ui-panel-top-history-undo");this.redoButton=this.layout.querySelector(".landing-ui-panel-top-history-redo");this.desktopButton=this.layout.querySelector(".landing-ui-button-desktop");this.tabletButton=this.layout.querySelector(".landing-ui-button-tablet");this.mobileButton=this.layout.querySelector(".landing-ui-button-mobile");this.iframeWrapper=document.querySelector(".landing-ui-view-iframe-wrapper");this.iframe=document.querySelector(".landing-ui-view");this.lastActive=this.desktopButton;this.loader=null;this.onDesktopSizeChange=this.onDesktopSizeChange.bind(this);this.onTabletSizeChange=this.onTabletSizeChange.bind(this);this.onMobileSizeChange=this.onMobileSizeChange.bind(this);this.onIframeClick=this.onIframeClick.bind(this);this.onSiteButtonClick=this.onSiteButtonClick.bind(this);this.onPageButtonClick=this.onPageButtonClick.bind(this);this.onUndo=this.onUndo.bind(this);this.onRedo=this.onRedo.bind(this);this.onKeyDown=this.onKeyDown.bind(this);this.adjustHistoryButtonsState=this.adjustHistoryButtonsState.bind(this);i(this.desktopButton,"click",this.onDesktopSizeChange);i(this.tabletButton,"click",this.onTabletSizeChange);i(this.mobileButton,"click",this.onMobileSizeChange);i(this.iframe.contentDocument,"click",this.onIframeClick);i(this.undoButton,"click",this.onUndo);i(this.redoButton,"click",this.onRedo);i(document,"keydown",this.onKeyDown);e(document,"iframe:keydown",this.onKeyDown);e(window,"BX.Landing.History:init",this.adjustHistoryButtonsState);e(window,"BX.Landing.History:update",this.adjustHistoryButtonsState);var a=parseInt(BX.Landing.Main.getInstance().options.sites_count);var s=parseInt(BX.Landing.Main.getInstance().options.pages_count);if(a>1&&this.siteButton){i(this.siteButton,"click",this.onSiteButtonClick)}if(s>1&&this.pageButton){i(this.pageButton,"click",this.onPageButtonClick)}var o=BX.Landing.PageObject.getRootWindow();var d=o.BX.getClass("BX.Landing.History");if(d){o.BX.Landing.History.instance=null}BX.Landing.History.getInstance()};BX.Landing.UI.Panel.Top.instance=null;BX.Landing.UI.Panel.Top.getInstance=function(){var t=BX.Landing.PageObject.getRootWindow();if(!t.BX.Landing.UI.Panel.Top.instance){t.BX.Landing.UI.Panel.Top.instance=new BX.Landing.UI.Panel.Top("top_panel")}return t.BX.Landing.UI.Panel.Top.instance};BX.Landing.UI.Panel.Top.prototype={constructor:BX.Landing.UI.Panel.Top,__proto__:BX.Landing.UI.Panel.BasePanel.prototype,superclass:BX.Landing.UI.Panel.BasePanel.prototype,onKeyDown:function(t){var n=t.keyCode||t.which;if(n===90&&(window.navigator.userAgent.match(/win/i)?t.ctrlKey:t.metaKey)){var e=BX.Landing.PageObject.getRootWindow();var i=e.BX.Reflection.getClass("BX.Landing.UI.Panel.FormSettingsPanel");if(!i||!i.getInstance().isShown()){if(t.shiftKey){t.preventDefault();this.onRedo()}else{t.preventDefault();this.onUndo()}}}},onUndo:function(){if(BX.Landing.History.getInstance().canUndo()&&!this.undoButton.hasAttribute("data-disabled")){this.getLoader().show(this.undoButton);n(this.undoButton,"landing-ui-onload");BX.Landing.History.getInstance().undo().then(function(){this.getLoader().hide();t(this.undoButton,"landing-ui-onload")}.bind(this))}else{this.getLoader().hide();t(this.undoButton,"landing-ui-onload")}},onRedo:function(){if(BX.Landing.History.getInstance().canRedo()&&!this.redoButton.hasAttribute("data-disabled")){this.getLoader().show(this.redoButton);n(this.redoButton,"landing-ui-onload");BX.Landing.History.getInstance().redo().then(function(){this.getLoader().hide();t(this.redoButton,"landing-ui-onload")}.bind(this))}else{this.getLoader().hide();t(this.redoButton,"landing-ui-onload")}},getLoader:function(){if(this.loader===null){this.loader=new BX.Loader({size:23,offset:{top:"3px",left:"1px"}});void o(this.loader.layout.querySelector(".main-ui-loader-svg-circle"),{"stroke-width":"4px"});void o(this.loader.layout.querySelector(".main-ui-loader-svg"),{"margin-top":"-3px"})}return this.loader},adjustHistoryButtonsState:function(t){if(t.canUndo()){this.undoButton.classList.remove("landing-ui-disabled");this.undoButton.removeAttribute("data-disabled")}else{this.undoButton.classList.add("landing-ui-disabled")}if(t.canRedo()){this.redoButton.classList.remove("landing-ui-disabled");this.redoButton.removeAttribute("data-disabled")}else{this.redoButton.classList.add("landing-ui-disabled")}},disableHistory:function(){this.undoButton.classList.add("landing-ui-disabled");this.undoButton.setAttribute("data-disabled","");this.redoButton.classList.add("landing-ui-disabled");this.redoButton.setAttribute("data-disabled","")},enableHistory:function(){this.adjustHistoryButtonsState(BX.Landing.History.getInstance())},disableDevices:function(){this.desktopButton.classList.add("landing-ui-disabled");this.tabletButton.classList.add("landing-ui-disabled");this.mobileButton.classList.add("landing-ui-disabled")},enableDevices:function(){this.desktopButton.classList.remove("landing-ui-disabled");this.tabletButton.classList.remove("landing-ui-disabled");this.mobileButton.classList.remove("landing-ui-disabled")},onDesktopSizeChange:function(){this.lastActive.classList.remove("active");this.lastActive=this.desktopButton;this.desktopButton.classList.add("active");BX.DOM.write(function(){this.iframeWrapper.style.width=null}.bind(this));document.body.setAttribute("data-device","desktop");BX.Landing.Main.getInstance().setDeviceCode("desktop");this.iframeWrapper.dataset.postfix="";BX.Landing.Main.getInstance().enableControls();BX.Landing.Main.getInstance().setNoTouchDevice();BX.Landing.Main.getInstance().makeControlsInternal();BX.Landing.UI.Panel.StylePanel.getInstance().hide();BX.onCustomEvent("BX.Landing.Main:editorSizeChange",["desktop"])},onTabletSizeChange:function(){this.lastActive.classList.remove("active");this.lastActive=this.tabletButton;this.tabletButton.classList.add("active");BX.DOM.write(function(){this.iframeWrapper.style.width="990px"}.bind(this));document.body.setAttribute("data-device","tablet");BX.Landing.Main.getInstance().setDeviceCode("tablet");this.iframeWrapper.dataset.postfix="--md";BX.Landing.Main.getInstance().setTouchDevice();BX.Landing.Main.getInstance().makeControlsInternal();BX.Landing.UI.Panel.StylePanel.getInstance().hide();BX.onCustomEvent("BX.Landing.Main:editorSizeChange",["tablet"])},onMobileSizeChange:function(){this.lastActive.classList.remove("active");this.lastActive=this.mobileButton;this.mobileButton.classList.add("active");BX.DOM.write(function(){this.iframeWrapper.style.width="375px"}.bind(this));document.body.setAttribute("data-device","mobile");BX.Landing.Main.getInstance().setDeviceCode("mobile");this.iframeWrapper.dataset.postfix="--md";BX.Landing.Main.getInstance().setTouchDevice();BX.Landing.Main.getInstance().makeControlsExternal();BX.Landing.UI.Panel.StylePanel.getInstance().hide();BX.onCustomEvent("BX.Landing.Main:editorSizeChange",["mobile"])},onSiteButtonClick:function(t){t.preventDefault();if(!this.siteMenu){var n=new BX.Loader({size:40});this.siteMenu=new BX.PopupMenuWindow({id:"site_list_menu",bindElement:this.siteButton,events:{onPopupClose:function(){this.siteButton.classList.remove("landing-ui-active");this.siteButton.blur()}.bind(this)},menuShowDelay:0,offsetTop:9});this.siteMenu.popupWindow.contentContainer.style.minHeight="60px";this.siteMenu.popupWindow.contentContainer.style.minWidth="160px";n.show(this.siteMenu.popupWindow.contentContainer);var e={siteId:BX.Landing.Main.getInstance().options.site_id,landingId:BX.Landing.Main.getInstance().id,filter:{"=TYPE":BX.Landing.Main.getInstance().options.params.type,SPECIAL:"N"}};BX.Landing.Backend.getInstance().getSites(e).then((function(t){return new Promise((function(n){setTimeout(n.bind(null,t),300)}))})).then(function(t){a(this.siteMenu);s(this.siteMenu);t.forEach((function(t){this.siteMenu.addMenuItem({id:t.ID,text:d(t.TITLE),items:function(){var n=[];var e=BX.Landing.Main.getInstance().options.params.sef_url.site_edit;var i=BX.Landing.Main.getInstance().options.params.sef_url.site_show;n.push({text:BX.Landing.Loc.getMessage("LANDING_ENTITIES_MENU_PAGES_LIST"),href:i.replace("#site_show#",t.ID)});n.push({text:BX.Landing.Loc.getMessage("LANDING_ENTITIES_MENU_EDIT"),href:e.replace("#site_edit#",t.ID)});return n}()})}),this);n.hide()}.bind(this))}this.siteButton.classList.add("landing-ui-active");this.siteMenu.show()},onPageButtonClick:function(t){t.preventDefault();if(!this.pageMenu){var n=new BX.Loader({size:40});this.pageMenu=new BX.PopupMenuWindow({id:"page_list_menu",bindElement:this.pageButton,events:{onPopupClose:function(){this.pageButton.classList.remove("landing-ui-active");this.pageButton.blur()}.bind(this)},menuShowDelay:0,offsetTop:9});this.pageMenu.popupWindow.contentContainer.style.minHeight="60px";this.pageMenu.popupWindow.contentContainer.style.minWidth="160px";n.show(this.pageMenu.popupWindow.contentContainer);var e={siteId:BX.Landing.Main.getInstance().options.site_id,landingId:BX.Landing.Main.getInstance().id,filter:{"=TYPE":BX.Landing.Main.getInstance().options.params.type}};BX.Landing.Backend.getInstance().getLandings({siteId:e.siteId}).then((function(t){return new Promise((function(n){setTimeout(n.bind(null,t),300)}))})).then(function(t){a(this.pageMenu);s(this.pageMenu);t.forEach((function(t){if((t.FOLDER_ID===null||parseInt(t.FOLDER_ID)===0)&&!t.IS_AREA){this.pageMenu.addMenuItem({id:t.ID,text:d(t.TITLE),items:function(){var n=[];var e=BX.Landing.Main.getInstance().options.params.sef_url.landing_edit;var i=BX.Landing.Main.getInstance().options.params.sef_url.landing_view;if(t.FOLDER==="Y"){var a=BX.Landing.Main.getInstance().options.params.sef_url.site_show;n.push({text:BX.Landing.Loc.getMessage("LANDING_ENTITIES_MENU_PAGES_LIST"),href:BX.Landing.Utils.addQueryParams(a.replace("#site_show#",t.SITE_ID),{folderId:t.ID})})}n.push({text:BX.Landing.Loc.getMessage("LANDING_ENTITIES_MENU_PAGES_EDIT"),href:i.replace("#site_show#",t.SITE_ID).replace("#landing_edit#",t.ID)});n.push({text:BX.Landing.Loc.getMessage("LANDING_ENTITIES_MENU_PAGES_SETTINGS"),href:e.replace("#site_show#",t.SITE_ID).replace("#landing_edit#",t.ID)});return n}()})}}),this);requestAnimationFrame((function(){n.hide()}))}.bind(this))}this.pageButton.classList.add("landing-ui-active");this.pageMenu.show()},onIframeClick:function(){if(this.siteMenu){this.siteMenu.close()}if(this.pageMenu){this.pageMenu.close()}},getFormNameLayout:function(){return this.layout.querySelector(".landing-ui-panel-top-form-name")},setFormName:function(t){if(BX.Type.isString(t)){var n=this.getFormNameLayout();if(BX.Type.isDomNode(n)){n.firstElementChild.textContent=t;n.firstElementChild.setAttribute("title",t)}}}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:57:"/bitrix/js/landing/ui/panel/card_action.js?17081150492386";s:6:"source";s:42:"/bitrix/js/landing/ui/panel/card_action.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
;(function() {
	"use strict";

	BX.namespace("BX.Landing.UI.Panel");


	/**
	 * Implements interface for works with card actions panel
	 *
	 * @extends {BX.Landing.UI.Panel.BaseButtonPanel}
	 *
	 * @inheritDoc
	 * @constructor
	 */
	BX.Landing.UI.Panel.CardAction = function(id, data)
	{
		BX.Landing.UI.Panel.BaseButtonPanel.apply(this, arguments);
		adjustPanelSize(this);
	};


	/**
	 * Gets element rect
	 * @param {HTMLElement} element
	 * @returns {ClientRect|{left, top, width, height}}
	 */
	function rect(element)
	{
		return element.getBoundingClientRect();
	}


	/**
	 * Checks that size is extra small
	 * @param {ClientRect} rect
	 * @return {boolean}
	 */
	function isXS(rect)
	{
		return rect.height < 100;
	}


	/**
	 * @param {ClientRect} cardRect
	 * @param {ClientRect} panelRect
	 * @return {boolean}
	 */
	function isLeft(cardRect, panelRect)
	{
		return cardRect.width < panelRect.width;
	}


	/**
	 * Gets rect diff
	 * @param cardRect
	 * @param panelRect
	 * @return {{width: number, height: number, top: number, right: number, bottom: number, left: number}}
	 */
	function diffRect(cardRect, panelRect)
	{
		return {
			width: Math.abs(cardRect.width - panelRect.width),
			height: Math.abs(cardRect.height - panelRect.height),
			top: Math.abs(cardRect.top - panelRect.top),
			right: Math.abs(cardRect.right - panelRect.right),
			bottom: Math.abs(cardRect.bottom - panelRect.bottom),
			left: Math.abs(cardRect.left - panelRect.left)
		}
	}


	/**
	 * Adjusts panel size
	 * @param panel
	 */
	function adjustPanelSize(panel)
	{
		BX.DOM.read(function() {
			if (panel.layout && panel.layout.parentNode)
			{
				var cardRect = rect(panel.layout.parentNode);
				var sizeClassName = "landing-ui-size-lg";

				if (isXS(cardRect))
				{
					sizeClassName = "landing-ui-size-xs";
				}

				BX.DOM.write(function() {
					panel.layout.classList.add(sizeClassName);

					BX.DOM.read(function() {
						var panelRect = rect(panel.layout);
						var left = "auto";

						if (isLeft(cardRect, panelRect))
						{
							left = -(diffRect(cardRect, panelRect).width / 2)
						}

						BX.DOM.write(function() {
							panel.layout.style.left = left + "px";
						});
					});
				});
			}
		});
	}


	BX.Landing.UI.Panel.CardAction.prototype = {
		constructor: BX.Landing.UI.Panel.CardAction,
		__proto__: BX.Landing.UI.Panel.BaseButtonPanel.prototype
	}
})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:60:"/bitrix/js/landing/ui/panel/link_panel.min.js?17081150494116";s:6:"source";s:41:"/bitrix/js/landing/ui/panel/link_panel.js";s:3:"min";s:45:"/bitrix/js/landing/ui/panel/link_panel.min.js";s:3:"map";s:45:"/bitrix/js/landing/ui/panel/link_panel.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Panel");var n=BX.Landing.Utils.attr;var e=BX.Landing.Utils.join;var t=BX.Landing.Utils.random;var i=BX.Landing.Utils.setTextContent;var a=BX.Landing.Utils.isPlainObject;var s=BX.Landing.Utils.isString;var d=BX.Landing.Utils.textToPlaceholders;var l=BX.Landing.Utils.findParent;var o=BX.Landing.Utils.escapeText;BX.Landing.UI.Panel.Link=function(n,e){BX.Landing.UI.Panel.Content.apply(this,arguments);this.layout.classList.add("landing-ui-panel-link");this.overlay.classList.add("landing-ui-panel-link");this.appendFooterButton(new BX.Landing.UI.Button.BaseButton("save_block_content",{text:BX.Landing.Loc.getMessage("BLOCK_SAVE"),onClick:this.save.bind(this),className:"landing-ui-button-content-save"}));this.appendFooterButton(new BX.Landing.UI.Button.BaseButton("cancel_block_content",{text:BX.Landing.Loc.getMessage("BLOCK_CANCEL"),onClick:this.hide.bind(this),className:"landing-ui-button-content-cancel"}));window.parent.document.body.appendChild(this.layout)};BX.Landing.UI.Panel.Link.instance=null;BX.Landing.UI.Panel.Link.getInstance=function(){if(!BX.Landing.UI.Panel.Link.instance){BX.Landing.UI.Panel.Link.instance=new BX.Landing.UI.Panel.Link("link_panel",{title:BX.Landing.Loc.getMessage("LANDING_EDIT_LINK")})}return BX.Landing.UI.Panel.Link.instance};BX.Landing.UI.Panel.Link.prototype={constructor:BX.Landing.UI.Panel.Link,__proto__:BX.Landing.UI.Panel.Content.prototype,show:function(n){var e;this.title.innerHTML=BX.Landing.Loc.getMessage("LANDING_EDIT_LINK");if(!!n&&n instanceof BX.Landing.Block.Node.Link){this.node=n;e=new BX.Landing.UI.Form.BaseForm({title:this.node.manifest.name});this.field=this.node.getField();e.addField(this.field);this.clear();this.appendForm(e);this.checkReadyToSave();BX.Landing.UI.Panel.Content.prototype.show.call(this);BX.Landing.UI.Panel.EditorPanel.getInstance().hide()}if(!!n&&(n instanceof BX.Landing.Block.Node.Text||n instanceof BX.Landing.UI.Field.Text)){this.range=this.contextDocument.getSelection().getRangeAt(0);this.node=n;this.textField=BX.Landing.UI.Field.BaseField.currentField;if(!!this.textField&&this.textField.isEditable()){this.node=this.textField}var t=this.range.cloneContents().querySelector("a");if(!t){t=l(this.range.startContainer,{tagName:"A"})}var i="";var a="";if(t){i=t.getAttribute("href");a=t.getAttribute("target")||"_self"}else{this.title.innerHTML=BX.Landing.Loc.getMessage("LANDING_CREATE_LINK")}e=new BX.Landing.UI.Form.BaseForm({title:""});BX.remove(e.header);var s=[BX.Landing.UI.Field.LinkUrl.TYPE_BLOCK,BX.Landing.UI.Field.LinkUrl.TYPE_PAGE];if(BX.Landing.Main.getInstance().options.params.type==="STORE"){s.push(BX.Landing.UI.Field.LinkUrl.TYPE_CATALOG)}this.field=new BX.Landing.UI.Field.Link({title:BX.Landing.Loc.getMessage("FIELD_LINK_TEXT_LABEL"),content:{text:d(o(t?t.innerText:this.range.toString())),href:o(i),target:o(a)},options:{siteId:BX.Landing.Main.getInstance().options.site_id,landingId:BX.Landing.Main.getInstance().id,filter:{"=TYPE":BX.Landing.Main.getInstance().options.params.type}},allowedTypes:s});e.addField(this.field);this.clear();this.appendForm(e);this.checkReadyToSave();BX.Landing.UI.Panel.Content.prototype.show.call(this)}},save:function(){if(this.field.isChanged()){if(!!this.node&&this.node instanceof BX.Landing.Block.Node.Link){this.node.setValue(this.field.getValue())}else{var d=this.field.getValue();this.contextDocument.getSelection().removeAllRanges();this.contextDocument.getSelection().addRange(this.range);this.node.enableEdit();var l=o(e(d.href,t()));var g=this.contextDocument.getSelection();this.contextDocument.execCommand("createLink",false,l);var r=g.anchorNode.parentElement.parentElement.parentElement.querySelector(e('[href="',l,'"]'));if(r){n(r,"href",d.href);n(r,"target",d.target);if(s(d.text)){if(d.text.includes("{{name}}")){this.field.hrefInput.getPlaceholderData(d.href).then(function(n){r.innerHTML=d.text.replace(new RegExp("{{name}}"),'<span data-placeholder="name">'+n.name+"</span>")}.bind(this))}else{i(r,d.text)}}if(a(d.attrs)){n(r,d.attrs)}}}}this.hide()}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:69:"/bitrix/js/landing/ui/panel/google_fonts_panel.min.js?170811504913021";s:6:"source";s:49:"/bitrix/js/landing/ui/panel/google_fonts_panel.js";s:3:"min";s:53:"/bitrix/js/landing/ui/panel/google_fonts_panel.min.js";s:3:"map";s:53:"/bitrix/js/landing/ui/panel/google_fonts_panel.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Panel");var e=BX.Landing.Utils.addClass;var t=BX.Landing.Utils.proxy;var n=BX.Landing.Utils.append;var i=BX.Landing.Utils.slice;var s=BX.Landing.Utils.clone;var a=BX.Landing.Utils.bind;var o=["A red flare silhouetted the jagged edge of a wing","I watched the storm, so beautiful yet terrific","Almost before we knew it, we had left the ground","Waves flung themselves at the blue evening","A shining crescent far beneath the flying vessel"];var r=["&#x0423;&#x0442;&#x0440;&#x0435;&#x043D;&#x043D;&#x0435;&#x0435; &#x0441;&#x043E;&#x043B;&#x043D;&#x0446;&#x0435; &#x044F;&#x0440;&#x043A;&#x043E; &#x043E;&#x0441;&#x0432;&#x0435;&#x0442;&#x0438;&#x043B;&#x043E; &#x043F;&#x043E;&#x043B;&#x044F;&#x043D;&#x0443; &#x0438; &#x043B;&#x0435;&#x0441;","&#x041F;&#x0440;&#x0438;&#x043B;&#x0435;&#x0442;&#x0435;&#x0432;&#x0448;&#x0438;&#x0435; &#x043F;&#x0442;&#x0438;&#x0446;&#x044B; &#x0437;&#x0430;&#x043D;&#x044F;&#x043B;&#x0438; &#x0432;&#x0435;&#x0441;&#x044C; &#x0441;&#x043A;&#x0430;&#x043B;&#x0438;&#x0441;&#x0442;&#x044B;&#x0439; &#x0431;&#x0435;&#x0440;&#x0435;&#x0433;","&#x0411;&#x043E;&#x0434;&#x0440;&#x044F;&#x0449;&#x0438;&#x0439; &#x043C;&#x043E;&#x0440;&#x0441;&#x043A;&#x043E;&#x0439; &#x0432;&#x043E;&#x0437;&#x0434;&#x0443;&#x0445; &#x0431;&#x044B;&#x043B; &#x043F;&#x0440;&#x043E;&#x0445;&#x043B;&#x0430;&#x0434;&#x0435;&#x043D; &#x0438; &#x0441;&#x0432;&#x0435;&#x0436;","&#x042D;&#x0442;&#x043E; &#x043B;&#x0443;&#x0447;&#x0448;&#x0435;&#x0435;, &#x0447;&#x0442;&#x043E; &#x043C;&#x043E;&#x0433;&#x043B;&#x043E; &#x0441; &#x043D;&#x0438;&#x043C; &#x043F;&#x0440;&#x043E;&#x0438;&#x0437;&#x043E;&#x0439;&#x0442;&#x0438; &#x0432; &#x043D;&#x043E;&#x0432;&#x043E;&#x043C; &#x0433;&#x043E;&#x0440;&#x043E;&#x0434;&#x0435;","&#x041D;&#x043E;&#x0432;&#x0430;&#x044F; &#x043A;&#x043D;&#x0438;&#x0433;&#x0430; &#x043E;&#x043A;&#x0430;&#x0437;&#x0430;&#x043B;&#x0430;&#x0441;&#x044C; &#x0438;&#x043D;&#x0442;&#x0435;&#x0440;&#x0435;&#x0441;&#x043D;&#x043E;&#x0439; &#x0438; &#x043F;&#x043E;&#x0437;&#x043D;&#x0430;&#x0432;&#x0430;&#x0442;&#x0435;&#x043B;&#x044C;&#x043D;&#x043E;&#x0439;"];var l="&#1576;&#1591;&#1575;&#1576;&#1593; &#1571;&#1581;&#1605;&#1585; &#1575;&#1585;&#1578;&#1587;&#1605;&#1578; &#1589;&#1608;&#1585;&#1577; &#1592;&#1604;&#1610;&#1617;&#1577; &#1604;&#1581;&#1583;&#1608;&#1583; &#1575;&#1604;&#1580;&#1606;&#1575;&#1581; &#1575;&#1604;&#1605;&#1587;&#1606;&#1606;&#1577;.";var h="&#1492;&#1496;&#1489;&#1506; &#1492;&#1488;&#1495;&#1491; &#1513;&#1500;&#1497; &#1493;&#1492;&#1496;&#1489;&#1506; &#1492;&#1488;&#1495;&#1512; &#1495;&#1500;&#1511;&#1493; &#1494;&#1497;&#1499;&#1512;&#1493;&#1503; &#1502;&#1513;&#1493;&#1514;&#1507;.";var u="&#45208;&#45716; &#54253;&#54413;&#51012; &#51648;&#53020;&#48372;&#50520;&#45796;. &#45320;&#47924;&#45208; &#50500;&#47492;&#45796;&#50864;&#47732;&#49436;&#46020; &#50628;&#52397;&#45212; &#54253;&#54413;&#51012;.";var g=new WeakSet;BX.Landing.UI.Panel.GoogleFonts=function(){BX.Landing.UI.Panel.Content.apply(this,["google-fonts-panel",{title:BX.Landing.Loc.getMessage("LANDING_GOOGLE_FONT_PANEL_TITLE")}]);this.pangramIndex=-1;e(this.layout,"landing-ui-panel-google-fonts");e(this.overlay,"landing-ui-panel-google-fonts-overlay");this.client=new BX.Landing.Client.GoogleFonts;var t=BX.Landing.PageObject.getRootWindow();var i=t.document.body.querySelector(".landing-ui-view-container");n(this.layout,i);n(this.overlay,i);this.searchForm=this.createSearchForm();this.categoryForm=this.createCategoryForm();this.languageForm=this.createLanguageForm();n(this.searchForm.layout,this.sidebar);n(this.categoryForm.layout,this.sidebar);n(this.languageForm.layout,this.sidebar);n(this.createListLayout(),this.content);n(this.createPaginationLayout(),this.content);BX.Event.bind(this.getMoreButton(),"click",this.onMoreButtonClick.bind(this))};BX.Landing.UI.Panel.GoogleFonts.getInstance=function(){return BX.Landing.UI.Panel.GoogleFonts.instance||(BX.Landing.UI.Panel.GoogleFonts.instance=new BX.Landing.UI.Panel.GoogleFonts)};BX.Landing.UI.Panel.GoogleFonts.prototype={constructor:BX.Landing.UI.Panel.GoogleFonts,__proto__:BX.Landing.UI.Panel.Content.prototype,superclass:BX.Landing.UI.Panel.Content.prototype,createListLayout:function(){return BX.Dom.create({tag:"div",props:{classList:"landing-ui-panel-fonts-list"}})},getListLayout:function(){return this.content.querySelector(".landing-ui-panel-fonts-list")},createPaginationLayout:function(){return BX.Dom.create({tag:"div",props:{classList:"landing-ui-panel-fonts-pagination"},children:[BX.Dom.create({tag:"span",props:{className:"ui-btn ui-btn-lg ui-btn-light-border"},text:BX.Landing.Loc.getMessage("LANDING_FONTS_PANEL_MORE_BUTTON_LABEL")})]})},getMoreButton:function(){return this.getPaginationLayout().querySelector(".ui-btn")},getPaginationLayout:function(){return this.content.querySelector(".landing-ui-panel-fonts-pagination")},show:function(e){var n=this.superclass.show.call(this);n.then(function(){this.searchForm.fields[0].enableEdit();this.searchForm.fields[0].input.focus()}.bind(this));if(this.isFontsLoaded()){return n.then(t(this.saveResolver,this))}if(e){if(e["hideOverlay"]){this.overlay.style.display="none"}if(e["context"]){this.context=e["context"]}}this.page=0;BX.Dom.hide(this.getMoreButton());return n.then(function(){return this.showLoader()}.bind(this)).then(function(){return this.getFonts()}.bind(this)).then(function(e){return this.applyFilter(e)}.bind(this)).then(function(e){var t=this.paginateList(e);return this.loadFonts(t[this.page]||[])}.bind(this)).then(function(e){return this.renderList(e)}.bind(this)).then(function(){BX.Dom.show(this.getMoreButton());return this.hideLoader()}.bind(this)).then(function(){return this.saveResolver()}.bind(this))},onMoreButtonClick:function(e){e.preventDefault();this.page+=1;void this.showLoader();var t=this.getMoreButton();BX.Dom.addClass(t,"ui-btn-wait");BX.Dom.style(t,"pointer-events","none");var n=false;this.getFonts().then(function(e){return this.applyFilter(e)}.bind(this)).then(function(e){var t=this.paginateList(e);n=t.length-1<=this.page;return this.loadFonts(t[this.page]||[])}.bind(this)).then(function(e){return this.renderList(e)}.bind(this)).then(function(){BX.Dom.removeClass(this.getMoreButton(),"ui-btn-wait");BX.Dom.style(t,"pointer-events",null);if(n){BX.Dom.hide(t)}return this.hideLoader()}.bind(this))},saveResolver:function(){var e=this;return new Promise((function(t){e.resolver=t}))},getFonts:function(){if(this.response){return Promise.resolve(this.response)}return this.client.getList().then(t(this.saveResponse,this))},paginateList:function(e){var t=[];while(e.length){t.push(e.splice(0,21))}return t},saveResponse:function(e){return this.response=e},isFontsLoaded:function(){return!!this.response},showLoader:function(){if(!this.loader){this.loader=new BX.Loader({target:this.body,offset:{left:"134px",top:"-30px"}})}BX.Dom.style(this.sidebar,{transition:"200ms all ease",opacity:.8,"pointer-events":"none"});this.loader.show();return Promise.resolve()},hideLoader:function(){if(this.loader){this.loader.hide()}BX.Dom.style(this.sidebar,{transition:null,opacity:null,"pointer-events":null});return Promise.resolve()},loadFonts:function(e){var t;if(this.context){t=this.context}else{t=BX.Landing.PageObject.getRootWindow()}return new Promise((function(n){if(!BX.Type.isArrayFilled(e)){n(e)}else{WebFont.load({google:{families:e.map((function(e){return e.family.replace(/ /g,"+")}))},context:t,classes:false,active:function(){var t=BX.Landing.PageObject.getRootWindow();if(t.document.fonts){t.document.fonts.ready.then((function(){n(e)}))}else{setTimeout(n,3e3,e)}}})}}))},applyFilter:function(e){var t=this.searchForm.fields[0].getValue();var n=this.languageForm.fields[0].getValue();var i=this.categoryForm.fields[0].getValue();if(!BX.Type.isArrayFilled(i)){i=this.categoryForm.fields[0].items.map((function(e){return e.value}))}return e.filter((function(e){return n.every((function(t){return e.subsets.indexOf(t)!==-1}))&&i.some((function(t){return t===e.category}))&&(!BX.Type.isStringFilled(t)||String(e.family).toLowerCase().includes(String(t).toLowerCase()))}))},createListItem:function(e){var t=this.languageForm.fields[0].getValue();var n="";var i="ltr";var s="left";this.pangramIndex+=1;this.pangramIndex=this.pangramIndex>4?0:this.pangramIndex;if(t.includes("latin")){n=o[this.pangramIndex]}if(t.includes("cyrillic")){n=r[this.pangramIndex]}if(t.includes("arabic")){i="rtl";s="right";n=l}if(t.includes("hebrew")){i="rtl";s="right";n=h}if(t.includes("korean")){n=u}return'<div class="landing-ui-font-preview">'+'<div class="landing-ui-font-preview-font-name">'+e.family+"</div>"+'<div class="landing-ui-font-preview-font-button">'+'<span class="ui-btn ui-btn-xs ui-btn-light-border ui-btn-round">'+BX.Landing.Loc.getMessage("LANDING_GOOGLE_FONT_SELECT_BUTTON")+"</span>"+"</div>"+'<div style="font-family: '+e.family+"; direction: "+i+"; text-align: "+s+';" class="landing-ui-font-preview-pangram" contenteditable="true" onpaste="return false;">'+n+"</div>"+"</div>"},onFilterChange:function(){void this.showLoader();this.page=0;var e=false;this.getFonts().then(function(e){return this.applyFilter(e)}.bind(this)).then(function(t){var n=this.paginateList(t);e=n.length<=1;return this.loadFonts(n[this.page]||[])}.bind(this)).then(function(t){this.content.scrollTop=0;void this.hideLoader();if(e){BX.Dom.hide(this.getMoreButton())}else{BX.Dom.show(this.getMoreButton())}return this.renderList(t,true)}.bind(this))},renderList:function(e,t){return this.renderItems(e,t)},renderItems:function(e,t){if(!t){this.getListLayout().insertAdjacentHTML("beforeend",e.map(this.createListItem,this).join(""))}else{if(!BX.Type.isArrayFilled(e)&&BX.Type.isStringFilled(this.searchForm.fields[0].getValue())){this.getListLayout().innerHTML="";BX.Dom.append(this.getEmptyStub(),this.getListLayout())}else{this.getListLayout().innerHTML=e.map(this.createListItem,this).join("")}}i(this.getListLayout().children).forEach(this.initItem(e),this)},getEmptyStub:function(){return BX.Dom.create({tag:"div",props:{className:"landing-ui-fonts-panel-empty-stub"},text:BX.Landing.Loc.getMessage("LANDING_FONTS_PANEL_EMPTY_STUB")})},initItem:function(e){return function(t,n){if(!g.has(t)){const a=t.querySelector(".landing-ui-font-preview-font-button");BX.Event.bind(a,"click",this.onFontSelect.bind(this,e[n-this.page*21]));g.add(t);var i=t.querySelector(".landing-ui-font-preview-pangram");if(i){var s=i.innerText;BX.Event.bind(i,"blur",(function(){if(!BX.Type.isStringFilled(i.innerText)){i.innerText=s}}))}}}},getListItems:function(){return i(this.content.querySelectorAll(".landing-ui-font-preview.cell"))},createSearchForm:function(){var e=BX.Runtime.debounce(this.onFilterChange,500,this);return new BX.Landing.UI.Form.StyleForm({title:BX.Landing.Loc.getMessage("LANDING_GOOGLE_FONT_SEARCH_TITLE"),fields:[new BX.Landing.UI.Field.Text({selector:"searchQuery",textOnly:true,onValueChange:function(){void this.showLoader();e()}.bind(this),placeholder:BX.Loc.getMessage("LANDING_GOOGLE_FONT_SEARCH_PLACEHOLDER")})]})},createLanguageForm:function(){var e=new BX.Landing.UI.Form.StyleForm({title:BX.Landing.Loc.getMessage("LANDING_GOOGLE_FONT_PANEL_LANGUAGE_FORM_TITLE")});var n=new BX.Landing.UI.Factory.FieldFactory({onValueChange:t(this.onFilterChange,this)});var i=window.location.host.includes(".ru");e.addField(n.create({type:"radio",items:[{name:BX.Landing.Loc.getMessage("LANDING_GOOGLE_FONT_PANEL_LANGUAGE_CYRILLIC"),value:"cyrillic",checked:i},{name:BX.Landing.Loc.getMessage("LANDING_GOOGLE_FONT_PANEL_LANGUAGE_LATIN"),value:"latin",checked:!i},{name:BX.Landing.Loc.getMessage("LANDING_GOOGLE_FONT_PANEL_LANGUAGE_ARABIC"),value:"arabic"},{name:BX.Landing.Loc.getMessage("LANDING_GOOGLE_FONT_PANEL_LANGUAGE_HEBREW"),value:"hebrew"},{name:BX.Landing.Loc.getMessage("LANDING_GOOGLE_FONT_PANEL_LANGUAGE_KOREAN"),value:"korean"}]}));return e},createCategoryForm:function(){var e=new BX.Landing.UI.Form.StyleForm({title:BX.Landing.Loc.getMessage("LANDING_GOOGLE_FONT_PANEL_CATEGORY_FORM_TITLE")});var n=new BX.Landing.UI.Factory.FieldFactory({onValueChange:t(this.onFilterChange,this)});e.addField(n.create({type:"checkbox",items:[{name:BX.Landing.Loc.getMessage("LANDING_GOOGLE_FONT_PANEL_CATEGORY_SANS_SERIF_2"),value:"sans-serif"},{name:BX.Landing.Loc.getMessage("LANDING_GOOGLE_FONT_PANEL_CATEGORY_SERIF_2"),value:"serif"},{name:BX.Landing.Loc.getMessage("LANDING_GOOGLE_FONT_PANEL_CATEGORY_DISPLAY"),value:"display"},{name:BX.Landing.Loc.getMessage("LANDING_GOOGLE_FONT_PANEL_CATEGORY_HANDWRITING"),value:"handwriting"},{name:BX.Landing.Loc.getMessage("LANDING_GOOGLE_FONT_PANEL_CATEGORY_MONOSPACE"),value:"monospace"}]}));return e},onFontSelect:function(e){this.selectedFont=e;this.onApply()},onApply:function(){if(this.resolver){var e=s(this.selectedFont);e.subset=this.languageForm.fields[0].getValue();this.hide().then(this.resolver.bind(null,e))}},onCancel:function(){this.hide()}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:78:"/bitrix/js/landing/ui/panel/google_images_settings_panel.min.js?17081150492137";s:6:"source";s:59:"/bitrix/js/landing/ui/panel/google_images_settings_panel.js";s:3:"min";s:63:"/bitrix/js/landing/ui/panel/google_images_settings_panel.min.js";s:3:"map";s:63:"/bitrix/js/landing/ui/panel/google_images_settings_panel.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Panel");BX.Landing.UI.Panel.GoogleImagesSettings=function(){BX.Landing.UI.Panel.Content.apply(this,["google_images_settings",{title:BX.Landing.Loc.getMessage("LANDING_GOOGLE_IMAGES_KEY_PANEL_TITLE"),footer:[new BX.Landing.UI.Button.BaseButton("save_block_content",{text:BX.Landing.Loc.getMessage("BLOCK_SAVE"),onClick:this.onSaveClick.bind(this),className:"landing-ui-button-content-save",attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_SLIDER_SAVE")}}),new BX.Landing.UI.Button.BaseButton("cancel_block_content",{text:BX.Landing.Loc.getMessage("BLOCK_CANCEL"),onClick:this.onCancelClick.bind(this),className:"landing-ui-button-content-cancel",attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_SLIDER_CANCEL")}})]}]);this.layout.style.width="496px";this.layout.style.zIndex="600";this.overlay.style.zIndex="599";this.settingsForm=new BX.Landing.UI.Form.BaseForm;this.keyField=new BX.Landing.UI.Field.Text({title:BX.Landing.Loc.getMessage("LANDING_GOOGLE_IMAGES_KEY_FIELD_TITLE"),textOnly:true,description:BX.Landing.Loc.getMessage("LANDING_GOOGLE_IMAGES_GET_KEY_GUIDE"),content:BX.Landing.Client.Google.key});this.settingsForm.addField(this.keyField);this.appendForm(this.settingsForm);document.body.appendChild(this.layout)};BX.Landing.UI.Panel.GoogleImagesSettings.getInstance=function(){return BX.Landing.UI.Panel.GoogleImagesSettings.instance||(BX.Landing.UI.Panel.GoogleImagesSettings.instance=new BX.Landing.UI.Panel.GoogleImagesSettings)};BX.Landing.UI.Panel.GoogleImagesSettings.prototype={constructor:BX.Landing.UI.Panel.GoogleImagesSettings,__proto__:BX.Landing.UI.Panel.Content.prototype,superclass:BX.Landing.UI.Panel.Content.prototype,show:function(){this.superclass.show.call(this);return new Promise(function(n){this.resolver=n}.bind(this))},onSaveClick:function(){var n=this.keyField.getValue();this.resolver(n);BX.Landing.Backend.getInstance().action("Utils::saveSettings",{settings:{google_images_key:n}});BX.Landing.Client.Google.key=n;this.hide()},onCancelClick:function(){this.hide()}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:60:"/bitrix/js/landing/ui/panel/catalog_panel.js?170811504911032";s:6:"source";s:44:"/bitrix/js/landing/ui/panel/catalog_panel.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
;(function() {
	"use strict";

	BX.namespace("BX.Landing.UI.Panel");

	var addClass = BX.Landing.Utils.addClass;
	var create = BX.Landing.Utils.create;
	var append = BX.Landing.Utils.append;
	var debounce = BX.Landing.Utils.debounce;
	var trim = BX.Landing.Utils.trim;
	var bind = BX.Landing.Utils.bind;
	var proxy = BX.Landing.Utils.proxy;
	var setTextContent = BX.Landing.Utils.setTextContent;
	var htmlToElement = BX.Landing.Utils.htmlToElement;
	var remove = BX.Landing.Utils.remove;
	var style = BX.Landing.Utils.style;
	var isArray = BX.Landing.Utils.isArray;
	var prepend = BX.Landing.Utils.prepend;
	var data = BX.Landing.Utils.data;
	var encodeDataValue = BX.Landing.Utils.encodeDataValue;

	var TYPE_CATALOG_SECTION = "section";
	var TYPE_CATALOG_ELEMENT = "element";
	var TYPE_CATALOG_ALL = "all";


	/**
	 * Implements interface for works with catalog panel
	 * @extends {BX.Landing.UI.Panel.Content}
	 * @param {string} id
	 * @constructor
	 */
	BX.Landing.UI.Panel.Catalog = function(id)
	{
		BX.Landing.UI.Panel.Content.apply(this, arguments);

		this.searchContainer = this.createSearchContainer();
		this.listContainer = this.createListContainer();
		this.searchField = this.createSearchField();
		this.typeSwitcher = this.createTypeSwitcher();
		this.iBlockSwitcher = this.createIblockSwitcher();
		this.resolver = (function() {});
		this.iblocks = null;

		addClass(this.layout, "landing-ui-panel-catalog");
		addClass(this.overlay, "landing-ui-panel-catalog");
		setTextContent(this.title, BX.Landing.Loc.getMessage("LANDING_STYLE_PANEL_CATALOG_TITLE"));

		if (!this.getIblocks() || this.getIblocks().length > 1)
		{
			append(this.iBlockSwitcher.layout, this.searchContainer);
		}
		else
		{
			void style(this.listContainer, {
				"margin-top": "94px"
			});
		}

		append(this.searchField.layout, this.searchContainer);
		append(this.typeSwitcher.layout, this.searchContainer);
		append(this.searchContainer, this.content);
		append(this.listContainer, this.content);

		if (BX.Landing.Main.isExternalControlsEnabled())
		{
			append(this.layout, parent.document.body);
		}
		else
		{
			append(this.layout, document.body);
			this.layout.style.marginTop = 0;
			this.overlay.style.display = 'none';
		}
	};


	BX.Landing.UI.Panel.Catalog.TYPE_CATALOG_ALL = TYPE_CATALOG_ALL;
	BX.Landing.UI.Panel.Catalog.TYPE_CATALOG_SECTION = TYPE_CATALOG_SECTION;
	BX.Landing.UI.Panel.Catalog.TYPE_CATALOG_ELEMENT = TYPE_CATALOG_ELEMENT;


	/**
	 * Gets instance of BX.Landing.UI.Panel.Catalog
	 * @returns {BX.Landing.UI.Panel.Catalog}
	 */
	BX.Landing.UI.Panel.Catalog.getInstance = function()
	{
		return (
			BX.Landing.UI.Panel.Catalog.instance ||
			(BX.Landing.UI.Panel.Catalog.instance = new BX.Landing.UI.Panel.Catalog("catalog_panel"))
		);
	};


	BX.Landing.UI.Panel.Catalog.prototype = {
		constructor: BX.Landing.UI.Panel.Catalog,
		__proto__: BX.Landing.UI.Panel.Content.prototype,
		superClass: BX.Landing.UI.Panel.Content.prototype,

		/**
		 * Search catalog items
		 * @param {string} query
		 * @return {Promise<Object, Object>}
		 */
		search: function(query)
		{
			var requestData = {
				query: trim(query.replace("&nbsp;", "")),
				type: this.typeSwitcher.getValue(),
				iblock: this.iBlockSwitcher.getValue()
			};
			var queryParams = {action: "Utils::catalogSearch"};

			return BX.Landing.Backend.getInstance()
				.action("Utils::catalogSearch", requestData, queryParams);
		},


		/**
		 * Creates search type switcher
		 * @return {BX.Landing.UI.Field.ButtonGroup}
		 */
		createTypeSwitcher: function()
		{
			var typeSwitcher = new BX.Landing.UI.Field.ButtonGroup({
				items: [
					{"name": BX.Landing.Loc.getMessage("LANDING_STYLE_PANEL_CATALOG_SEARCH_TYPE_ALL"), value: TYPE_CATALOG_ALL},
					{"name": BX.Landing.Loc.getMessage("LANDING_STYLE_PANEL_CATALOG_SEARCH_TYPE_ELEMENTS"), value: TYPE_CATALOG_ELEMENT},
					{"name": BX.Landing.Loc.getMessage("LANDING_STYLE_PANEL_CATALOG_SEARCH_TYPE_SECTIONS"), value: TYPE_CATALOG_SECTION}
				],
				content: TYPE_CATALOG_ALL,
				onChange: this.onSearchTypeChange.bind(this)
			});

			addClass(typeSwitcher.layout, "landing-ui-panel-catalog-switch");

			return typeSwitcher;
		},


		/**
		 * Gets iblocks list
		 * @return {*[]}
		 */
		getIblocks: function()
		{
			if (isArray(this.iblocks))
			{
				return this.iblocks;
			}

			return [
				{name: "", value: ""}
			];
		},

		/**
		 * Gets iBlock switcher
		 * @return {BX.Landing.UI.Field.Dropdown}
		 */
		createIblockSwitcher: function()
		{
			var iBlockSwitcher = new BX.Landing.UI.Field.Dropdown({
				title: BX.Landing.Loc.getMessage("LANDING_STYLE_PANEL_CATALOG_IBLOCK_SWITCHER"),
				items: this.getIblocks(),
				content: isArray(this.getIblocks()) ? this.getIblocks()[0].value : "",
				onChange: this.onIblockChange.bind(this)
			});

			addClass(iBlockSwitcher.layout, "landing-ui-panel-catalog-iblock-switch");

			return iBlockSwitcher;
		},


		/**
		 * Handles iblock change event
		 */
		onIblockChange: function()
		{
			this.onSearch();
		},


		/**
		 * Creates search field
		 * @return {BX.Landing.UI.Field.Text}
		 */
		createSearchField: function()
		{
			return new BX.Landing.UI.Field.Text({
				placeholder: BX.Landing.Loc.getMessage("LANDING_STYLE_PANEL_CATALOG_SEARCH_PLACEHOLDER"),
				textOnly: true,
				onValueChange: debounce(this.onSearch, 200, this)
			});
		},


		/**
		 * Creates search container
		 * @return {HTMLElement}
		 */
		createSearchContainer: function()
		{
			return create("div", {
				props: {className: "landing-ui-panel-catalog-search-container"}
			});
		},


		/**
		 * Creates list container
		 * @return {HTMLElement}
		 */
		createListContainer: function()
		{
			return create("div", {
				props: {className: "landing-ui-panel-catalog-list-container"}
			});
		},


		/**
		 * Handles search type change event
		 */
		onSearchTypeChange: function()
		{
			this.onSearch();
		},


		/**
		 * Renders search response
		 * @param response
		 */
		renderResponse: function(response)
		{
			var oldResult = this.listContainer.querySelector(".landing-ui-panel-catalog-list");

			if (oldResult)
			{
				remove(oldResult);
			}

			this.body.scrollTop = 0;

			append(htmlToElement(
				"<div class=\"landing-ui-panel-catalog-list\">" +
					response.map(function(item) {
						if (item.subType === TYPE_CATALOG_SECTION && !item.image)
						{
							item.image = "/bitrix/images/landing/folder.svg";
						}

						var chain = item.chain.reduce(function(accumulator, chainItem) {
							if (chainItem)
							{
								accumulator.push(encodeDataValue(chainItem));
							}

							return accumulator;
						}, []);

						return (
							"<div class='landing-ui-panel-catalog-list-row landing-ui-panel-catalog-list-row-"+item.subType+"'>" +
								"<div class='landing-ui-panel-catalog-list-row-left'>" +
									"<div class='landing-ui-panel-catalog-list-cell-preview' style=\"background-image: url('"+item.image+"')\"></div>" +
								"</div>" +
								"<div class='landing-ui-panel-catalog-list-row-right'>" +
									"<div class='landing-ui-panel-catalog-list-cell-name'>" +
										"<div>"+encodeDataValue(item.name)+"</div>" +
									"</div>" +
									"<div class='landing-ui-panel-catalog-list-cell-chain'>" +
										"<div>"+(chain ? chain.join("&nbsp;/&nbsp;") : "")+"</div>" +
									"</div>" +
								"</div>" +
							"</div>"
						);
					}).join("") +
				"</div>"
			), this.listContainer);

			return response;
		},


		/**
		 * Initializes events handlers on items rendered from response
		 * @param {object[]} response
		 */
		initResponseItems: function(response)
		{
			var items = this.listContainer.querySelector(".landing-ui-panel-catalog-list");

			response.forEach(function(item, index) {
				bind(items.children[index], "click", this.onItemClick.bind(this, item));
			}, this);

			return response;
		},


		/**
		 * Shows catalog panel
		 * @param {?object[]} [iblocks]
		 * @param {?string[]} [entityTypes]
		 * @return {Promise<Object>}
		 */
		show: function(iblocks, entityTypes)
		{
			this.superClass.show.call(this);
			this.iblocks = iblocks || null;
			this.entityTypes = entityTypes;

			this.onSearch();
			this.adjustIblockSwitcher();
			this.adjustEntityTypes();
			this.adjustSearchPlaceholder();

			return new Promise(function(resolve) {
				this.resolver = resolve;
			}.bind(this));
		},


		adjustSearchPlaceholder: function()
		{
			var entityTypes = this.getEntityTypes();

			if (entityTypes.length === 1 && entityTypes[0] === TYPE_CATALOG_SECTION)
			{
				data(this.searchField.input, {
					"data-placeholder": BX.Landing.Loc.getMessage("LANDING_STYLE_PANEL_CATALOG_SEARCH_SECTION_PLACEHOLDER")
				})
			}
		},


		/**
		 * Gets catalog entity types
		 * @return {string[]}
		 */
		getEntityTypes: function()
		{
			if (isArray(this.entityTypes) && this.entityTypes.length > 0)
			{
				return this.entityTypes;
			}

			return [
				TYPE_CATALOG_ALL,
				TYPE_CATALOG_ELEMENT,
				TYPE_CATALOG_SECTION
			];
		},


		adjustEntityTypes: function()
		{
			this.typeSwitcher.buttons.forEach(function(button) {
				button.layout.hidden = !this.getEntityTypes().includes(button.id);
			}, this);

			this.typeSwitcher.setValue(this.getEntityTypes()[0]);
		},


		adjustIblockSwitcher: function()
		{
			remove(this.iBlockSwitcher.layout);
			this.iBlockSwitcher = this.createIblockSwitcher();
			prepend(this.iBlockSwitcher.layout, this.searchContainer);

			if (!this.getIblocks() || this.getIblocks().length < 2)
			{
				void style(this.iBlockSwitcher.layout, {
					display: "none"
				});

				void style(this.loaderContainer, {
					"top": "182px"
				});

				void style(this.listContainer, {
					"margin-top": "94px"
				});
			}
			else
			{
				void style(this.iBlockSwitcher.layout, {
					display: null
				});

				void style(this.loaderContainer, {
					"top": null
				});

				void style(this.listContainer, {
					"margin-top": null
				});
			}
		},


		/**
		 * Handles search event
		 */
		onSearch: function()
		{
			this.showLoader();

			clearTimeout(this.searchTimeout);
			this.searchTimeout = setTimeout(function() {
				this.search(this.searchField.getValue())
					.then(proxy(this.renderResponse, this))
					.then(proxy(this.initResponseItems, this))
					.then(function() {
						this.hideLoader();
					}.bind(this));
			}.bind(this), 500);
		},


		showLoader: function()
		{
			if (!this.loader)
			{
				this.loader = new BX.Loader({offset: {top: "-70px"}});
				this.loaderContainer = create("div", {
					props: {className: "landing-ui-panel-catalog-loader-container"},
					children: [this.loader.layout]
				});
				append(this.loaderContainer, this.listContainer);
				this.loader.show();
			}

			this.loaderContainer.hidden = false;
		},

		hideLoader: function()
		{
			if (this.loaderContainer)
			{
				this.loaderContainer.hidden = true;
			}
		},


		/**
		 * Handles item click event
		 * @param {object} item
		 */
		onItemClick: function(item)
		{
			this.resolver(item);
			this.hide();
		}
	};
})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:58:"/bitrix/js/landing/ui/panel/status_panel.js?17081150491915";s:6:"source";s:43:"/bitrix/js/landing/ui/panel/status_panel.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
;(function() {
	"use strict";

	BX.namespace("BX.Landing.UI.Panel");

	var addClass = BX.Landing.Utils.addClass;

	var statusInterval;
	var lastUpdate = new Date();
	var format = [
		["s" , "sago"],
		["i", "iago"],
		["H", "Hago"],
		["d", "dago"],
		["m100", "mago"],
		["m", "mago"]
	];

	BX.Landing.UI.Panel.StatusPanel = function(options)
	{
		BX.Landing.UI.Panel.BasePanel.apply(this, arguments);
		addClass(this.layout, "landing-ui-panel-status");

		if (!!document.body.querySelector('.landing-edit-mode'))
		{
			parent.document.body.appendChild(this.layout);
		}

		this.runInterval();
		this.updateTime();
	};

	BX.Landing.UI.Panel.StatusPanel.setLastModified = function(timestamp)
	{
		lastUpdate = new Date(timestamp * 1000);
	};

	BX.Landing.UI.Panel.StatusPanel.getInstance = function()
	{
		return (
			BX.Landing.UI.Panel.StatusPanel.instance ||
			(BX.Landing.UI.Panel.StatusPanel.instance = new BX.Landing.UI.Panel.StatusPanel())
		);
	};

	BX.Landing.UI.Panel.StatusPanel.prototype = {
		constructor: BX.Landing.UI.Panel.StatusPanel,
		__proto__: BX.Landing.UI.Panel.BasePanel.prototype,

		runInterval: function()
		{
			clearInterval(statusInterval);
			statusInterval = setInterval(this.updateTime.bind(this), (10 * 1000));
		},

		updateTime: function()
		{
			let lastUpdateTime = lastUpdate.getTime();
			let nowTime = (new Date()).getTime();

			if (lastUpdateTime > nowTime)
			{
				this.setContent(BX.Landing.Loc.getMessage("LANDING_PAGE_STATUS_UPDATED_NOW"));
				return;
			}

			this.setContent([
				BX.Landing.Loc.getMessage("LANDING_PAGE_STATUS_UPDATED"),
				BX.date.format(format, lastUpdateTime / 1000, nowTime / 1000)
			].join(" "));
		},

		update: function()
		{
			this.show()
				.then(function() {
					this.runInterval();
					lastUpdate = new Date();
					this.setContent(BX.Landing.Loc.getMessage("LANDING_PAGE_STATUS_UPDATED_NOW"));
				}.bind(this));
		}
	};
})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:67:"/bitrix/js/landing/ui/panel/detail_page_panel.min.js?17081150494359";s:6:"source";s:48:"/bitrix/js/landing/ui/panel/detail_page_panel.js";s:3:"min";s:52:"/bitrix/js/landing/ui/panel/detail_page_panel.min.js";s:3:"map";s:52:"/bitrix/js/landing/ui/panel/detail_page_panel.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Panel");BX.Landing.UI.Panel.DetailPage=function(n,e){BX.Landing.UI.Panel.URLList.apply(this,arguments);this.layout.classList.add("landing-ui-panel-detail-page");this.overlay.classList.add("landing-ui-panel-detail-page");this.cache=new BX.Cache.MemoryCache;document.body.appendChild(this.layout)};BX.Landing.UI.Panel.DetailPage.instance=null;BX.Landing.UI.Panel.DetailPage.getInstance=function(){if(!BX.Landing.UI.Panel.DetailPage.instance){BX.Landing.UI.Panel.DetailPage.instance=new BX.Landing.UI.Panel.DetailPage("detail_page_panel",{title:BX.Landing.Loc.getMessage("LANDING_BLOCK__DETAIL_PAGE_PANEL_TITLE")})}return BX.Landing.UI.Panel.DetailPage.instance};BX.Landing.UI.Panel.DetailPage.prototype={constructor:BX.Landing.UI.Panel.DetailPage,__proto__:BX.Landing.UI.Panel.URLList.prototype,getSources:function(){return this.cache.remember("sources",function(){var n=BX.Landing.PageObject.getRootWindow();return n.BX.Landing.Main.getInstance().options.sources})},onSourceClick:function(n){this.sidebarButtons.forEach(function(e){if(e.id===n.id){e.activate();return}e.deactivate()});this.content.innerHTML="";this.showLoader();this.content.appendChild(BX.create("div",{props:{className:"ui-alert ui-alert-warning landing-ui-panel-list-description"},children:[BX.create("span",{props:{className:"ui-alert-message"},html:BX.Landing.Loc.getMessage("LANDING_BLOCK__DETAIL_PAGE_LIST_DESCRIPTION")})]}));BX.Landing.Backend.getInstance().getDynamicTemplates(n.id).then(function(n){n.forEach(function(n){this.appendCard(this.createTemplatePreview(n))},this);this.loader.hide()}.bind(this))},createTemplatePreview:function(n){return new BX.Landing.UI.Card.LandingPreviewCard({title:n.TITLE,description:n.DESCRIPTION,preview:n.PREVIEW2X,onClick:this.onTemplateClick.bind(this,n)})},onTemplateClick:function(n){this.loader.show();var e=BX.Landing.Backend.getInstance();e.action("Utils::checkMultiFeature",{code:["create_page","publication_page"]}).then(function(t){if(!t||t==="false"){var i=BX.Landing.PageObject.getRootWindow();i.BX.Landing.PaymentAlertShow({message:BX.Landing.Loc.getMessage("LANDING_PUBLIC_PAGE_REACHED")});this.loader.hide()}else{e.action("Landing::addByTemplate",{siteId:e.getSiteId(),code:n.ID,fields:{ID:e.getLandingId()}}).then(function(e){this.loader.hide();this.onChange({type:"landing",id:e,name:n.TITLE});var t=this.sidebarButtons.getActive();if(t){var i=t.id;var a=BX.Landing.Env.getInstance();var s=a.getOptions();var o=s.sources.find(function(n){return n.id===i});if(o){o.default.detail="#landing"+e}a.setOptions(s)}}.bind(this))}}.bind(this))},showSourcesButtons:function(){this.appendSidebarButton(new BX.Landing.UI.Button.SidebarButton("templates",{text:BX.Landing.Loc.getMessage("LANDING_BLOCK__DETAIL_PAGE_PANEL_TEMPLATES")}));this.getSources().forEach(function(n){if(n.settings.detailPage){this.appendSidebarButton(new BX.Landing.UI.Button.SidebarButton(n.id,{text:n.name,child:true,onClick:this.onSourceClick.bind(this,n)}))}},this)},showSitesButtons:function(){this.appendSidebarButton(new BX.Landing.UI.Button.SidebarButton("my_sites",{text:BX.Landing.Loc.getMessage("LANDING_LINKS_PANEL_MY_SITES")}));return BX.Landing.Backend.getInstance().getSites().then(function(n){n.forEach(function(n){this.appendSidebarButton(new BX.Landing.UI.Button.SidebarButton(n.ID,{text:n.TITLE,onClick:this.onSiteClick.bind(this,n.ID,false),child:true}))},this)}.bind(this))},showCreatePageButton:function(){this.appendSidebarButton(new BX.Landing.UI.Button.SidebarButton("feedback_button",{className:"landing-ui-button-sidebar-feedback",text:BX.Landing.Loc.getMessage("LANDING_BLOCK__DETAIL_PAGE_PANEL_ADD_PAGE_BUTTON"),onClick:function(){var n=BX.Landing.Main.getInstance().options;var e=n.params.sef_url.site_show;var t=n.site_id;var i=e.replace("#site_show#",t)+"#createPage";window.open(i,"_blank")}}))},buildSidebar:function(){return Promise.all([this.showSourcesButtons(),this.showSitesButtons().then(function(){this.showCreatePageButton()}.bind(this))])},show:function(n){BX.Landing.UI.Panel.Content.prototype.show.call(this);this.clear();this.showLoader();this.buildSidebar();var e=this.sidebarButtons.find(function(e){return e.id===n.source});if(e){e.layout.click()}return new Promise(function(n){this.promiseResolve=n}.bind(this))}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:64:"/bitrix/js/landing/ui/field/dropdown_field.min.js?17081150494296";s:6:"source";s:45:"/bitrix/js/landing/ui/field/dropdown_field.js";s:3:"min";s:49:"/bitrix/js/landing/ui/field/dropdown_field.min.js";s:3:"map";s:49:"/bitrix/js/landing/ui/field/dropdown_field.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Field");var t=BX.Landing.Utils.setTextContent;var i=BX.Landing.Utils.escapeText;var e=BX.Landing.Utils.data;var n=BX.Landing.Utils.offsetTop;var s=BX.Landing.Utils.offsetLeft;BX.Landing.UI.Field.Dropdown=function(i){this.items="items"in i&&i.items?i.items:{};BX.Landing.UI.Field.BaseField.apply(this,arguments);this.setEventNamespace("BX.Landing.UI.Field.Dropdown");this.subscribeFromOptions(BX.Landing.UI.Component.fetchEventsFromOptions(i));this.onChangeHandler=typeof i.onChange==="function"?i.onChange:function(){};this.frame=typeof i.frame==="object"?i.frame:null;this.layout.classList.add("landing-ui-field-dropdown");this.popup=null;this.input.addEventListener("click",this.onInputClick.bind(this));this.classForTextNode=i.classForTextNode;document.addEventListener("click",this.onDocumentClick.bind(this));var n=BX.Landing.PageObject.getRootWindow();n.document.addEventListener("click",this.onDocumentClick.bind(this));if(i.hint){var s=this.layout.querySelector(".landing-ui-field-header");if(s){BX.Dom.append(top.BX.UI.Hint.createNode(i.hint),s)}}if(BX.type.isPlainObject(this.items)){var o=Object.keys(this.items);this.items=o.map((function(t){return{name:this.items[t],value:t}}),this)}if(BX.Type.isArrayFilled(this.items)){t(this.input,this.items[0].name,this.classForTextNode);e(this.input,"value",this.items[0].value)}else{t(this.input,BX.Landing.Loc.getMessage("LANDING_DROPDOWN_NOT_FILLED"));e(this.input,"value","")}if(this.content!==""){setTimeout((()=>{this.emit("onInit",this.items[this.content])}),0);this.setValue(this.content)}};BX.Landing.UI.Field.Dropdown.prototype={constructor:BX.Landing.UI.Field.Dropdown,__proto__:BX.Landing.UI.Field.BaseField.prototype,onInputClick:function(t){t.stopPropagation();if(!this.popup||!this.contentRoot&&this.popupRoot&&!this.popupRoot.contains(this.popup.popupWindow.popupContainer)){var e=[];this.items.forEach((function(t){if(t.hidden!==true){e.push(t)}}));var o;if(this.options.maxHeight){o=this.options.maxHeight}else{o=196}e=e.map((function(t){if(t.delimiter){return{delimiter:t.delimiter}}return{html:t.html,text:!t.html?i(t.name):undefined,onclick:function(){this.onItemClick(t)}.bind(this),className:t.className}}),this);this.popup=new BX.PopupMenuWindow({id:"dropdown_"+ +new Date,bindElement:this.input,bindOptions:{forceBindPosition:true},targetContainer:this.contentRoot,maxHeight:o,items:e,events:{onPopupClose:function(){this.input.classList.remove("landing-ui-active");this.layout.classList.remove("landing-ui-active")}.bind(this)},className:this.options.className,angle:true});if(!this.contentRoot){this.popupRoot=this.layout.parentElement.parentElement.parentElement;this.popupRoot.appendChild(this.popup.popupWindow.popupContainer);this.popupRoot.style.position="relative"}}this.layout.classList.add("landing-ui-active");this.input.classList.add("landing-ui-active");if(this.popup.popupWindow.isShown()){this.popup.close()}else{this.popup.show()}var p=this.input.getBoundingClientRect();if(!this.contentRoot){var a=s(this.input,this.popupRoot);var u=n(this.input,this.popupRoot);this.popup.popupWindow.popupContainer.style.top=u+p.height+"px";this.popup.popupWindow.popupContainer.style.left=a+"px"}this.popup.popupWindow.popupContainer.style.width=p.width+"px"},onItemClick:function(i){t(this.input,i.name,this.classForTextNode);e(this.input,"value",i.value);this.popup.close();this.onChangeHandler(i.value,this.items,this.postfix,this.property);this.onValueChangeHandler(this);BX.fireEvent(this.input,"input");this.emit("onChange",i)},getValue:function(){var t=this.input.dataset.value;if(t!=="undefined"&&typeof t!=="undefined"){return t}if(BX.Type.isArrayFilled(this.items)){return this.items[0].value}},setValue:function(i,n){this.items.forEach((function(s){if(i==s.value){t(this.input,s.name,this.classForTextNode);e(this.input,"value",s.value);if(n){setTimeout((()=>{this.emit("onInit",s)}),0)}}}),this)},onFrameLoad:function(){const t=this.frame.document.querySelector(this.selector);if(t){const i=this.items.find((i=>t.classList.contains(i.value)));if(i){this.setValue(i.value,true)}}},isChanged:function(){return this.content!=this.getValue()},onDocumentClick:function(){if(this.popup){this.popup.close()}}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:72:"/bitrix/js/landing/ui/field/dropdown_preview_field.min.js?17081150492746";s:6:"source";s:53:"/bitrix/js/landing/ui/field/dropdown_preview_field.js";s:3:"min";s:57:"/bitrix/js/landing/ui/field/dropdown_preview_field.min.js";s:3:"map";s:57:"/bitrix/js/landing/ui/field/dropdown_preview_field.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Field");BX.Landing.UI.Field.DropdownPreview=function(i){this.items="items"in i&&i.items?i.items:{};BX.Landing.UI.Field.BaseField.apply(this,arguments);this.layout.classList.add("landing-ui-field-dropdown");this.layout.classList.add("landing-ui-field-dropdown-preview");this.frame=typeof i.frame==="object"?i.frame:null;this.format=typeof i.format==="function"?i.format:function(){};this.postfix=typeof i.postfix==="string"?i.postfix:"";this.property=typeof i.property==="string"?i.property:"";this.changeHandler=typeof i.onChange==="function"?i.onChange:function(){};this.elements=[];this.setValue(this.items[0].value,true);this.input.innerText=this.items[0].name;this.input.addEventListener("click",this.onInputClick.bind(this));this.onFrameLoad()};BX.Landing.UI.Field.DropdownPreview.CreateSelect=function(){return BX.create("select",{props:{className:"landing-ui-field-input landing-ui-field-dropdown"}})};BX.Landing.UI.Field.DropdownPreview.prototype={constructor:BX.Landing.UI.Field.DropdownPreview,__proto__:BX.Landing.UI.Field.BaseField.prototype,superClass:BX.Landing.UI.Field.BaseField,onInputClick:function(i){i.preventDefault();if(!this.popup){var t=this;var e=this.items.map(function(i){return{text:i.name,className:"landing-ui-field-dropdown-preview-item",menuShowDelay:0,subMenuOffsetX:10,items:[{text:'<div class="landing-ui-field-dropdown-preview-item-preview '+i.value+'">Text</div>',className:"landing-ui-field-dropdown-preview-item-child"}],onclick:function(){this.close();t.onChange(i)}}});this.popup=new BX.PopupMenuWindow({id:this.selector+this.property,bindElement:this.input,items:e,zIndex:9e3,angle:false,bindOptions:{forceBindPosition:true},events:{onPopupClose:function(){this.input.classList.remove("landing-ui-active")}.bind(this)}});this.input.parentNode.appendChild(this.popup.popupWindow.popupContainer)}this.input.classList.add("landing-ui-active");var n=BX.pos(this.input,this.input.parentNode);this.popup.popupWindow.popupContainer.style.top=n.bottom+"px";this.popup.popupWindow.popupContainer.style.left="0px";this.popup.popupWindow.popupContainer.style.right=""},onFrameLoad:function(){this.elements=[].slice.call(this.frame.document.querySelectorAll(this.selector));if(this.elements.length){this.items.some(function(i){if(this.elements[0].classList.contains(i.value)){this.setValue(i.value,true)}},this)}},onChange:function(i,t){this.setValue(i.value);this.input.innerText=i.name;if(!t){this.changeHandler(this.getValue(),this.items,this.postfix,this.property);BX.fireEvent(this.layout,"input")}},setValue:function(i){this.input.dataset.value=i},getValue:function(){return this.input.dataset.value}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:60:"/bitrix/js/landing/ui/field/unit_field.min.js?17081150492463";s:6:"source";s:41:"/bitrix/js/landing/ui/field/unit_field.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Field");BX.Landing.UI.Field.Unit=function(t){BX.Landing.UI.Field.Text.apply(this,arguments);this.layout.classList.add("landing-ui-field-unit");this.unit=BX.Landing.UI.Field.Unit.createUnit();this.onInputHandler=typeof t.onInput==="function"?t.onInput:function(){};this.input.addEventListener("keydown",this.onInputKeydown.bind(this));this.input.addEventListener("input",BX.debounce(this.onInputInput,200,this));this.input.addEventListener("input",this.onInputInputWithoutDebounce.bind(this));this.input.value=t.content;this.input.placeholder=this.placeholder;this.items=t.items;this.unit.innerText=typeof t.unit==="string"?t.unit:"";this.input.min=typeof t.min==="number"?t.min:0;this.input.max=typeof t.max==="number"?t.max:Infinity;this.input.step=typeof t.step==="number"?t.step:1;this.frame=typeof t.frame==="object"?t.frame:null;this.selector=typeof t.selector==="string"?t.selector:null;this.property=typeof t.property==="string"?t.property:null;this.postfix=typeof t.postfix==="string"?t.postfix:"";this.format=typeof t.format==="function"?t.format:function(){};this.elements=null;if(this.frame){this.onFrameLoad()}this.layout.appendChild(this.unit);this.enableTextOnly()};BX.Landing.UI.Field.Unit.createUnit=function(){return BX.create("div",{props:{className:"landing-ui-field-unit-unit"}})};BX.Landing.UI.Field.Unit.prototype={constructor:BX.Landing.UI.Field.Unit,__proto__:BX.Landing.UI.Field.Text.prototype,onFrameLoad:function(){this.elements=[].slice.call(this.frame.document.querySelectorAll(this.selector));if(this.elements.length){var t=parseFloat(BX.style(this.elements[0],this.property));t=t===t?t:0;this.setValue(t)}},onInputInput:function(){this.onInputHandler(this)},onInputInputWithoutDebounce:function(){if(!!this.elements){this.elements.forEach(function(t){this.format(t,this.getValue(),this.items)},this)}},onInputKeydown:function(t){if(t.keyCode===13){t.preventDefault()}},createInput:function(){return BX.create("input",{props:{className:"landing-ui-field-input",type:"number"}})},setValue:function(t){this.input.value=t;BX.fireEvent(this.input,"input")},getValue:function(){return this.input.value},enableEdit:function(){if(this!==BX.Landing.UI.Field.BaseField.currentField&&BX.Landing.UI.Field.BaseField.currentField!==null){BX.Landing.UI.Field.BaseField.currentField.disableEdit()}BX.Landing.UI.Field.BaseField.currentField=this;this.input.focus()},disableEdit:function(){}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:61:"/bitrix/js/landing/ui/field/range_field.min.js?17081150498326";s:6:"source";s:42:"/bitrix/js/landing/ui/field/range_field.js";s:3:"min";s:46:"/bitrix/js/landing/ui/field/range_field.min.js";s:3:"map";s:46:"/bitrix/js/landing/ui/field/range_field.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Field");BX.Landing.UI.Field.Range=function(t){this.items=BX.type.isArray(t.items)?t.items:[];this.values=new BX.Landing.Collection.BaseCollection;this.isMultiple=typeof t.type==="string"&&t.type==="multiple";this.inputInner=this.createInputInner();this.container=BX.create("div",{props:{className:"landing-ui-field-range-container"}});this.output=this.createOutput();this.sliderFrom=null;this.sliderTo=this.createSlider();this.sliderValue=this.createValue();this.elements=[];this.frame=typeof t.frame==="object"?t.frame:null;this.format=typeof t.format==="function"?t.format:function(){};this.postfix=typeof t.postfix==="string"?t.postfix:"";this.changeHandler=typeof t.onChange==="function"?t.onChange:function(){};this.onValueChangeHandler=t.onValueChange?t.onValueChange:function(){};this.dragStartHandler=typeof t.onDragStart==="function"?t.onDragStart:function(){};this.dragEndHandler=typeof t.onDragEnd==="function"?t.onDragEnd:function(){};var e=BX.Landing.PageObject.getRootWindow();this.jsDD=this.frame?e.jsDD:window.jsDD;this.value=null;this.valueFrom=null;this.valueTo=null;BX.Landing.UI.Field.BaseField.apply(this,arguments);this.layout.classList.add("landing-ui-field-range");this.stepPercent=100/this.values.length;if(this.content===null||this.content===undefined||this.content===""){if(this.isMultiple){this.content={from:this.items[0].value,to:this.items[this.items.length-1].value}}else{this.content=this.items[0].value;this.value=this.items[0].value}}var i=function(t){this.jsDD.stopDrag(t)}.bind(this);BX.Event.bind(window,"mouseup",i);BX.Event.bind(e,"mouseup",i);BX.Event.bind(window.top,"mouseup",i);this.setValue(this.content,true)};BX.Landing.UI.Field.Range.prototype={constructor:BX.Landing.UI.Field.Range,__proto__:BX.Landing.UI.Field.BaseField.prototype,init:function(){this.input.appendChild(this.inputInner);this.input.appendChild(this.sliderValue);this.layout.appendChild(this.container);this.container.appendChild(this.input);if(!this.isMultiple){this.container.appendChild(this.output)}if(this.isMultiple){this.sliderFrom=this.createSlider();this.inputInner.appendChild(this.sliderFrom)}this.inputInner.appendChild(this.sliderTo);this.items.forEach((function(t,e){this.values.add({value:t.value,valuePercent:this.valueToPercent(e),left:this.valueToLeftPercent(t.value),name:t.name})}),this);if(this.isMultiple){this.sliderFrom.onbxdragstart=this.onDragStart.bind(this);this.sliderFrom.onbxdrag=this.onDrag.bind(this);this.sliderFrom.onbxdragstop=this.onDragEnd.bind(this);this.jsDD.registerObject(this.sliderFrom)}this.sliderTo.onbxdragstart=this.onDragStart.bind(this);this.sliderTo.onbxdrag=this.onDrag.bind(this);this.sliderTo.onbxdragstop=this.onDragEnd.bind(this);this.jsDD.registerObject(this.sliderTo);if(this.isMultiple){requestAnimationFrame(function(){this.sliderFrom.style.transform="translateX(-"+this.values[this.values.length-1].valuePercent+"%)";this.sliderFrom.style.left=this.values[this.values.length-1].valuePercent+"%"}.bind(this))}if(this.frame){this.onFrameLoad()}},createOutput:function(){this.outputInput=BX.create("div",{props:{className:"landing-ui-field-range-output-input"},text:"0"});return BX.create("div",{props:{className:"landing-ui-field-range-output"},children:[this.outputInput,BX.create("div",{props:{className:"landing-ui-field-range-output-arrows"},children:[BX.create("div",{props:{className:"landing-ui-field-range-output-arrows-up"},events:{click:this.onArrowUpClick.bind(this)}}),BX.create("div",{props:{className:"landing-ui-field-range-output-arrows-down"},events:{click:this.onArrowDownClick.bind(this)}})]})]})},onArrowUpClick:function(){var t=!!this.value?this.values.length-1:0;var e;this.values.forEach((function(e,i){if(e.value===this.value){t=i}}),this);e=this.values[t+1]?this.values[t+1]:this.values[t];this.setValue(e.value)},onArrowDownClick:function(){var t=0;var e;this.values.forEach((function(e,i){if(e.value==this.value){t=i}}),this);e=this.values[t-1]?this.values[t-1]:this.values[t];this.setValue(e.value)},onFrameLoad:function(){this.elements=[].slice.call(this.frame.document.querySelectorAll(this.selector));if(this.elements.length){const t=this.elements[0];if(this.isMultiple){const e=this.values.find((function(e){return t.classList.contains(e.value)}));const i=this.values.find((function(i){return t.classList.contains(i.value)&&i.value!==e}));this.setValue({from:!!e?e.value:null,to:!!i?i.value:null},true)}else{const e=this.values.find((function(e){return t.classList.contains(e.value)}));this.setValue(!!e?e.value:null,true)}}},getStartXOffset:function(){var t=parseFloat(this.jsDD.current_node.style.left)*(this.inputInner.getBoundingClientRect().width/100);return this.jsDD.current_node.getBoundingClientRect().left+window.pageXOffset-(t===t?t:0)},onDragStart:function(){this.offset=this.getStartXOffset();this.dragStartHandler()},onDrag:function(t){t=(t-this.offset)/this.inputInner.getBoundingClientRect().width*100;t=t<0?0:t>100?100:t;var e=t;var i;var n=parseFloat(this.jsDD.current_node.style.left);n=n===n?n:0;if(t>this.lastPos){e+=this.stepPercent/2;i=this.values.filter((function(t){return e>=t.valuePercent&&t.valuePercent>n}),this);i=i[i.length-1]}else{e-=this.stepPercent/2;i=this.values.filter((function(t){return e<=t.valuePercent&&t.valuePercent<n}),this);i=i[0]}if(i){if(this.isMultiple){if(this.jsDD.current_node===this.sliderFrom){this.valueFrom=i.value}if(this.jsDD.current_node===this.sliderTo){this.valueTo=i.value}this.setValue({from:this.valueFrom,to:this.valueTo})}else{this.setValue(i.value)}}this.lastPos=t},onChange:function(){this.changeHandler(this.getValue(),this.items,this.postfix,this.property);this.onValueChangeHandler(this)},onDragEnd:function(){this.dragEndHandler()},getValue:function(){var t;if(this.isMultiple){t={from:this.toPercent<this.fromPercent?this.valueTo:this.valueFrom,to:this.toPercent>this.fromPercent?this.valueTo:this.valueFrom}}else{t=this.value}return t},setValue:function(t,e){if(t&&typeof t==="object"){var i=this.values.filter((function(e){return e.value==t.from}));var n=this.values.filter((function(e){return e.value==t.to}));i=i.length?i[0]:this.values[0];n=n.length?n[0]:this.values[this.values.length-1];if(i){requestAnimationFrame(function(){this.sliderFrom.style.transform="translateX(-"+i.valuePercent+"%)";this.sliderFrom.style.left=i.valuePercent+"%"}.bind(this));this.valueFrom=i.value;this.fromPercent=i.valuePercent}if(n){requestAnimationFrame(function(){this.sliderTo.style.transform="translateX(-"+n.valuePercent+"%)";this.sliderTo.style.left=n.valuePercent+"%"}.bind(this));this.valueTo=n.value;this.toPercent=n.valuePercent}this.updateValuePosition(i.valuePercent,n.valuePercent)}else if(t){var s=this.values.filter((function(e){return e.value==t}));s=s.length?s[0]:null;if(s){requestAnimationFrame(function(){this.sliderTo.style.transform="translateX(-"+s.valuePercent+"%)";this.sliderTo.style.left=s.valuePercent+"%"}.bind(this));this.value=t;this.updateValuePosition(s.valuePercent)}}if(!e){this.onChange()}},updateValuePosition:function(t,e){if(typeof t!=="number"&&typeof e!=="number"){t=0;e=100}if(typeof t==="number"&&typeof e!=="number"){e=t;t=0}requestAnimationFrame(function(){this.sliderValue.style.left=Math.min(t,e)+"%";this.sliderValue.style.right=100-Math.max(t,e)+"%"}.bind(this));var i=this.values.filter((function(t){return t.valuePercent==e}));i=i.length?i[0]:null;this.outputInput.innerText=!!i?i.name:0;BX.Dom.attr(this.outputInput,"title",BX.Text.encode(this.outputInput.innerText))},createInputInner:function(){return BX.create("div",{props:{className:"landing-ui-field-range-input-inner"}})},createValue:function(){return BX.create("div",{props:{className:"landing-ui-field-range-value"}})},createSlider:function(){return BX.create("div",{props:{className:"landing-ui-field-range-input-slider"}})},createInput:function(){return BX.create("div",{props:{className:"landing-ui-field-input landing-ui-field-range-input"}})},valueToPercent:function(t){return t/(this.items.length-1)*100},valueToLeftPercent:function(t){return t/this.inputInner.getBoundingClientRect().width*100},isChanged:function(){if(this.isMultiple){return JSON.stringify(this.content)!==JSON.stringify(this.getValue())}return this.content!=this.getValue()}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:68:"/bitrix/js/landing/ui/field/button_group_field.min.js?17081150492697";s:6:"source";s:49:"/bitrix/js/landing/ui/field/button_group_field.js";s:3:"min";s:53:"/bitrix/js/landing/ui/field/button_group_field.min.js";s:3:"map";s:53:"/bitrix/js/landing/ui/field/button_group_field.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Field");var t=BX.Landing.Utils.isArray;BX.Landing.UI.Field.ButtonGroup=function(t){this.items="items"in t&&t.items?t.items:[];BX.Landing.UI.Field.BaseField.apply(this,arguments);this.layout.classList.add("landing-ui-field-button-group");this.frame=typeof t.frame==="object"?t.frame:null;this.format=typeof t.format==="function"?t.format:function(){};this.postfix=typeof t.postfix==="string"?t.postfix:"";this.property=typeof t.property==="string"?t.property:"";this.multiple=typeof t.multiple==="boolean"?t.multiple:false;this.changeHandler=typeof t.onChange==="function"?t.onChange:function(){};this.elements=[];this.buttons=new BX.Landing.UI.Collection.ButtonCollection;this.value=this.getValue();this.onButtonClick=this.onButtonClick.bind(this);this.input.innerHTML="";this.items.forEach((function(t){var e=this.createButtonByItem(t);this.buttons.add(e);this.input.appendChild(e.layout)}),this);if(this.content){this.setValue(this.content,true)}if(this.frame){this.onFrameLoad()}};BX.Landing.UI.Field.ButtonGroup.prototype={constructor:BX.Landing.UI.Field.ButtonGroup,__proto__:BX.Landing.UI.Field.BaseField.prototype,superClass:BX.Landing.UI.Field.BaseField,onFrameLoad:function(){this.elements=[].slice.call(this.frame.document.querySelectorAll(this.selector));if(this.elements.length){this.deactivateAll();this.items.some((t=>{if(this.elements[0].classList.contains(t.value)){this.buttons.getByValue(t.value).activate();return!this.multiple}}))}},createButtonByItem:function(t){return new BX.Landing.UI.Button.BaseButton(t.id||t.value,{html:t.name,active:t.active,attrs:{value:t.value,title:t.title?BX.Landing.Utils.escapeText(t.title):null},onClick:this.onButtonClick})},onButtonClick:function(t){var e=this.buttons.getByNode(t.currentTarget);var i=e.layout.value;if(this.multiple){if(e.isActive()){e.deactivate()}else{e.activate()}}else{this.deactivateAll();e.activate()}this.onChange(i)},onChange:function(t){if(!this.multiple){this.changeHandler(t,this.items,this.postfix,this.property)}else{this.elements.forEach((function(e){e.classList.toggle(t)}),this);this.changeHandler()}this.onValueChangeHandler(this)},isChanged:function(){return this.value!==this.getValue()},setValue:function(e,i){this.deactivateAll();if(this.multiple){e=t(e)?e:[e];e.forEach((function(t){var e=this.buttons.getByValue(t);if(e){e.activate()}}),this)}else{var n=this.buttons.getByValue(e);if(n){n.activate()}}if(!i){this.onChange(e)}},deactivateAll:function(){this.buttons.forEach((function(t){t.deactivate()}))},getValue:function(){var t=this.buttons.getActive();if(t){return t.layout.value}return null}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:65:"/bitrix/js/landing/ui/field/dropdown_inline.min.js?17081150492393";s:6:"source";s:46:"/bitrix/js/landing/ui/field/dropdown_inline.js";s:3:"min";s:50:"/bitrix/js/landing/ui/field/dropdown_inline.min.js";s:3:"map";s:50:"/bitrix/js/landing/ui/field/dropdown_inline.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Field");BX.Landing.UI.Field.DropdownInline=function(t){this.items="items"in t&&t.items?t.items:{};this.id=t.id?t.id:"";BX.Landing.UI.Field.BaseField.apply(this,arguments);this.setEventNamespace("BX.Landing.UI.Field.DropdownInline");this.subscribeFromOptions(BX.Landing.UI.Component.fetchEventsFromOptions(t));this.popup=null;this.input.addEventListener("click",this.onInputClick.bind(this));this.layout.classList.add("landing-ui-field-dropdown-inline");if(BX.type.isPlainObject(this.items)){var i=Object.keys(this.items);this.items=i.map((function(t){return{name:this.items[t],value:t}}),this)}if(this.items.length===0){this.items.push({});this.items[0].name="";this.items[0].value=""}this.input.innerText=this.items[0].name;this.input.dataset.value=this.items[0].value;this.setValue(this.content,this.options.skipInitialEvent)};BX.Landing.UI.Field.DropdownInline.prototype={constructor:BX.Landing.UI.Field.DropdownInline,__proto__:BX.Landing.UI.Field.BaseField.prototype,onInputClick:function(){if(!this.popup){this.popup=new BX.PopupMenuWindow({id:this.selector+"_dropdown_popup_"+this.id,bindElement:this.input,bindOptions:{forceBindPosition:true},targetContainer:this.contentRoot,items:this.items.map((function(t){return{text:t.name,onclick:function(){this.onItemClick(t)}.bind(this)}}),this)});if(!this.contentRoot){this.layout.appendChild(this.popup.popupWindow.popupContainer)}}this.popup.show();if(!this.contentRoot){var t=BX.pos(this.input,this.layout);this.popup.popupWindow.popupContainer.style.top=t.bottom+"px";this.popup.popupWindow.popupContainer.style.left=t.left+"px"}},closePopup:function(){if(this.popup){this.popup.close()}},onItemClick:function(t){this.input.innerText=t.name;this.input.dataset.value=t.value;this.popup.close();BX.fireEvent(this.input,"input");this.emit("onChange");this.emit("onItemClick")},getValue:function(){return typeof this.input.dataset.value!=="undefined"?this.input.dataset.value:this.items[0].value},setValue:function(t,i){this.items.forEach((function(n){if(t===n.value){this.input.innerText=n.name;this.input.dataset.value=n.value;if(!i){this.emit("onChange")}}}),this)},setItems:function(t){if(BX.type.isArray(t)){this.items=BX.clone(t);this.popup=null;this.input.innerText=this.items[0].name;this.input.dataset.value=this.items[0].value}}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:58:"/bitrix/js/landing/ui/field/dnd_list.min.js?17081150499052";s:6:"source";s:39:"/bitrix/js/landing/ui/field/dnd_list.js";s:3:"min";s:43:"/bitrix/js/landing/ui/field/dnd_list.min.js";s:3:"map";s:43:"/bitrix/js/landing/ui/field/dnd_list.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Field");var t=BX.Landing.Utils.addClass;var e=BX.Landing.Utils.removeClass;var i=BX.Landing.Utils.hasClass;var n=BX.Landing.Utils.isBoolean;var a=BX.Landing.Utils.isArray;var s=BX.Landing.Utils.create;var o=BX.Landing.Utils.append;var r=BX.Landing.Utils.insertAfter;var l=BX.Landing.Utils.insertBefore;var h=BX.Landing.Utils.attr;var d=BX.Landing.Utils.slice;var u=BX.Landing.Utils.style;var p=BX.Landing.Utils.bind;var c=BX.Landing.Utils.unbind;var g=BX.Landing.Utils.data;var v=BX.Landing.Utils.remove;var m=BX.Landing.Utils.nextSibling;var f=BX.Landing.Utils.prevSibling;var L=BX.Landing.Utils.escapeHtml;var B=BX.Landing.Utils.findParent;var A=BX.Landing.Utils.offsetTop;var D=BX.Landing.Utils.offsetLeft;BX.Landing.UI.Field.DragAndDropList=function(e){BX.Landing.UI.Field.BaseField.apply(this,arguments);t(this.layout,"landing-ui-field-dnd-list");this.isMultiple=n(e.multiple)?e.multiple:false;this.items=a(e.items)?e.items:[];this.value=a(e.value)?e.value:[];this.onDragStart=this.onDragStart.bind(this);this.onDragEnd=this.onDragEnd.bind(this);this.onDragOver=this.onDragOver.bind(this);this.onItemDragOver=this.onItemDragOver.bind(this);this.onItemDragLeave=this.onItemDragLeave.bind(this);this.onDragLeave=this.onDragLeave.bind(this);this.onDrop=this.onDrop.bind(this);this.onDrag=this.onDrag.bind(this);this.onRemoveClick=this.onRemoveClick.bind(this);this.onElementClick=this.onElementClick.bind(this);this.onMouseWheel=this.onMouseWheel.bind(this);this.onMouseOver=this.onMouseOver.bind(this);this.onMouseLeave=this.onMouseLeave.bind(this);if(typeof window.onwheel!=="undefined"){this.wheelEventName="wheel"}else if(typeof window.onmousewheel!=="undefined"){this.wheelEventName="mousewheel"}this.target=s("div",{props:{className:"landing-ui-field-dnd-target"},children:[s("div",{props:{className:"landing-ui-field-dnd-target-browser-header"},children:[s("span"),s("span"),s("span")]})]});this.addButton=new BX.Landing.UI.Button.BaseButton("add_catalog_item",{onClick:this.onAddItemClick.bind(this),className:"landing-ui-field-dnd-add-button"});this.valueArea=s("div",{props:{classList:"landing-ui-field-dnd-list-value"}});this.itemsArea=s("div",{props:{classList:"landing-ui-field-dnd-list-items"}});o(this.valueArea,this.target);o(this.target,this.input);o(this.addButton.layout,this.target);p(this.valueArea,"dragover",this.onDragOver);p(this.valueArea,"dragleave",this.onDragLeave);p(this.valueArea,"drop",this.onDrop);this.items.forEach(function(t){o(this.createItem(t),this.itemsArea)},this);this.value.forEach(function(t){var e=this.getItem(t);if(e){o(this.createItem(e),this.valueArea)}},this);this.adjustPlaceholder();this.value=this.getValue()};BX.Landing.UI.Field.DragAndDropList.prototype={constructor:BX.Landing.UI.Field.DragAndDropList,__proto__:BX.Landing.UI.Field.BaseField.prototype,onDragStart:function(e){this.dragItem=e.currentTarget;this.dragIndex=d(this.valueArea.children).findIndex(function(t){return t===e.currentTarget});this.valueAreaRect=this.valueArea.getBoundingClientRect();t(this.dragItem,"landing-ui-ondrag");t(this.valueArea,"landing-ui-ondrag")},onDragEnd:function(){e(this.valueArea,"landing-ui-over");e(this.dragItem,"landing-ui-ondrag");e(this.valueArea,"landing-ui-ondrag");d(this.valueArea.children).forEach(function(t){u(t,null)});this.cloned=null;this.dragItem=null;if(this.isChanged()){this.onValueChangeHandler(this);this.value=this.getValue()}},onDragOver:function(e){e.preventDefault();e.dataTransfer.dropEffect="copy";t(e.currentTarget,"landing-ui-over")},onItemDragOver:function(t){var e=t.currentTarget;if(this.itemsArea.contains(this.dragItem)||this.valueArea.contains(this.dragItem)){if(this.valueArea.contains(e)&&e!==this.cloned){var i=e.getBoundingClientRect();var n=i.top+i.height/2;if(!this.cloned&&!this.valueArea.contains(this.dragItem)){this.cloned=this.createItemFromElement(this.dragItem);o(this.cloned,this.valueArea)}if(!this.cloned&&this.valueArea.contains(this.dragItem)){this.cloned=this.dragItem}if(t.clientY>n&&m(e)!==this.cloned){return r(this.cloned,e)}if(t.clientY<n&&f(e)!==this.cloned){return l(this.cloned,e)}}}this.adjustPopupPosition()},onAddItemClick:function(t){t.preventDefault();t.stopPropagation();if(!this.popup){this.popup=new BX.Main.Popup({id:"catalog_blocks_list",bindElement:this.addButton.layout,content:this.itemsArea,autoHide:true,height:176});this.popup.contentContainer.style.overflowX="hidden";p(this.popup.popupContainer,"mouseover",this.onMouseOver);p(this.popup.popupContainer,"mouseleave",this.onMouseLeave);var e=BX.Landing.PageObject.getRootWindow();p(e.document,"click",this.onDocumentClick.bind(this));o(this.popup.popupContainer,B(this.addButton.layout,{className:"landing-ui-panel-content-body-content"}))}if(this.popup.isShown()){this.popup.close()}else{this.popup.show()}this.adjustPopupPosition()},onMouseOver:function(){p(this.popup.popupContainer,this.wheelEventName,this.onMouseWheel);p(this.popup.popupContainer,"touchmove",this.onMouseWheel)},onMouseLeave:function(){c(this.popup.popupContainer,this.wheelEventName,this.onMouseWheel);c(this.popup.popupContainer,"touchmove",this.onMouseWheel)},onMouseWheel:function(t){t.stopPropagation();t.preventDefault();var e=BX.Landing.UI.Panel.Content.getDeltaFromEvent(t);var i=this.popup.contentContainer.scrollTop;requestAnimationFrame(function(){this.popup.contentContainer.scrollTop=i-e.y}.bind(this))},adjustPopupPosition:function(){if(this.popup){requestAnimationFrame(function(){var t=B(this.addButton.layout,{className:"landing-ui-panel-content-body-content"});var e=A(this.addButton.layout,t);var i=D(this.addButton.layout,t);var n=this.addButton.layout.getBoundingClientRect();var a=this.popup.popupContainer.getBoundingClientRect();var s=14;this.popup.popupContainer.style.top=e+n.height+s+"px";this.popup.popupContainer.style.left=i-a.width/2+n.width/2+"px";this.popup.setAngle({offset:71,position:"top"})}.bind(this))}},createItemFromElement:function(t){var e=t.querySelector("img");var i={name:t.innerText,value:g(t,"value")};if(e){i.image=e.src}return this.createItem(i)},onDragLeave:function(t){e(t.currentTarget,"landing-ui-over")},onItemDragLeave:function(t){t.stopPropagation()},onDrop:function(t){t.stopPropagation();if(this.itemsArea.contains(this.dragItem)||this.valueArea.contains(this.dragItem)){if(!this.valueArea.contains(this.dragItem)&&!this.valueArea.contains(this.cloned)){var e=this.createItemFromElement(this.dragItem);o(e,this.valueArea);this.cloned=null;this.adjustPlaceholder();this.adjustPopupPosition()}}if(this.isChanged()){this.onValueChangeHandler(this);this.value=this.getValue()}},onDrag:function(t){if(this.cloned&&this.valueArea.contains(this.cloned)){if(t.clientX>this.valueAreaRect.right){v(this.cloned);this.cloned=null;this.adjustPlaceholder();this.adjustPopupPosition()}}},onRemoveClick:function(t){t.preventDefault();t.stopPropagation();v(t.currentTarget.parentNode);this.adjustPlaceholder();this.adjustPopupPosition();if(this.isChanged()){this.onValueChangeHandler(this);this.value=this.getValue()}},onElementClick:function(t){t.preventDefault();t.stopPropagation();if(this.itemsArea.contains(t.currentTarget)){var e=this.createItemFromElement(t.currentTarget);o(e,this.valueArea);this.adjustPlaceholder();this.adjustPopupPosition()}if(this.isChanged()){this.onValueChangeHandler(this);this.value=this.getValue()}},getSelectedItem:function(){return d(this.valueArea.children).find(function(t){return i(t,"landing-ui-selected")})||d(this.itemsArea.children).find(function(t){return i(t,"landing-ui-selected")})},onDocumentClick:function(){if(this.popup){this.popup.close()}},adjustPlaceholder:function(){if(d(this.valueArea.children).length===0){this.placeholder=this.createValuePlaceholder();o(this.placeholder,this.valueArea)}else if(this.placeholder){v(this.placeholder);this.placeholder=null}},getItem:function(t){return this.items.find(function(e){return e.value==t})},createValuePlaceholder:function(){return s("div",{props:{className:"landing-ui-field-dnd-value-placeholder"},children:[s("span",{html:BX.Landing.Loc.getMessage("LANDING_FIELD_CATALOG_CONSTRUCTOR_PLACEHOLDER_TEXT")})]})},createItem:function(t){var e=s("div",{props:{className:"landing-ui-field-dnd-list-item"+(t.image?" landing-ui-with-image":"")},attrs:{title:t.name},html:t.image?s("img",{props:{src:t.image}}).outerHTML:L(t.name)});var i=s("span",{props:{className:"landing-ui-field-dnd-list-item-remove"}});o(i,e);g(e,"data-value",t.value);h(e,"draggable","true");p(e,"dragstart",this.onDragStart);p(e,"dragend",this.onDragEnd);p(e,"dragover",this.onItemDragOver);p(e,"dragleave",this.onItemDragLeave);p(e,"drag",this.onDrag);p(i,"click",this.onRemoveClick);p(e,"click",this.onElementClick);return e},isChanged:function(){return JSON.stringify(this.value)!==JSON.stringify(this.getValue())},getValue:function(){var t=d(this.valueArea.children);t=t.filter(function(t){return i(t,"landing-ui-field-dnd-list-item")});return t.map(function(t){return g(t,"data-value")})}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:63:"/bitrix/js/landing/ui/field/sortable_list.min.js?17081150492604";s:6:"source";s:44:"/bitrix/js/landing/ui/field/sortable_list.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Field");var i=BX.Landing.Utils.remove;var e=BX.Landing.Utils.unbind;var t=BX.Landing.Utils.addClass;var n=BX.Landing.Utils.removeClass;var a=BX.Landing.Utils.encodeDataValue;var r=BX.Landing.Utils.prepend;var l=BX.Landing.Utils.append;var s=BX.Landing.Utils.create;var d=BX.Landing.Utils.data;var g=BX.Landing.Utils.slice;var o=BX.Landing.Utils.bind;BX.Landing.UI.Field.SortableList=function(i){BX.Landing.UI.Field.DragAndDropList.apply(this,arguments);t(this.layout,"landing-ui-field-sortable-list");this.makePreview();r(this.preview,this.target)};BX.Landing.UI.Field.SortableList.prototype={constructor:BX.Landing.UI.Field.SortableList,__proto__:BX.Landing.UI.Field.DragAndDropList.prototype,onDragStart:function(i){BX.Landing.UI.Field.DragAndDropList.prototype.onDragStart.call(this,i);t(this.preview,"landing-ui-ondrag");t(this.dragItem,"landing-ui-ondrag")},onDragEnd:function(i){BX.Landing.UI.Field.DragAndDropList.prototype.onDragEnd.call(this,i);n(this.preview,"landing-ui-ondrag");n(this.dragItem,"landing-ui-ondrag");this.makePreview()},onElementClick:function(){},makePreview:function(){if(!this.preview){this.preview=s("div",{props:{className:"landing-ui-field-sortable-list-preview"}})}this.preview.innerHTML="";this.getValue().forEach(function(i){l(this.createPreviewItem(this.getItem(i).preview,i),this.preview)},this)},createItem:function(t){var n=BX.Landing.UI.Field.DragAndDropList.prototype.createItem.call(this,t);i(n.querySelector(".landing-ui-field-dnd-list-item-remove"));e(n,"drag",this.onDrag);r(s("span",{props:{className:"landing-ui-field-dnd-list-item-drag"}}),n);o(n,"mouseover",this.highlightByValue.bind(this,t.value));o(n,"mouseout",this.removeHighLightByValue.bind(this,t.value));return n},createPreviewItem:function(i,e){return s("div",{props:{className:"landing-ui-field-sortable-list-preview-item"},attrs:{"data-value":a(e)},children:[s("img",{props:{src:i},events:{mouseover:this.highlightByValue.bind(this,e),mouseout:this.removeHighLightByValue.bind(this,e)}})]})},highlightByValue:function(i){var e=this.getPreviewByValue(i);var n=this.getElementByValue(i);if(e){t(e,"landing-ui-active")}if(n){t(n,"landing-ui-active")}},removeHighLightByValue:function(i){var e=this.getPreviewByValue(i);var t=this.getElementByValue(i);if(e){n(e,"landing-ui-active")}if(t){n(t,"landing-ui-active")}},getElementByValue:function(i){return g(this.valueArea.children).find(function(e){return d(e,"data-value")==i})},getPreviewByValue:function(i){return g(this.preview.children).find(function(e){return d(e,"data-value")==i})}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:64:"/bitrix/js/landing/ui/field/position_field.min.js?17081150491930";s:6:"source";s:45:"/bitrix/js/landing/ui/field/position_field.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Field");var i=BX.Landing.Utils.addClass;var t=BX.Landing.Utils.clone;var e=BX.Landing.Utils.append;var a=BX.Landing.Utils.create;var n=[{name:"",value:"top-left"},{name:"",value:"top-center"},{name:"",value:"top-right"},{name:"",value:"middle-left"},{name:"",value:"middle-center"},{name:"",value:"middle-right"},{name:"",value:"bottom-left"},{name:"",value:"bottom-center"},{name:"",value:"bottom-right"}];BX.Landing.UI.Field.Position=function(s){this.dataItems=s.items?t(s.items):{};this.mode=s.mode?s.mode:"ball";if(Object.keys(this.dataItems).length){s.items=n.map(function(i){if(i.value in this.dataItems){if("content"in this.dataItems[i.value]){i.name=this.dataItems[i.value].content}if("value"in this.dataItems[i.value]){i.value=this.dataItems[i.value].value}}return i},this)}else{s.items=n}BX.Landing.UI.Field.ButtonGroup.apply(this,arguments);i(this.layout,"landing-ui-field-position");i(this.layout,"landing-ui-field-position-mode-"+this.mode);this.wrapper=a("div",{props:{className:"landing-ui-field-position-wrapper"}});this.container=a("div",{props:{className:"landing-ui-field-position-container"},children:this.buttons.map(function(i){return i.layout})});e(this.container,this.wrapper);var l=a("div",{props:{className:"landing-ui-field-position-stripes"},children:[a("span",{props:{className:"landing-ui-field-position-stripes-item"}}),a("span",{props:{className:"landing-ui-field-position-stripes-item"}}),a("span",{props:{className:"landing-ui-field-position-stripes-item"}}),a("span",{props:{className:"landing-ui-field-position-stripes-item"}}),a("span",{props:{className:"landing-ui-field-position-stripes-item"}})]});e(l,this.wrapper);e(this.wrapper,this.input);this.setValue(s.value,true);this.value=this.getValue()};BX.Landing.UI.Field.Position.prototype={constructor:BX.Landing.UI.Field.Position,__proto__:BX.Landing.UI.Field.ButtonGroup.prototype}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:64:"/bitrix/js/landing/ui/field/checkbox_field.min.js?17081150492746";s:6:"source";s:45:"/bitrix/js/landing/ui/field/checkbox_field.js";s:3:"min";s:49:"/bitrix/js/landing/ui/field/checkbox_field.min.js";s:3:"map";s:49:"/bitrix/js/landing/ui/field/checkbox_field.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Field");var i=BX.Landing.Utils.addClass;var t=BX.Landing.Utils.isArray;var e=BX.Landing.Utils.isPlainObject;var n=BX.Landing.Utils.isFunction;var a=BX.Landing.Utils.create;var l=BX.Landing.Utils.random;var s=BX.Landing.Utils.escapeHtml;var r=BX.Landing.Utils.append;var c=BX.Landing.Utils.slice;var u=BX.Landing.Utils.encodeDataValue;var d=BX.Landing.Utils.decodeDataValue;var h=BX.Landing.Utils.isNumber;var o=BX.Landing.Utils.isBoolean;var p=BX.Landing.Utils.data;var f=BX.Landing.Utils.clone;BX.Landing.UI.Field.Checkbox=function(e){BX.Landing.UI.Field.BaseField.apply(this,arguments);i(this.layout,"landing-ui-field-checkbox");this.onChangeHandler=n(e.onChange)?e.onChange:function(){};this.items=t(e.items)?e.items:[];this.value=t(e.value)?e.value:null;this.depth=h(e.depth)?e.depth:0;this.compact=o(e.compact)?e.compact:false;this.multiple=e.multiple!==false;p(this.layout,"data-depth",this.depth);p(this.layout,"data-compact",this.compact);if(t(this.value)){this.value=this.value.map(function(i){return d(i)})}if(!t(this.value)){this.value=this.items.filter(function(i){return i.checked}).map(function(i){return d(i.value)})}this.content=this.value;this.items.forEach(this.addItem,this)};BX.Landing.UI.Field.Checkbox.prototype={constructor:BX.Landing.UI.Field.Checkbox,__proto__:BX.Landing.UI.Field.BaseField.prototype,addItem:function(i){if(e(i)){var t="checkbox_item_"+l();var n=a("div",{props:{className:"landing-ui-field-checkbox-item"+(i.disabled?" landing-ui-disabled":"")},children:[a("input",{props:{className:"landing-ui-field-checkbox-item-checkbox"},attrs:{id:t,type:"checkbox",value:u(i.value),checked:this.value.find(function(t){return t==i.value})!==undefined},events:{change:this.onItemChange.bind(this)}}),a("label",{props:{className:"landing-ui-field-checkbox-item-label"},attrs:{for:t,title:BX.Text.encode(i.name)},html:i.html?i.html:s(i.name)})]});r(n,this.input)}return n},onItemChange:function(){this.onChangeHandler(this);this.onValueChangeHandler(this);this.emit("onChange")},isChanged:function(){var i=f(this.content).sort();var t=this.getValue().sort();return JSON.stringify(i)!==JSON.stringify(t)},setValue:function(i){if(t(i)){c(this.input.children).forEach(function(i){i.querySelector("input").checked=false});i.forEach(function(i){var t=c(this.input.children).find(function(t){return d(t.querySelector("input").value)==i},this);if(t){t.querySelector("input").checked=true}},this)}},getValue:function(){var i=c(this.input.children).filter(function(i){return i.querySelector("input").checked}).map(function(i){return d(i.querySelector("input").value)});if(!this.multiple){return i.length>0?i[0]:false}return i}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:60:"/bitrix/js/landing/ui/field/radio_field.min.js?1708115049469";s:6:"source";s:42:"/bitrix/js/landing/ui/field/radio_field.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Field");BX.Landing.UI.Field.Radio=function(i){BX.Landing.UI.Field.Checkbox.apply(this,arguments)};BX.Landing.UI.Field.Radio.prototype={constructor:BX.Landing.UI.Field.Radio,__proto__:BX.Landing.UI.Field.Checkbox.prototype,superclass:BX.Landing.UI.Field.Checkbox.prototype,addItem:function(i){var e=this.superclass.addItem.call(this,i);if(e){var n=e.querySelector("input");if(n){n.type="radio";n.name=this.id}}}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:67:"/bitrix/js/landing/ui/field/multiselect_field.min.js?17081150495813";s:6:"source";s:48:"/bitrix/js/landing/ui/field/multiselect_field.js";s:3:"min";s:52:"/bitrix/js/landing/ui/field/multiselect_field.min.js";s:3:"map";s:52:"/bitrix/js/landing/ui/field/multiselect_field.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Field");var i=BX.Landing.Utils.addClass;var t=BX.Landing.Utils.hasClass;var n=BX.Landing.Utils.removeClass;var e=BX.Landing.Utils.isArray;var a=BX.Landing.Utils.isFunction;var s=BX.Landing.Utils.create;var l=BX.Landing.Utils.random;var o=BX.Landing.Utils.escapeHtml;var u=BX.Landing.Utils.append;var d=BX.Landing.Utils.slice;var p=BX.Landing.Utils.encodeDataValue;var r=BX.Landing.Utils.remove;var h=BX.Landing.Utils.data;var c=BX.Landing.Utils.bind;var g=BX.Landing.Utils.style;var f=BX.Landing.Utils.clone;var v=BX.Landing.Utils.offsetLeft;var m=BX.Landing.Utils.offsetTop;var B=BX.Landing.Utils.findParent;var C=BX.Landing.Utils.decodeDataValue;var L=BX.Landing.Collection.BaseCollection;function X(i,t,n){i.forEach(function(i){var a=new BX.Landing.UI.Field.Checkbox({id:i.value,items:[{name:i.name,value:i.value,checked:i.selected}],depth:n,compact:true,onChange:t.onCheckboxChange});t.fields.add(a);if(a.layout){u(a.layout,t.getPopup().contentContainer)}if(i.selected){t.addPlaceholder(i)}if(e(i.items)){n+=1;X(i.items,t,n);n-=1}})}BX.Landing.UI.Field.MultiSelect=function(t){BX.Landing.UI.Field.BaseField.apply(this,arguments);i(this.layout,"landing-ui-field-multiselect");this.onChangeHandler=a(t.onChange)?t.onChange:function(){};this.items=e(t.items)?t.items:[];this.value=e(t.value)?t.value:null;this.content=this.value;this.fields=new L;this.button=new BX.Landing.UI.Button.BaseButton("dropdown_button",{text:BX.Landing.Loc.getMessage("LINK_URL_SUGGESTS_SELECT"),className:"landing-ui-button-select-link",onClick:this.onButtonClick.bind(this)});this.grid=s("div",{props:{className:"landing-ui-field-multiselect-grid"},children:[s("div",{props:{className:"landing-ui-field-multiselect-grid-left"},children:[this.input]}),s("div",{props:{className:"landing-ui-field-multiselect-grid-right"},children:[this.button.layout]})]});u(this.grid,this.layout);this.onInputClick=this.onInputClick.bind(this);this.onCheckboxChange=this.onCheckboxChange.bind(this);var n=BX.Landing.PageObject.getRootWindow();c(this.input,"click",this.onInputClick);c(n.document,"click",this.onDocumentClick.bind(this));requestAnimationFrame(function(){X(this.items,this,0);if(e(this.value)){this.value=this.value.map(function(i){return C(i)});this.setValue(this.value,true)}else{this.value=this.getValue();this.content=this.value}}.bind(this))};BX.Landing.UI.Field.MultiSelect.prototype={constructor:BX.Landing.UI.Field.MultiSelect,__proto__:BX.Landing.UI.Field.BaseField.prototype,addPlaceholder:function(i){var t=s("div",{props:{className:"landing-ui-field-multiselect-placeholder"},attrs:{"data-item":p(i),title:o(i.name)},children:[s("span",{props:{className:"landing-ui-field-multiselect-placeholder-text"},html:o(i.name)}),s("span",{props:{className:"landing-ui-field-multiselect-placeholder-remove"},events:{click:this.onPlaceholderRemoveClick.bind(this,i)}})]});u(t,this.input)},onPlaceholderRemoveClick:function(i,t,n){if(t){t.preventDefault();t.stopPropagation()}var e=this.getPlaceholderByItem(i);if(e){r(e);this.adjustPopupPosition();var a=this.fields.get(i.value);if(a){a.layout.querySelector("input").checked=false}}if(!n){this.onValueChangeHandler(this)}},onCheckboxChange:function(i){if(i instanceof BX.Landing.UI.Field.Checkbox){var t=i.getValue();if(t.length){this.addPlaceholder(i.items[0]);this.adjustPopupPosition()}else{this.onPlaceholderRemoveClick(i.items[0],null,true)}this.onValueChangeHandler(this)}},getPlaceholderByItem:function(i){return d(this.input.children).find(function(t){return h(t,"data-item").value===i.value})},getPopup:function(){if(this.popup){return this.popup}this.popup=new BX.Main.Popup({id:this.selector+"_"+l(),bindElement:this.input,autoHide:true,maxHeight:142,events:{onPopupClose:function(){n(this.input,"landing-ui-active");if(t(this.layout.parentElement.parentElement,"landing-ui-form-style")){void g(this.layout.parentElement.parentElement,{"z-index":null,position:null})}}.bind(this)}});if(this.popup.popupContainer){i(this.popup.popupContainer,"landing-ui-field-multiselect-popup");var e=B(this.input,{className:"landing-ui-panel-content-body-content"},document.body);if(e){u(this.popup.popupContainer,e)}}return this.popup},showPopup:function(){this.getPopup().show();this.adjustPopupPosition();this.setValue(this.getValue(),true)},adjustPopupPosition:function(){if(this.popup){var i=B(this.input,{className:"landing-ui-panel-content-body-content"});if(BX.Type.isDomNode(i)){var t=m(this.input,i);var n=v(this.input,i);var e=this.input.getBoundingClientRect();var a=2;requestAnimationFrame(function(){this.popup.popupContainer.style.top=t+e.height+a+"px";this.popup.popupContainer.style.left=n+"px";this.popup.popupContainer.style.width=e.width+"px"}.bind(this))}}},onInputClick:function(t){if(t){t.stopPropagation()}var e=this.getPopup();if(e.isShown()){n(this.input,"landing-ui-active");return e.close()}i(this.input,"landing-ui-active");return this.showPopup()},onButtonClick:function(i){i.preventDefault();i.stopPropagation();this.onInputClick()},onDocumentClick:function(){this.getPopup().close()},getValue:function(){return d(this.input.children).map(function(i){return h(i,"data-item").value})},isChanged:function(){var i=f(this.content).sort();var t=this.getValue().sort();return JSON.stringify(i)!==JSON.stringify(t)},getItemByValue:function(i,t){var n=null;function e(i,t){return i.forEach(function(i){if(t==i.value){n=i;return}if(i.items){e(i.items,t)}},this)}e(i,t);return n},setValue:function(i,t){if(e(i)){this.input.innerHTML="";i.forEach(function(i){var t=this.getItemByValue(this.items,i);if(t){this.addPlaceholder(t);var n=this.fields.find(function(t){return t.id===i}.bind(this));if(n){n.setValue([i])}}},this)}if(!t){this.onValueChangeHandler(this)}}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:62:"/bitrix/js/landing/ui/field/filter_field.min.js?17081150491673";s:6:"source";s:43:"/bitrix/js/landing/ui/field/filter_field.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Field");var i=BX.Landing.Utils.addClass;var t=BX.Landing.Utils.removeClass;var n=BX.Landing.Utils.isPlainObject;var e=BX.Landing.Utils.append;var a=BX.Landing.Utils.findParent;var s=BX.Landing.Utils.offsetLeft;var l=BX.Landing.Utils.offsetTop;var o=BX.Landing.Utils.rect;var r=BX.Landing.Utils.onCustomEvent;var p=BX.Landing.Utils.bind;BX.Landing.UI.Field.Filter=function(t){BX.Landing.UI.Field.BaseField.apply(this,arguments);i(this.layout,"landing-ui-field-filter");this.input.innerHTML=t.html;requestAnimationFrame(function(){BX.ajax.processScripts(BX.processHTML(t.html).SCRIPT,undefined,function(){this.filter=BX.Main.filterManager.getById(t.filterId);this.value=n(t.value)?t.value:{};e(this.filter.getPopup().popupContainer,a(this.layout,{className:"landing-ui-panel-content-body"}));r(this.filter.getPopup(),"onPopupShow",this.adjustPopupPosition.bind(this));p(a(this.layout,{className:"landing-ui-panel-content-body-content"}),"scroll",this.adjustPopupPosition.bind(this));this.filter.getApi().setFields(this.value);this.filter.getApi().apply()}.bind(this))}.bind(this))};BX.Landing.UI.Field.Filter.prototype={constructor:BX.Landing.UI.Field.Filter,__proto__:BX.Landing.UI.Field.BaseField.prototype,getValue:function(){var i=this.filter.getFilterFieldsValues();if(n(i)){if("FIND"in i){delete i["FIND"]}return i}return{}},adjustPopupPosition:function(){if(this.filter.getPopup()){var i=this.input.getBoundingClientRect();var t=6;requestAnimationFrame(function(){this.filter.getPopup().popupContainer.style.top=i.top+i.height+t+"px";this.filter.getPopup().popupContainer.style.left=i.left+"px"}.bind(this))}}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:60:"/bitrix/js/landing/ui/field/font_field.min.js?17081150495233";s:6:"source";s:41:"/bitrix/js/landing/ui/field/font_field.js";s:3:"min";s:45:"/bitrix/js/landing/ui/field/font_field.min.js";s:3:"map";s:45:"/bitrix/js/landing/ui/field/font_field.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Field");BX.Runtime.loadExtension("landing.ui.component.link");var t=BX.Landing.Utils.isFunction;var e=BX.Landing.Utils.isPlainObject;var n=BX.Landing.Utils.bind;var i=BX.Landing.Utils.proxy;var a=BX.Landing.Utils.escapeHtml;var s=BX.Landing.Utils.addClass;var l=BX.Landing.Utils.clone;var o=/g-font-(?!size-|weight-)([a-z0-9-]+)/gi;var r=/[a-z0-9 ]*[a-z0-9]/i;var h=/['|"]/g;var c=/ /g;var u=["H1","H2","H3","H4","H5","H6","H7"];BX.Landing.UI.Field.Font=function(l){BX.Landing.UI.Field.BaseField.apply(this,arguments);s(this.layout,"landing-ui-field-font");this.value=l.value;this.headlessMode=l.headlessMode===true;this.frame=l.frame;this.items=[];this.defaultFontFamily=null;this.defaultFontLink=new BX.Landing.UI.Component.Link({text:BX.Landing.Loc.getMessage("LANDING_EDIT_BLOCK_DEFAULT_FONT")});s(this.defaultFontLink.getLayout(),"landing-ui-field-font-link");if(e(l.items)){var o=Object.keys(this.items);this.items=o.map((function(t){return{name:this.items[t],value:t}}),this)}this.onChangeHandler=t(l.onChange)?l.onChange:function(){};this.onValueChangeHandler=t(l.onValueChange)?l.onValueChange:function(){};if(this.value){this.content=a(this.value.family);this.input.innerHTML=this.value.family}else{this.content=a(this.content);this.input.innerHTML=this.content}if(this.frame){if(l.styleNode.currentTarget){this.element=l.styleNode.currentTarget}else{this.element=this.frame.document.querySelectorAll(this.selector)[0]}if(this.element){var r=BX.style(this.element,"font-family");if(r){r=r.replace(h,"");this.content=r.split(",")[0];this.input.innerHTML=this.content}this.createLinkContainer();this.setConditionLink()}}if(this.content.search(new RegExp("var\\(--[a-z-]*\\)"))!==-1){var c=window.getComputedStyle(document.body).getPropertyValue("font-family");this.input.innerHTML=c.replace(h,"").split(",")[0]}n(this.input,"click",i(this.onInputClick,this));this.defaultFontLink.subscribe("onClick",i(this.onDefaultFontLinkClick,this))};function d(t){return"g-font-"+t.toLowerCase().replace(c,"-")}BX.Landing.UI.Field.Font.prototype={constructor:BX.Landing.UI.Field.Font,__proto__:BX.Landing.UI.Field.BaseField.prototype,onInputClick:function(t){t.preventDefault();t.stopPropagation();BX.Landing.UI.Panel.GoogleFonts.getInstance().show().then(function(t){if(!this.response){this.response=l(BX.Landing.UI.Panel.GoogleFonts.getInstance().response);this.response.forEach((function(t){this.items.push({name:t.family,value:d(t.family)})}),this)}this.setValue(t)}.bind(this))},onDefaultFontLinkClick:function(){if(this.defaultFontFamily){const t=this.element.classList.value.match(o);if(t!==null){t.forEach((t=>{this.element.classList.remove(t)}))}this.content=this.defaultFontFamily.replace(h,"").split(",")[0];const e={family:this.content};this.setValue(e)}},createLinkContainer:function(){this.linkContainer=document.createElement("div");this.linkContainer.classList.add("landing-ui-component-link-container");this.layout.append(this.linkContainer)},setConditionLink:function(){if(this.element){if(u.includes(this.element.tagName)){const t=document.createElement("H2");document.body.appendChild(t);this.defaultFontFamily=getComputedStyle(t).fontFamily;t.remove()}else{this.defaultFontFamily=getComputedStyle(document.body).fontFamily}this.defaultFont=this.defaultFontFamily.match(r)[0];this.currentFont=getComputedStyle(this.element).fontFamily.match(r)[0];if(this.defaultFont!==this.currentFont){this.linkContainer.append(this.defaultFontLink.getLayout())}else if(this.linkContainer.hasChildNodes()){this.linkContainer.removeChild(this.linkContainer.firstChild)}}},setValue:function(t,n){if(e(t)){var i=d(t.family);var s=[100,200,300,400,500,600,700,800,900];var l=":wght@"+s.join(";");var o=t.family.replace(c,"+");var r=o+l;var h=BX.Landing.UI.Panel.GoogleFonts.getInstance().client.makeUrl({family:r});if(this.headlessMode){this.value={family:t.family,public:"https://fonts.google.com/specimen/"+o,uri:h};this.input.innerHTML=a(t.family);this.emit("onChange")}else{const e=BX.Landing.UI.Tool.FontManager.getInstance();e.addFont({className:i,family:o,href:h,category:t.category},window);this.input.innerHTML=a(t.family);this.onChangeHandler(i,this.items,this.postfix,this.property);this.onValueChangeHandler(this);e.removeUnusedFonts();if(!n){let t="";e.getUsedLoadedFonts().forEach((function(e){if(e.element){e.element.setAttribute("rel","stylesheet");e.element.removeAttribute("media");t+="<noscript>"+e.element.outerHTML+"</noscript>\n";e.element.setAttribute("rel","preload");e.element.setAttribute("onload","this.removeAttribute('onload');this.rel='stylesheet'");e.element.setAttribute("as","style");t+=e.element.outerHTML+"\n"}if(e.CSSDeclaration){t+=e.CSSDeclaration.outerHTML}}));t=t.replace("async@load","all").replace(/data-loadcss="true"/g,"");BX.Landing.Backend.getInstance().action("Landing::updateHead",{content:t})}}}this.setConditionLink()},getValue:function(){return this.value},onFrameLoad:function(){const t=Array.from(this.element.classList.value.matchAll(o));if(t){const e=t[t.length-1][1].split("-").map((t=>t.charAt(0).toUpperCase()+t.slice(1))).join(" ");this.content=e;this.setValue({family:e},true)}}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:60:"/bitrix/js/landing/ui/field/html_field.min.js?17081150491233";s:6:"source";s:41:"/bitrix/js/landing/ui/field/html_field.js";s:3:"min";s:45:"/bitrix/js/landing/ui/field/html_field.min.js";s:3:"map";s:45:"/bitrix/js/landing/ui/field/html_field.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Field");var t=BX.Landing.Utils.addClass;var n=BX.Landing.Utils.bind;var i=BX.Landing.Utils.proxy;var e=BX.Landing.Utils.decodeDataValue;BX.Landing.UI.Field.Html=function(s){BX.Landing.UI.Field.BaseField.apply(this,arguments);t(this.layout,"landing-ui-field-html");this.onContentChange=i(this.onContentChange,this);this.onMousewheel=i(this.onMousewheel,this);n(this.input,"input",this.onContentChange);n(this.input,"keydown",this.onContentChange);n(this.input,"mousewheel",this.onMousewheel);this.input.value=e(this.content);setTimeout(function(){this.adjustHeight()}.bind(this),20)};BX.Landing.UI.Field.Html.prototype={constructor:BX.Landing.UI.Field.Html,__proto__:BX.Landing.UI.Field.BaseField.prototype,createInput:function(){return BX.create("textarea",{props:{className:"landing-ui-field-input"},html:this.content})},onMousewheel:function(t){t.stopPropagation()},onPaste:function(){},onContentChange:function(){this.adjustHeight();this.onValueChangeHandler(this)},adjustHeight:function(){this.input.style.height="0px";this.input.style.height=Math.min(this.input.scrollHeight,180)+"px"},getValue:function(){return this.input.value}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:61:"/bitrix/js/landing/ui/field/embed_field.min.js?17081150493108";s:6:"source";s:42:"/bitrix/js/landing/ui/field/embed_field.js";s:3:"min";s:46:"/bitrix/js/landing/ui/field/embed_field.min.js";s:3:"map";s:46:"/bitrix/js/landing/ui/field/embed_field.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Field");var e=BX.Landing.Utils.bind;var i=BX.Landing.Utils.fireCustomEvent;var t=BX.Landing.Utils.getQueryParams;var a=BX.Landing.Utils.remove;var n=BX.Landing.Utils.create;BX.Landing.UI.Field.Embed=function(e){e.textOnly=true;var i=e.content;e.content=i.source||i.src;e.placeholder=BX.Landing.Loc.getMessage("LANDING_EMBED_NOT_BG_FIELD_DESCRIPTION");e.description=e.description||"<span class='landing-ui-anchor-preview'>"+BX.Landing.Loc.getMessage("LANDING_EMBED_NOT_BG_FIELD_DESCRIPTION")+"</span>";BX.Landing.UI.Field.Text.apply(this,arguments);this.hiddenInput=n("input",{props:{type:"hidden",value:i.src||this.input.innerText}});this.error=BX.create("div",{props:{className:"landing-ui-field-error"}});BX.Dom.append(this.error,this.layout);BX.Dom.style(this.description,"margin-bottom","0px");this.adjustForm()};BX.Landing.UI.Field.Embed.isBgVideo=false;BX.Landing.UI.Field.Embed.prototype={constructor:BX.Landing.UI.Field.Embed,__proto__:BX.Landing.UI.Field.Text.prototype,onInputInput:function(){var e=this.getValue();this.adjustForm(true);this.onInputHandler(e);this.onValueChangeHandler(this);var i=new BX.Event.BaseEvent({data:{value:e},compatData:[e]});this.emit("change",i)},isEmbedUrl:function(e){return BX.Landing.Utils.Matchers.youtube.test(e)||BX.Landing.Utils.Matchers.vimeo.test(e)||BX.Landing.Utils.Matchers.rutube.test(e)||BX.Landing.Utils.Matchers.vk.test(e)||BX.Landing.Utils.Matchers.vine.test(e)||BX.Landing.Utils.Matchers.facebookVideos.test(e)},getValue:function(){return{src:this.mediaService?this.mediaService.getEmbedURL():this.input.innerText,preview:this.mediaService?this.mediaService.getEmbedPreview():"",source:this.input.innerText,ratio:this.mediaService&&this.mediaService.isVertical?BX.Landing.Block.Node.Embed.DEFAULT_RATIO_V:BX.Landing.Block.Node.Embed.DEFAULT_RATIO_H}},adjustForm:function(e){var i=String(this.input.innerText).trim();this.hideError();if(this.isEmbedUrl(i)){if(this.mediaService&&this.mediaService.form){a(this.mediaService.form.layout)}const r=new BX.Landing.MediaService.Factory;this.mediaService=r.create(i,!e?t(this.hiddenInput.value):{});this.mediaService.setBgVideoMode(this.constructor.isBgVideo);if(this.mediaService){var n=this.mediaService.getSettingsForm();if(n){this.layout.appendChild(n.layout)}if(!this.mediaService.isDataLoaded){this.readyToSave=false;BX.addCustomEvent(this.mediaService,"onDataLoaded",(()=>{this.readyToSave=true;this.emit("onChangeReadyToSave")}));BX.addCustomEvent(this.mediaService,"onDataLoadError",(e=>{this.readyToSave=false;this.showError(e.message)}))}this.emit("onChangeReadyToSave")}}else{if(this.mediaService){a(this.mediaService.form.layout)}if(BX.Type.isStringFilled(i)){this.showError(BX.Landing.Loc.getMessage("LANDING_EMBED_ERROR_WRONG_SOURCE_TEXT_ALL"))}}},showError:function(e){BX.Dom.append(BX.Landing.UI.Field.BaseField.createError(e),this.error);BX.Dom.style(this.description,"margin-bottom",null)},hideError:function(){BX.Dom.clean(this.error);BX.Dom.style(this.description,"margin-bottom","0px")}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:63:"/bitrix/js/landing/ui/field/embed_bg_field.min.js?1708115049939";s:6:"source";s:45:"/bitrix/js/landing/ui/field/embed_bg_field.js";s:3:"min";s:49:"/bitrix/js/landing/ui/field/embed_bg_field.min.js";s:3:"map";s:49:"/bitrix/js/landing/ui/field/embed_bg_field.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Field");const n=BX.Landing.Utils.bind;const e=BX.Landing.Utils.fireCustomEvent;const i=BX.Landing.Utils.getQueryParams;const t=BX.Landing.Utils.remove;const d=BX.Landing.Utils.create;BX.Landing.UI.Field.EmbedBg=function(n){n.description="<span class='landing-ui-anchor-preview'>"+BX.Landing.Loc.getMessage("LANDING_EMBED_BG_FIELD_DESCRIPTION")+"</span>";BX.Landing.UI.Field.Embed.apply(this,arguments);BX.Dom.addClass(this.error,"landing-ui-error")};BX.Landing.UI.Field.EmbedBg.isBgVideo=true;BX.Landing.UI.Field.EmbedBg.prototype={constructor:BX.Landing.UI.Field.EmbedBg,__proto__:BX.Landing.UI.Field.Embed.prototype,isEmbedUrl:function(n){return BX.Landing.Utils.Matchers.youtube.test(n)||BX.Landing.Utils.Matchers.vk.test(n)},getValue:function(){const n=BX.Landing.UI.Field.Embed.prototype.getValue.call(this);delete n.ratio;return n}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:60:"/bitrix/js/landing/ui/field/date_field.min.js?17081150491896";s:6:"source";s:41:"/bitrix/js/landing/ui/field/date_field.js";s:3:"min";s:45:"/bitrix/js/landing/ui/field/date_field.min.js";s:3:"map";s:45:"/bitrix/js/landing/ui/field/date_field.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Field");var t=BX.Landing.Utils.create;var e=BX.Landing.Utils.bind;var i=BX.Landing.Utils.fireCustomEvent;var a="s";var n="ms";BX.Landing.UI.Field.Date=function(i){i.textOnly=true;BX.Landing.UI.Field.BaseField.apply(this,arguments);this.format=i.format===a||i.format===n?i.format:a;this.time=i.time===true;this.hiddenInput=t("input",{props:{type:"hidden"},value:i.content});e(this.input,"click",this.onInputClick.bind(this));this.setValue(this.formatDateToValue(i.content))};BX.Landing.UI.Field.Date.prototype={constructor:BX.Landing.UI.Field.Date,__proto__:BX.Landing.UI.Field.BaseField.prototype,onInputClick:function(){var t={node:this.input,field:this.hiddenInput,bTime:this.time,value:BX.date.format(this.getFormat(),new Date(this.formatDateToValue(this.hiddenInput.value)*1e3)),bHideTime:!this.time,callback_after:function(t){this.setValue(t.getTime()/1e3)}.bind(this)};return top.BX.calendar(t)},getFormat:function(){return BX.date.convertBitrixFormat(BX.Landing.Loc.getMessage(this.time?"FORMAT_DATETIME":"FORMAT_DATE"))},reset:function(){this.setValue("")},setValue:function(t){if(t){this.input.innerText=BX.date.format(this.getFormat(),new Date(t*1e3));this.hiddenInput.value=this.formatValue(t);this.onValueChangeHandler(this);var e=new BX.Event.BaseEvent({data:{value:this.getValue()},compatData:[this.getValue()]});this.emit("change",e)}},formatValue:function(t){switch(this.format){case a:return t;case n:return t*1e3;default:break}},formatDateToValue:function(t){switch(this.format){case a:return t;case n:return t/1e3;default:break}},getValue:function(){return this.formatValue(this.formatDateToValue(this.hiddenInput.value))},clone:function(t){var e=Object.assign({},t||this.data,{content:(new Date).getTime()});var i=new this.constructor(e);if(this.type){i.type=this.type}return i}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:68:"/bitrix/js/landing/ui/field/block_source_field.min.js?17081150491561";s:6:"source";s:49:"/bitrix/js/landing/ui/field/block_source_field.js";s:3:"min";s:53:"/bitrix/js/landing/ui/field/block_source_field.min.js";s:3:"map";s:53:"/bitrix/js/landing/ui/field/block_source_field.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Field");BX.Landing.UI.Field.BlockSource=function(e){BX.Landing.UI.Field.BaseField.apply(this,arguments);BX.Landing.Utils.addClass(this.layout,"landing-ui-field-block-source");this.onSourceChangeHandler=e.onSourceChange;this.value=e.value;this.sourceField=this.createLinkField();this.layout.innerHTML="";BX.Landing.Utils.append(this.sourceField.layout,this.layout)};BX.Landing.UI.Field.BlockSource.prototype={constructor:BX.Landing.UI.Field.BlockSource,__proto__:BX.Landing.UI.Field.BaseField.prototype,getSources:function(){return BX.Landing.Main.getInstance().options.sources},createLinkField:function(){return new BX.Landing.UI.Field.LinkUrl({selector:"source",title:BX.Landing.Loc.getMessage("LANDING_BLOCK__SOURCE_TITLE"),textOnly:true,disableCustomURL:true,disablePages:true,disallowType:true,allowedTypes:[BX.Landing.UI.Field.LinkUrl.TYPE_BLOCK],customPlaceholder:BX.Landing.Loc.getMessage("LANDING_BLOCK__BLOCK_SOURCE_PLACEHOLDER"),options:{siteId:BX.Landing.Main.getInstance().options.site_id,landingId:BX.Landing.Main.getInstance().id,filter:{"=TYPE":BX.Landing.Main.getInstance().options.params.type}},content:this.value,onValueChange:function(e){var n=null;if(BX.type.isPlainObject(e)&&BX.type.isPlainObject(e.source)){n=Object.keys(e.source)[0]}var i=this.getSources().find((function(e){return e.id===n}));setTimeout(function(){this.onSourceChangeHandler(i)}.bind(this),0)}.bind(this)})},getValue:function(){return this.sourceField.getValue()}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:69:"/bitrix/js/landing/ui/field/dynamic_image_field.min.js?17081150491947";s:6:"source";s:50:"/bitrix/js/landing/ui/field/dynamic_image_field.js";s:3:"min";s:54:"/bitrix/js/landing/ui/field/dynamic_image_field.min.js";s:3:"map";s:54:"/bitrix/js/landing/ui/field/dynamic_image_field.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Field");BX.Landing.UI.Field.DynamicImage=function(e){BX.Landing.UI.Field.BaseField.apply(this,arguments);BX.addClass(this.layout,"landing-ui-field-dynamic-image");BX.remove(this.input);this.reference=e.reference;this.linkField=e.linkField;this.dropdownField=new BX.Landing.UI.Field.Dropdown({title:e.title,items:e.dropdownItems,content:BX.type.isPlainObject(e.value)?e.value.id:undefined});this.checkboxField=new BX.Landing.UI.Field.Checkbox({title:BX.Landing.Loc.getMessage("LANDING_BLOCK__DYNAMIC_LINK_ACTION_FIElD_LABEL"),items:[{name:BX.Landing.Loc.getMessage("LANDING_BLOCK__DYNAMIC_IMAGE_MAKE_LINK_TO_DETAIL"),value:true,checked:function(){if(BX.type.isPlainObject(e.value)){return[true,"true"].includes(e.value.link)}return false}()}],multiple:false});BX.remove(this.dropdownField.header);BX.remove(this.checkboxField.header);this.grid=this.createGrid();this.dropdownContainer=this.grid.children[0];this.checkboxContainer=this.grid.children[1];this.layout.appendChild(this.grid);this.dropdownContainer.appendChild(this.dropdownField.layout);if(!e.hideCheckbox){this.checkboxContainer.appendChild(this.checkboxField.layout)}if(BX.type.isPlainObject(e.value)){this.setValue(e.value)}};BX.Landing.UI.Field.DynamicImage.prototype={constructor:BX.Landing.UI.Field.DynamicImage,__proto__:BX.Landing.UI.Field.BaseField.prototype,createGrid:function(){return BX.create({tag:"div",props:{className:"landing-ui-field-dynamic-image-grid"},children:[BX.create({tag:"div",props:{className:"landing-ui-field-dynamic-image-grid-reference"}}),BX.create({tag:"div",props:{className:"landing-ui-field-dynamic-image-grid-link"}})]})},getValue:function(){return{id:this.dropdownField.getValue(),link:this.checkboxField.getValue()}},setValue:function(e){if(BX.type.isPlainObject(e)){this.dropdownField.setValue(e.id);this.checkboxField.setValue(e.link)}}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:71:"/bitrix/js/landing/ui/field/dynamic_dropdown_field.min.js?1708115049430";s:6:"source";s:53:"/bitrix/js/landing/ui/field/dynamic_dropdown_field.js";s:3:"min";s:57:"/bitrix/js/landing/ui/field/dynamic_dropdown_field.min.js";s:3:"map";s:57:"/bitrix/js/landing/ui/field/dynamic_dropdown_field.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Field");BX.Landing.UI.Field.DynamicDropdown=function(n){BX.Landing.UI.Field.DynamicImage.apply(this,arguments);BX.addClass(this.layout,"landing-ui-field-dynamic-dropdown")};BX.Landing.UI.Field.DynamicDropdown.prototype={constructor:BX.Landing.UI.Field.DynamicDropdown,__proto__:BX.Landing.UI.Field.DynamicImage.prototype}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:61:"/bitrix/js/landing/ui/field/pages_field.min.js?17081150491478";s:6:"source";s:42:"/bitrix/js/landing/ui/field/pages_field.js";s:3:"min";s:46:"/bitrix/js/landing/ui/field/pages_field.min.js";s:3:"map";s:46:"/bitrix/js/landing/ui/field/pages_field.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Field");BX.Landing.UI.Field.Pages=function(e){BX.Landing.UI.Field.BaseField.apply(this,arguments);BX.remove(this.input);this.layout.classList.add("landing-ui-field-pages");this.rangeField=this.createRangeField(Number(e.value));this.gridLeft=this.createGridLeft();this.gridRight=this.createGridRight();this.grid=this.createGrid([this.gridLeft,this.gridRight]);this.layout.appendChild(this.grid);this.gridLeft.appendChild(this.rangeField.layout)};BX.Landing.UI.Field.Pages.prototype={constructor:BX.Landing.UI.Field.Pages,__proto__:BX.Landing.UI.Field.BaseField.prototype,createRangeField:function(e){var i=new BX.Landing.UI.Field.Range({items:Array.from({length:100},function(e,i){return{name:i,value:i}}),content:BX.type.isNumber(e)?e:undefined});BX.remove(i.header);return i},createGridLeft:function(){return BX.create("div",{props:{className:"landing-ui-field-pages-grid-left"}})},createGridRight:function(){return BX.create("div",{props:{className:"landing-ui-field-pages-grid-right"}})},createGrid:function(e){return BX.create("div",{props:{className:"landing-ui-field-pages-grid"},children:e})},createButtonField:function(){return new BX.Landing.UI.Button.BaseButton({text:BX.Landing.Loc.getMessage("LANDING_CARDS__ADD_NEW_PAGE_BUTTON"),className:["landing-ui-button-select-link","landing-ui-field-pages-add-button"]})},getValue:function(){return this.rangeField.getValue()}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:68:"/bitrix/js/landing/ui/field/click_action_field.min.js?17081150492334";s:6:"source";s:49:"/bitrix/js/landing/ui/field/click_action_field.js";s:3:"min";s:53:"/bitrix/js/landing/ui/field/click_action_field.min.js";s:3:"map";s:53:"/bitrix/js/landing/ui/field/click_action_field.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Field");BX.Landing.UI.Field.ClickAction=function(i){BX.Landing.UI.Field.BaseField.apply(this,arguments);BX.addClass(this.layout,"landing-ui-field-click-action");BX.remove(this.input);this.reference=i.reference;this.linkField=i.linkField;this.textField=new BX.Landing.UI.Field.Text({title:BX.Landing.Loc.getMessage("LANDING_BLOCK__DYNAMIC_LINK_TEXT_FIELD_LABEL"),textOnly:true,content:i.content||""});this.actionField=new BX.Landing.UI.Field.Dropdown({title:BX.Landing.Loc.getMessage("LANDING_BLOCK__DYNAMIC_LINK_ACTION_FIElD_LABEL"),items:this.getActions(),onValueChange:this.onActionChange.bind(this)});this.grid=this.createGrid();this.textContainer=this.grid.children[0];this.actionContainer=this.grid.children[1];this.additionalContainer=this.grid.children[2];this.layout.appendChild(this.grid);this.textContainer.appendChild(this.textField.layout);this.actionContainer.appendChild(this.actionField.layout);if(BX.type.isPlainObject(i.value)){this.setValue(i.value)}this.onActionChange()};BX.Landing.UI.Field.ClickAction.prototype={constructor:BX.Landing.UI.Field.ClickAction,__proto__:BX.Landing.UI.Field.BaseField.prototype,createGrid:function(){return BX.create({tag:"div",props:{className:"landing-ui-field-click-action-grid"},children:[BX.create({tag:"div",props:{className:"landing-ui-field-click-action-grid-text"}}),BX.create({tag:"div",props:{className:"landing-ui-field-click-action-grid-action"}}),BX.create({tag:"div",props:{className:"landing-ui-field-click-action-layout-additional"}})]})},getActions:function(){return this.reference.actions.map(function(i){return{name:i.name,value:i.type}})},onActionChange:function(){var i=this.actionField.getValue();if(i==="link"){this.additionalContainer.appendChild(this.linkField.layout);return}this.additionalContainer.innerHTML=""},getValue:function(){var i=this.linkField.getValue();if(BX.type.isPlainObject(i)){delete i.text}return{id:this.reference.id,text:this.textField.getValue(),action:this.actionField.getValue(),link:i}},setValue:function(i){if(BX.type.isPlainObject(i)){this.textField.setValue(i.text);this.actionField.setValue(i.action);if(i.link){this.linkField.setValue(i.link,true);this.linkField.hrefInput.makeDisplayedHrefValue()}this.onActionChange()}}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:61:"/bitrix/js/landing/ui/field/color_field.min.js?17081150492119";s:6:"source";s:42:"/bitrix/js/landing/ui/field/color_field.js";s:3:"min";s:46:"/bitrix/js/landing/ui/field/color_field.min.js";s:3:"map";s:46:"/bitrix/js/landing/ui/field/color_field.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI.Field");BX.Landing.UI.Field.ColorPalette=function(t){BX.Landing.UI.Field.ButtonGroup.apply(this,arguments);this.pseudoElement=typeof t.pseudoElement==="string"?t.pseudoElement:null;this.pseudoClass=typeof t.pseudoClass==="string"?t.pseudoClass:null;this.layout.classList.add("landing-ui-field-color");this.stylePath=t.stylePath;this.initButtons()};function t(t,e,s){var n=document.styleSheets;var o=n.length;for(var l=0;l<o;l++){if("href"in document.styleSheets[l]&&(document.styleSheets[l].href&&document.styleSheets[l].href.indexOf("/templates/landing24/")!==-1||document.styleSheets[l].href&&document.styleSheets[l].href.indexOf("/landing24/template_")!==-1||document.styleSheets[l].href&&document.styleSheets[l].href.indexOf("/landing24/kernel_landing_assets_")!==-1)||s&&document.styleSheets[l].href&&document.styleSheets[l].href.indexOf(s)!==-1){var i=document.styleSheets[l].cssRules;if(i){var a=i.length;for(var u=0;u<a;u++){if(i[u].selectorText===t){return i[u].style[e]}}}}}}BX.Landing.UI.Field.ColorPalette.prototype={constructor:BX.Landing.UI.Field.ColorPalette,__proto__:BX.Landing.UI.Field.ButtonGroup.prototype,initButtons:function(){this.buttons.forEach(function(e){e.layout.classList.add(e.layout.value);e.layout.innerHTML='<span class="landing-ui-button-inner landing-ui-pattern-transparent"></span>';var s=BX.Landing.UI.Adapter.CSSProperty.get(this.property);if((s!=="background-image"&&s!=="background-color"||this.pseudoElement)&&!this.pseudoClass){BX.DOM.read(function(){var t=getComputedStyle(e.layout,this.pseudoElement).getPropertyValue(s);BX.DOM.write(function(){e.layout.classList.remove(e.layout.value);e.layout.style["background-color"]=t})}.bind(this))}else if(this.pseudoClass){BX.DOM.read(function(){var n=t("."+e.layout.value+this.pseudoClass,s,this.stylePath);BX.DOM.write(function(){e.layout.classList.remove(e.layout.value);e.layout.style["background-color"]=n})}.bind(this))}},this)},reset:function(){this.buttons.forEach(function(t){t.layout.classList.remove("landing-ui-active")})}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:54:"/bitrix/js/landing/ui/style_node.min.js?17081150495255";s:6:"source";s:35:"/bitrix/js/landing/ui/style_node.js";s:3:"min";s:39:"/bitrix/js/landing/ui/style_node.min.js";s:3:"map";s:39:"/bitrix/js/landing/ui/style_node.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.UI");const e=BX.Landing.Utils.slice;BX.Landing.UI.Style=function(e){this.node="node"in e?e.node:null;this.id="id"in e?e.id:null;this.selector="selector"in e?e.selector:null;this.relativeSelector="relativeSelector"?e.relativeSelector:null;this.clickHandler="onClick"in e?e.onClick:function(){};this.iframe="iframe"in e?e.iframe:null;this.affects=new BX.Landing.Collection.BaseCollection;this.inlineProperties=[];this.computedProperties=[];this.pseudoElement=null;this.isSelectGroupFlag=null;this.onFrameLoad()};BX.Landing.UI.Style.SERVICE_CLASSES=["landing-card","slick-slide","slick-current","slick-active"];BX.Landing.UI.Style.prototype={onFrameLoad:function(){if(this.node){this.node=BX.type.isArray(this.node)?this.node:[this.node]}else{this.node=this.getNode(true)}this.currentTarget=this.node[0];this.node.forEach((function(e){e.addEventListener("click",this.onClick.bind(this));e.addEventListener("mouseover",this.onMouseEnter.bind(this));e.addEventListener("mouseleave",this.onMouseLeave.bind(this))}),this);this.value=this.getValue()},getNode:function(t){const i=e(this.iframe.document.querySelectorAll(this.relativeSelector));if(this.isSelectGroup()||t){return i}return this.currentTarget?[i[this.getElementIndex(this.currentTarget)]]:[]},getTargetElement:function(){return this.currentTarget},getElementIndex:function(e){return[].indexOf.call(this.getNode(true),e)},onClick:function(e){if(BX.Landing.UI.Panel.StylePanel.getInstance().isShown()){e.preventDefault();e.stopPropagation();this.currentTarget=e.currentTarget;this.clickHandler()}},onMouseEnter:function(e){e.preventDefault();e.stopPropagation();this.highlight(e.currentTarget)},onMouseLeave:function(e){e.preventDefault();e.stopPropagation();this.unHighlight();var t=BX.type.isArray(this.node)&&this.node.length?this.node[0]:this.node;BX.fireEvent(t.parentNode,"mouseenter")},isSelectGroup:function(){if(this.isSelectGroupFlag!==null){return this.isSelectGroupFlag}return window.localStorage.getItem("selectGroup")==="true"},setIsSelectGroup:function(e){this.isSelectGroupFlag=!!e},unsetIsSelectGroupFlag:function(){this.isSelectGroupFlag=null},highlight:function(e){if(BX.Landing.UI.Panel.StylePanel.getInstance().isShown()){if(this.isSelectGroup()){e=this.node}BX.Landing.UI.Highlight.getInstance().show(e)}},unHighlight:function(){BX.Landing.UI.Highlight.getInstance().hide()},isChanged:function(){const e=this.getValue();if(JSON.stringify(this.value)!==JSON.stringify(e)){return true}else{return this.lastValue!==undefined&&JSON.stringify(this.lastValue)!==JSON.stringify(e)}},setInlineProperty:function(e){if(!BX.Type.isArray(e)){e=[e]}e.forEach((function(e){if(this.inlineProperties.indexOf(e)===-1){this.inlineProperties.push(e)}}),this);this.value=this.getValue()},setComputedProperty:function(e){if(!BX.Type.isArray(e)){e=[e]}e.forEach((function(e){if(this.computedProperties.indexOf(e)===-1){this.computedProperties.push(e)}}),this);this.value=this.getValue()},setPseudoElement:function(e){this.pseudoElement=e;this.value=this.getValue()},setValue:function(t,i,n,s,l){this.lastValue=this.currentValue;this.currentValue=this.getValue();if(!t){return}s=!!s?s:"";if(s.length){this.setAffects(s)}if(BX.type.isObjectLike(t)){if("from"in t&&"to"in t){t.from+="-min";t.to+="-max"}if(!("style"in t)){var r=Object.keys(t);t=r.map((function(e){return t[e]}))}}else{t=[t]}this.getNode().forEach((function(n){if(BX.type.isArray(t)){this.setValueClass(n,t,i,s)}if(BX.type.isObjectLike(t)){if("style"in t){this.setValueStyle(n,t.style)}if("className"in t&&BX.type.isArray(t.className)){this.setValueClass(n,t.className,i,s)}}if(s){if(s!=="background-image"){e(n.querySelectorAll("*")).forEach((function(e){e.style[s]=null;if(s==="color"){e.removeAttribute("color")}}))}}if(l){l.items.forEach((function(e){n.classList.remove(e.value)}))}}),this)},setAffects(e){e=BX.Type.isArray(e)?e:[e];e.forEach((e=>{if(e!=="background-image"){this.affects.add(e)}}))},setValueClass:function(e,t,i,n){if(BX.type.isArray(i)){e.style[n]=null;t.forEach((function(n){i.forEach((function(i){if(t.indexOf(i.value)===-1&&t.indexOf(i.value+"-min")===-1&&t.indexOf(i.value+"-max")===-1){e.classList.remove(i.value);e.classList.remove(i.value+"-min");e.classList.remove(i.value+"-max")}}));e.classList.add(n)}))}},setValueStyle:function(e,t){this.inlineProperties.forEach((function(i){if(i in t){e.style.setProperty(i,t[i])}}))},getValue:function(t){const i=this.getNode().length?this.getNode()[0]:null;const n={};if(i){let e=false;if(this.inlineProperties.length){e=true;const t=i.style;this.inlineProperties.forEach((i=>{n[i]=t.getPropertyValue(i).trim()||null;if(i==="background-image"&&!!n[i]){n[i]=n[i].replaceAll('"',"'")}e=e&&!!n[i]}))}if(!!t&&this.computedProperties.length&&!e){this.computedProperties.forEach((e=>{n[e]=getComputedStyle(i,this.pseudoElement).getPropertyValue(e)||null}))}}return{classList:i?this.sanitizeClassList(e(i.classList)):[],affect:this.affects.toArray(),style:n}},sanitizeClassList:function(e){const t=[];e.forEach((e=>{if(BX.Landing.UI.Style.SERVICE_CLASSES.indexOf(e)===-1){t.push(e)}}));return t},sanitizeClassName:function(e){return this.sanitizeClassList(e.split(" ")).join(" ")}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:58:"/bitrix/js/landing/events/block_event.min.js?1708115049520";s:6:"source";s:40:"/bitrix/js/landing/events/block_event.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
(function(){"use strict";BX.namespace("BX.Landing.Event");BX.Landing.Event.Block=function(n){this.block=typeof n.block==="object"?n.block:null;this.card=typeof n.card==="object"?n.card:null;this.node=typeof n.node==="object"?n.node:null;this.data=typeof n.data!=="undefined"?n.data:null;this.forceInitHandler=typeof n.onForceInit==="function"?n.onForceInit:function(){}};BX.Landing.Event.Block.prototype={forceInit:function(){this.forceInitHandler()},makeRelativeSelector:function(n){return"#"+this.block.id+" "+n}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:45:"/bitrix/js/landing/group.min.js?1708115049576";s:6:"source";s:27:"/bitrix/js/landing/group.js";s:3:"min";s:31:"/bitrix/js/landing/group.min.js";s:3:"map";s:31:"/bitrix/js/landing/group.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing");BX.Landing.Group=function(n){this.id=n.id;this.name=typeof n.name==="string"?n.name:null;this.nodes=n.nodes;this.callback=typeof n.onClick==="function"?n.onClick:function(){};var i=this.onClick.bind(this);this.nodes.forEach(function(n){n.node.addEventListener("click",i)})};BX.Landing.Group.prototype={onClick:function(n){if(!BX.Landing.UI.Panel.StylePanel.getInstance().isShown()){n.preventDefault();n.stopPropagation();n.stopImmediatePropagation();this.callback(this);return false}}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:47:"/bitrix/js/landing/block.min.js?170811504981296";s:6:"source";s:27:"/bitrix/js/landing/block.js";s:3:"min";s:31:"/bitrix/js/landing/block.min.js";s:3:"map";s:31:"/bitrix/js/landing/block.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing");var e=BX.Landing.Utils.deepFreeze;var t=BX.Landing.Utils.style;var n=BX.Landing.Utils.insertAfter;var i=BX.Landing.Utils.insertBefore;var s=BX.Landing.Utils.append;var a=BX.Landing.Utils.isPlainObject;var o=BX.Landing.Utils.isBoolean;var r=BX.Landing.Utils.isNumber;var c=BX.Landing.Utils.isString;var d=BX.Landing.Utils.isArray;var l=BX.Landing.Utils.isEmpty;var h=BX.Landing.Utils.addClass;var u=BX.Landing.Utils.removeClass;var g=BX.Landing.Utils.hasClass;var f=BX.Landing.Utils.toggleClass;var m=BX.Landing.Utils.create;var p=BX.Landing.Utils.debounce;var B=BX.Landing.Utils.throttle;var v=BX.Landing.Utils.fireCustomEvent;var b=BX.Landing.Utils.onCustomEvent;var L=BX.Landing.Utils.bind;var y=BX.Landing.Utils.unbind;var k=BX.Landing.Utils.getClass;var C=BX.Landing.Utils.rect;var I=BX.Landing.Utils.setTextContent;var X=BX.Landing.Utils.translateY;var _=BX.Landing.Utils.nextSibling;var T=BX.Landing.Utils.prevSibling;var A=BX.Landing.Utils.join;var E=BX.Landing.Utils.slice;var O=BX.Landing.Utils.decodeDataValue;var M=BX.Landing.Utils.encodeDataValue;var w=BX.Landing.Utils.data;var N=BX.Landing.Utils.attr;var S=BX.Landing.Utils.removePanels;var P=BX.Landing.Utils.getCSSSelector;var F=BX.Landing.Utils.remove;var D=BX.Landing.Utils.clone;var U=BX.Landing.Utils.trim;var x=BX.Landing.Utils.prepend;var j=BX.Landing.Utils.random;var R=BX.Landing.Utils.htmlToElement;var V=BX.Landing.Utils.proxy;var G=BX.Landing.Utils.escapeText;var K=BX.Landing.Utils.isValidElementId;var q=BX.Landing.Collection.BaseCollection;var H=BX.Landing.Collection.NodeCollection;var W=BX.Landing.UI.Collection.FormCollection;var Y=BX.Landing.Collection.CardCollection;var z=BX.Landing.UI.Collection.PanelCollection;var J=BX.Landing.UI.Panel.BaseButtonPanel;var Q=BX.Landing.UI.Panel.CardAction;var Z=BX.Landing.UI.Panel.ContentEdit;var $=BX.Landing.UI.Button.BaseButton;var ee=BX.Landing.UI.Button.ActionButton;var te=BX.Landing.UI.Button.Plus;var ne=BX.Landing.UI.Button.CardAction;var ie=BX.Landing.UI.Factory.StyleFactory;var se=BX.Landing.UI.Form.BaseForm;var ae=BX.Landing.UI.Form.StyleForm;var oe=BX.Landing.UI.Form.CardForm;var re=BX.Landing.UI.Form.CardsForm;var ce=BX.Landing.Group;var de=BX.Landing.Event.Block;var le=BX.Landing.UI.Card.TabCard;var he=BX.Landing.UI.Card.DynamicFieldsGroup;var ue="D";var ge="V";var fe="W";var me="X";function pe(e){let t=BX.Landing.Main.getInstance();let n=Object.keys(t.options.style);for(let i=0;i<n.length;i++){let s=n[i];let a=t.options.style[s]["style"][e];if(!a){continue}a.attrKey=e;if(e==="background"){a.items=a.items.concat(t.options.style[s]["style"]["background-overlay"].items)}return a}return null}function Be(e){let t=BX.Landing.Main.getInstance();let n=Object.keys(t.options.attrs);for(let i=0;i<n.length;i++){let s=n[i];let a=t.options.attrs[s]["attrs"][e];if(!a){continue}a.attrKey=e;return a}return{}}function ve(e){let t=BX.Landing.Main.getInstance();let n=Object.keys(t.options.style);for(let i=0;i<n.length;i++){let s=n[i];if(!t.options.style[s]["group"]){continue}if(e in t.options.style[s]["group"]){return true}}return false}function be(e){let t=BX.Landing.Main.getInstance();let n=Object.keys(t.options.style);for(let i=0;i<n.length;i++){let s=n[i];if(!t.options.style[s]["group"]){continue}if(t.options.style[s]["group"][e]){return t.options.style[s]["group"][e]}}return[]}function Le(e){if(!!e){if(!e.loader){e.loader=new BX.Loader({target:e.layout,size:16});void t(e.loader.layout.querySelector(".main-ui-loader-svg-circle"),{"stroke-width":"4px"})}e.loader.show();h(e.text,"landing-ui-hide-icon")}}function ye(e){if(!!e){if(e.loader){e.loader.hide();u(e.text,"landing-ui-hide-icon")}}}function ke(e){return!!e&&e.includes("@")}var Ce=BX.debounce((function(){BX.Landing.PageObject.getBlocks().forEach((function(e){e.adjustSortButtonsState()}))}),400);b("BX.Landing.Block:init",Ce);BX.Landing.Block=function(t,n){this.node=t;this.parent=t.parentElement;this.content=t.firstElementChild;this.siteId=w(t.parentElement,"data-site");this.lid=w(t.parentElement,"data-landing");this.id=r(parseInt(n.id))?parseInt(n.id):0;this.selector=A("#block",r(n.id)?n.id:0," > :first-child");this.repoId=r(n.repoId)?n.repoId:null;this.active=o(n.active)?n.active:true;this.allowedByTariff=o(n.allowedByTariff)?n.allowedByTariff:true;this.manifest=a(n.manifest)?n.manifest:{};this.manifest.nodes=a(n.manifest.nodes)?n.manifest.nodes:{};this.manifest.cards=a(n.manifest.cards)?n.manifest.cards:{};this.manifest.attrs=a(n.manifest.attrs)?n.manifest.attrs:{};this.onStyleInputWithDebounce=p(this.onStyleInput,300,this);this.changeTimeout=null;this.php=n.php;this.designed=n.designed;this.access=n.access;this.anchor=n.anchor;this.savedAnchor=n.anchor;this.requiredUserActionOptions=n.requiredUserAction;this.dynamicParams=n.dynamicParams||{};this.sections=n.sections?n.sections.split(","):[];this.nodes=new H;this.cards=new Y;this.panels=new z;this.groups=new q;this.changedNodes=new q;this.styles=new q;this.forms=new W;this.menu=[];if(a(this.requiredUserActionOptions)&&!l(this.requiredUserActionOptions)){this.showRequiredUserAction(this.requiredUserActionOptions);this.requiredUserActionIsShown=true}this.onEditorEnabled=this.onEditorEnabled.bind(this);this.onEditorDisabled=this.onEditorDisabled.bind(this);this.adjustPanelsPosition=this.adjustPanelsPosition.bind(this);this.onMouseMove=this.onMouseMove.bind(this);this.onStorage=this.onStorage.bind(this);this.onBlockRemove=this.onBlockRemove.bind(this);e(this.manifest);this.node.classList[this.active?"remove":"add"]("landing-block-disabled");this.state="ready";this.initPanels();this.initStyles();this.initMenu();this.adjustContextSensitivityStyles();var i=BX.Landing.Env.getInstance().getOptions();var s=i.specialType;if(this.isDefaultCrmFormBlock()){var c={formId:i.formEditorData.formOptions.id,formOptions:this.getCrmFormOptions(),block:this,showWithOptions:true};var d=new BX.Uri(window.top.location.toString());if(BX.Text.toBoolean(d.getQueryParam("formCreated"))){c.state="presets"}void BX.Landing.UI.Panel.FormSettingsPanel.getInstance().show(c)}BX.Landing.PageObject.getBlocks().push(this);var h={};if(this.requiredUserActionIsShown){h.requiredUserActionIsShown=true;h.layout=this.node.firstElementChild;h.button=this.node.firstElementChild.querySelector(".ui-btn")}v(window,"BX.Landing.Block:init",[this.createEvent({data:h})]);b("BX.Landing.Editor:enable",this.onEditorEnabled);b("BX.Landing.Editor:disable",this.onEditorDisabled);b("BX.Landing.Block:afterRemove",this.onBlockRemove);L(this.node,"mousemove",this.onMouseMove);L(this.node,"keydown",this.adjustPanelsPosition);L(top,"storage",this.onStorage)};BX.Landing.Block.storage=new BX.Landing.Collection.BlockCollection;BX.Landing.Block.prototype={onMouseMove:function(){if(this.state==="ready"){y(this.node,"mousemove",this.onMouseMove);this.initEntities();this.lazyInitPanels();this.state="complete"}},getBlockNode:function(){return this.node},isAllowedByTariff:function(){return this.allowedByTariff},showRequiredUserAction:function(e){let t=this.node;if(e.targetNodeSelector){t=this.node.querySelector(e.targetNodeSelector)}t.innerHTML='<div class="landing-block-user-action">'+'<div class="landing-block-user-action-inner">'+(e.header?"<h3>"+'<i class="fa fa-exclamation-triangle g-mr-15"></i>'+e.header+"</h3><hr>":"")+(e.description?"<p>"+e.description+"</p>":"")+((e.href||e.onClick||e.className)&&e.text?"<div>"+'<a href="'+e.href+'" class="landing-trusted-link ui-btn '+e.className+'" target="'+(e.target?e.target:"")+'">'+e.text+"</a>"+"</div>":"")+"</div>"+"</div>";if(e.onClick){var n=t.querySelector(".landing-block-user-action .ui-btn");L(n,"click",(function(t){t.preventDefault();try{BX.evalGlobal(e.onClick)}catch(e){console.error(e)}}))}},disableLinks:function(){var e="a:not([class*='landing-ui']):not(.landing-trusted-link), .btn:not([class*='landing-ui']):not(.landing-trusted-link), button:not([class*='landing-ui']):not(.landing-trusted-link), input:not([class*='landing-ui'])";var t=E(this.content.querySelectorAll(e));t.forEach((function(e){var t=this.nodes.some((function(t){return t.node.contains(e)}));var n=this.menu.some((function(t){return t.root.contains(e)}));if(!this.nodes.getByNode(e)&&!t&&!n){e.style.pointerEvents="none"}}),this)},adjustContextSensitivityStyles:function(){if(g(this.parent,"landing-sidebar")){if(!g(this.content,"landing-adjusted")){var e=Object.keys(this.manifest.style.nodes);var t=e.filter((function(e){return!!this.manifest.style.nodes[e].type&&this.manifest.style.nodes[e].type.indexOf("columns")!==-1}),this);if(l(t)){return}var n=pe("columns");if(n===null){return}t.forEach((function(e){var t=this.styles.get(e);if(t){t.setIsSelectGroup(true);t.setValue("col-lg-12",n.items);t.unsetIsSelectGroupFlag()}}),this);var i=this.styles.get(this.selector);if(i){i.setValue("landing-adjusted",["landing-adjusted"])}this.saveStyles()}}},forceInit:function(){this.onMouseMove()},createEvent:function(e){return new de({block:this.node,node:!!e&&!!e.node?e.node:null,card:!!e&&!!e.card?e.card:null,data:!!e&&e.data||{},onForceInit:this.forceInit.bind(this)})},initEntities:function(){this.initCards();this.initNodes();this.initGroups();this.disableLinks()},initMenu:function(){if(BX.type.isPlainObject(this.manifest.menu)){this.menu=Object.entries(this.manifest.menu).map((function(e){var t=e[0];var n=e[1];return new BX.Landing.Menu.Menu({code:t,root:this.node.querySelector(t),manifest:n,block:this.id})}),this)}},initCardsLabels:function(){this.cards.forEach((function(e){e.label=this.createCardLabel(e.node,e.manifest)}),this)},initGroups:function(){var e=[];var t=a(this.manifest.groups)?this.manifest.groups:{};this.nodes.forEach((function(t){if(c(t.manifest.group)&&!e.includes(t.manifest.group)){e.push(t.manifest.group)}}));e.forEach((function(e){var n=this.nodes.filter((function(t){return t.manifest.group===e})).reduce((function(e,t){var n=parseInt(t.selector.split("@")[1]);if(!e[n]){e[n]=new H}e[n].push(t);return e}),{});Object.keys(n).forEach((function(i){this.groups.add(new ce({id:e,name:t[e],nodes:n[i],onClick:this.onGroupClick.bind(this)}))}),this)}),this)},onGroupClick:function(e){if(!BX.Landing.UI.Panel.StylePanel.getInstance().isShown()){this.showContentPanel({name:e.name,nodes:e.nodes,compact:true,nodesOnly:true,showAll:true,hideCheckbox:true})}},initPanels:function(){if(!this.panels.get("create_action")){var e=new J("create_action","landing-ui-panel-create-action");e.addButton(new te("insert_after",{text:BX.Landing.Loc.getMessage("ACTION_BUTTON_CREATE"),onClick:B(this.addBlockAfterThis,600,this)}));e.show();this.addPanel(e);if(this.isCrmFormPage()){var t=new J("create_before_action","landing-ui-panel-create-before-action");t.addButton(new te("insert_before",{text:BX.Landing.Loc.getMessage("ACTION_BUTTON_CREATE"),onClick:B(this.addBlockBeforeThis,600,this)}));t.show();this.addPanel(t)}e.buttons[0].on("mouseover",this.onCreateButtonMouseover.bind(this));e.buttons[0].on("mouseout",this.onCreateButtonMouseout.bind(this))}},isLastChildInArea:function(){return this.parent.querySelector("[class*='block-wrapper']:last-of-type")===this.node},onCreateButtonMouseover:function(){if(this.isLastChildInArea()||g(this.parent,"landing-header")||g(this.parent,"landing-footer")){var e=BX.Landing.Main.getInstance().getLayoutAreas();if(e.length>1){var t=this.panels.get("create_action");var n=t.buttons.get("insert_after");switch(true){case g(this.parent,"landing-main"):n.setText([BX.Landing.Loc.getMessage("ACTION_BUTTON_CREATE"),BX.Landing.Loc.getMessage("LANDING_ADD_BLOCK_TO_MAIN")].join(" "));break;case g(this.parent,"landing-header"):n.setText([BX.Landing.Loc.getMessage("ACTION_BUTTON_CREATE"),BX.Landing.Loc.getMessage("LANDING_ADD_BLOCK_TO_HEADER")].join(" "));break;case g(this.parent,"landing-sidebar"):n.setText([BX.Landing.Loc.getMessage("ACTION_BUTTON_CREATE"),BX.Landing.Loc.getMessage("LANDING_ADD_BLOCK_TO_SIDEBAR")].join(" "));break;case g(this.parent,"landing-footer"):n.setText([BX.Landing.Loc.getMessage("ACTION_BUTTON_CREATE"),BX.Landing.Loc.getMessage("LANDING_ADD_BLOCK_TO_FOOTER")].join(" "));break}clearTimeout(this.fadeTimeout);this.fadeTimeout=setTimeout(function(){h(this.parent,"landing-area-highlight");e.forEach((function(e){if(e!==this.parent){h(e,"landing-area-fade")}}),this)}.bind(this),400)}}},onCreateButtonMouseout:function(){clearTimeout(this.fadeTimeout);if(this.isLastChildInArea()||g(this.parent,"landing-header")||g(this.parent,"landing-footer")){var e=BX.Landing.Main.getInstance().getLayoutAreas();if(e.length>1){var t=this.panels.get("create_action").buttons[0];t.setText(BX.Landing.Loc.getMessage("ACTION_BUTTON_CREATE"));u(this.parent,"landing-area-highlight");e.forEach((function(e){u(e,"landing-area-fade")}),this)}}},isInSidebar:function(){return!!this.node.closest(".landing-sidebar")},initSidebarActionPanel:function(){if(this.isInSidebar()&&!this.panels.contains("sidebar_actions")){var e=new J("sidebar_actions","landing-ui-panel-sidebar-actions");e.addButton(new ee("showSidebarActions",{onClick:this.onShowSidebarActionsClick.bind(this)}));this.addPanel(e);e.show()}},showFeedbackForm:function(){BX.Landing.Main.getInstance().showSliderFeedbackForm({blockName:this.manifest.block.name,blockCode:this.manifest.code,blockSection:this.manifest.block.section,landingId:BX.Landing.Main.getInstance().id,target:"blockActions"});if(this.blockActionsMenu){this.blockActionsMenu.close()}if(this.sidebarActionsMenu){this.sidebarActionsMenu.close()}},onShowSidebarActionsClick:function(e){var t=this.panels.get("sidebar_actions").buttons.get("showSidebarActions");if(!this.sidebarActionsMenu){this.sidebarActionsMenu=BX.Main.MenuManager.create({id:this.id+"_sidebar_actions",bindElement:t.layout,className:"landing-ui-block-actions-popup",angle:{position:"top",offset:95},offsetTop:-6,offsetLeft:-26,events:{onPopupClose:function(){this.panels.get("sidebar_actions").buttons.get("showSidebarActions").deactivate();u(this.node,"landing-ui-hover")}.bind(this)},items:[function(){if((a(this.manifest.nodes)||a(this.manifest.attrs))&&this.isAllowedByTariff()){return new BX.Main.MenuItem({id:"content",text:BX.Landing.Loc.getMessage("ACTION_BUTTON_CONTENT"),onclick:function(){this.onShowContentPanel();this.sidebarActionsMenu.close()}.bind(this)})}}.bind(this)(),function(){if(a(this.manifest.style)&&this.isAllowedByTariff()){return new BX.Main.MenuItem({id:"style",text:BX.Landing.Loc.getMessage("ACTION_BUTTON_STYLE"),onclick:function(){this.onStyleShow();this.sidebarActionsMenu.close()}.bind(this),className:this.access<ge?"landing-ui-disabled":""})}}.bind(this)(),function(){if(a(this.manifest.style)&&this.isAllowedByTariff()){return new BX.Main.MenuItem({id:"designblock",text:BX.Landing.Loc.getMessage("LANDING_BLOCKS_ACTIONS_DESIGN_BLOCK"),className:!this.isDesignBlockAllowed()?"landing-ui-disabled":"",onclick:function(){this.onDesignerBlockClick();this.sidebarActionsMenu.close()}.bind(this)})}}.bind(this)(),function(){if(this.isAllowedByTariff()){return new BX.Main.MenuItem({delimiter:true})}}.bind(this)(),function(){var e=BX.Landing.Main.getInstance().options.placements.blocks;if(a(e)&&(this.manifest.code in e||e["*"])){var t=[];if(this.manifest.code in e){Object.keys(e[this.manifest.code]).forEach((function(n){t.push(e[this.manifest.code][n])}),this)}if(e["*"]){Object.keys(e["*"]).forEach((function(n){t.push(e["*"][n])}),this)}if(t.length){if(typeof BX.Landing.PageObject.getRootWindow().BX.rest!=="undefined"&&typeof BX.Landing.PageObject.getRootWindow().BX.rest.AppLayout!=="undefined"){var n=["*",this.manifest.code];for(var i=0,s=n.length;i<s;i++){var o=BX.Landing.PageObject.getRootWindow().BX.rest.AppLayout.initializePlacement("LANDING_BLOCK_"+n[i]);if(o){o.prototype.refreshBlock=function(e,t){var n=BX.Landing.PageObject.getBlocks().get(e.id);if(n){n.reload().then(t)}}}}}return new BX.Main.MenuItem({id:"actions",text:BX.Landing.Loc.getMessage("ACTION_BUTTON_CONTENT_MORE"),items:t.map((function(e){return new BX.Main.MenuItem({id:"placement_"+e.id+"_"+j(),text:M(e.title),onclick:this.onPlacementClick.bind(this,e)})}),this),className:this.access<ge?"landing-ui-disabled":""})}}}.bind(this)(),new BX.Main.MenuItem({id:"down",text:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_BLOCK_ACTION_SORT_DOWN"),onclick:function(){this.moveDown();this.sidebarActionsMenu.close()}.bind(this)}),new BX.Main.MenuItem({id:"up",text:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_BLOCK_ACTION_SORT_UP"),onclick:function(){this.moveUp();this.sidebarActionsMenu.close()}.bind(this)}),new BX.Main.MenuItem({delimiter:true}),new BX.Main.MenuItem({id:"show_hide",text:BX.Landing.Loc.getMessage(this.isEnabled()?"ACTION_BUTTON_HIDE":"ACTION_BUTTON_SHOW"),className:!this.isChangeStateBlockAllowed()?"landing-ui-disabled":"",onclick:function(){this.onStateChange();this.sidebarActionsMenu.close()}.bind(this)}),new BX.Main.MenuItem({delimiter:true}),new BX.Main.MenuItem({text:BX.Landing.Loc.getMessage("ACTION_BUTTON_ACTIONS_CUT"),className:!this.isRemoveBlockAllowed()?"landing-ui-disabled":"",onclick:function(){BX.Landing.Main.getInstance().onCutBlock.bind(BX.Landing.Main.getInstance(),this)();this.sidebarActionsMenu.close()}.bind(this)}),new BX.Main.MenuItem({text:BX.Landing.Loc.getMessage("ACTION_BUTTON_ACTIONS_COPY"),onclick:function(){BX.Landing.Main.getInstance().onCopyBlock.bind(BX.Landing.Main.getInstance(),this)();this.sidebarActionsMenu.close()}.bind(this)}),new BX.Main.MenuItem({id:"block_paste",text:BX.Landing.Loc.getMessage("ACTION_BUTTON_ACTIONS_PASTE"),title:window.localStorage.landingBlockName,className:this.isPasteBlockAllowed()?"":"landing-ui-disabled",onclick:function(){BX.Landing.Main.getInstance().onPasteBlock.bind(BX.Landing.Main.getInstance(),this)();this.sidebarActionsMenu.close()}.bind(this)}),new BX.Main.MenuItem({delimiter:true}),new BX.Main.MenuItem({text:BX.Landing.Loc.getMessage("LANDING_BLOCKS_ACTIONS_FEEDBACK_BUTTON"),onclick:this.showFeedbackForm.bind(this)}),new BX.Main.MenuItem({text:BX.Landing.Loc.getMessage("LANDING_BLOCKS_ACTIONS_SAVE_BLOCK_BUTTON_MSGVER_1"),className:!this.isSaveBlockInLibraryAllowed()?"landing-ui-disabled":"",onclick:function(){this.saveBlock();this.sidebarActionsMenu.close()}.bind(this)}),new BX.Main.MenuItem({delimiter:true}),new BX.Main.MenuItem({id:"remove",text:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_BLOCK_ACTION_REMOVE"),onclick:function(){this.deleteBlock();this.sidebarActionsMenu.close()}.bind(this),className:!this.isRemoveBlockAllowed()?"landing-ui-disabled":""})]})}this.sidebarActionsMenu.show();h(this.node,"landing-ui-hover")},lazyInitPanels:function(){if(this.isInSidebar()){this.initSidebarActionPanel()}var e=BX.Landing.Main.getInstance().options.placements.blocks;if(!this.panels.contains("content_actions")&&(a(this.manifest.nodes)&&!l(this.manifest.nodes)||a(this.manifest.style)&&!l(this.manifest.style)||a(e)&&!l(e))){var t=new J("content_actions","landing-ui-panel-content-action");t.addButton(new ee("collapse",{html:"<span class='fas fa-caret-right'></span>",onClick:this.onCollapseActionPanel.bind(this),attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_BLOCK_ACTION_COLLAPSE")},separate:true}));if(this.isAllowedByTariff()){if(a(this.manifest.style)){t.addButton(new ee("designblock",{text:BX.Landing.Loc.getMessage("LANDING_BLOCKS_ACTIONS_DESIGN_BLOCK"),onClick:this.onDesignerBlockClick.bind(this),disabled:!this.isDesignBlockAllowed(),attrs:{title:BX.Landing.Loc.getMessage("LANDING_BLOCKS_ACTIONS_DESIGN_BLOCK")},separate:true}));t.addButton(new ee("style",{text:BX.Landing.Loc.getMessage("ACTION_BUTTON_STYLE"),onClick:this.onStyleShow.bind(this),disabled:!this.isStyleModifyAllowed(),attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_BLOCK_DESIGN")},separate:true}))}if(a(this.manifest.nodes)||a(this.manifest.attrs)){t.addButton(new ee("content",{text:BX.Landing.Loc.getMessage("ACTION_BUTTON_CONTENT"),onClick:this.onShowContentPanel.bind(this),attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_BLOCK_EDIT")},separate:true}))}}else{t.addButton(new ee("expired",{text:BX.Landing.Loc.getMessage("ACTION_BUTTON_EXPIRED"),separate:true}))}if(a(e)&&(this.manifest.code in e||e["*"])){var n=[];if(this.manifest.code in e){Object.keys(e[this.manifest.code]).forEach((function(t){n.push(e[this.manifest.code][t])}),this)}if(e["*"]){Object.keys(e["*"]).forEach((function(t){n.push(e["*"][t])}),this)}if(n.length){t.addButton(new ee("actions",{html:BX.Landing.Loc.getMessage("ACTION_BUTTON_CONTENT_MORE"),onClick:this.onPlacementButtonClick.bind(this,n),separate:true}));if(typeof BX.Landing.PageObject.getRootWindow().BX.rest!=="undefined"&&typeof BX.Landing.PageObject.getRootWindow().BX.rest.AppLayout!=="undefined"){var i=["*",this.manifest.code];for(var s=0,o=i.length;s<o;s++){var r=BX.Landing.PageObject.getRootWindow().BX.rest.AppLayout.initializePlacement("LANDING_BLOCK_"+i[s]);if(r){r.prototype.refreshBlock=function(e,t){var n=BX.Landing.PageObject.getBlocks().get(e.id);if(n){n.reload().then(t)}}}}}}}if(a(this.manifest.style)){var c=new ee("block_display_info",{html:"&nbsp;",separate:true,onClick:this.onStyleShow.bind(this)});L(c.layout,"mouseenter",this.onBlockDisplayMouseenter.bind(this));L(c.layout,"mouseleave",this.onBlockDisplayMouseleave.bind(this));t.addButton(c)}t.show();this.addPanel(t)}if(!this.panels.get("block_action")){var d=new J("block_action","landing-ui-panel-block-action");var h=this.getBlockFromRepository(this.manifest.code);if(h&&h.restricted){var u=new ee("restricted",{html:"!",className:"landing-ui-block-restricted-button",onClick:this.onRestrictedButtonClick.bind(this),separate:true});L(u.layout,"mouseenter",this.onRestrictedButtonMouseenter.bind(this));L(u.layout,"mouseleave",this.onRestrictedButtonMouseleave.bind(this));d.addButton(u)}d.addButton(new ee("down",{html:BX.Landing.Loc.getMessage("ACTION_BUTTON_DOWN"),onClick:this.moveDown.bind(this),attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_BLOCK_ACTION_SORT_DOWN")}}));d.addButton(new ee("up",{html:BX.Landing.Loc.getMessage("ACTION_BUTTON_UP"),onClick:this.moveUp.bind(this),attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_BLOCK_ACTION_SORT_UP")}}));d.addButton(new ee("actions",{html:BX.Landing.Loc.getMessage("ACTION_BUTTON_ACTIONS"),onClick:this.showBlockActionsMenu.bind(this),attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_BLOCK_ACTION_ADDITIONAL_ACTIONS")}}));d.addButton(new ee("remove",{html:BX.Landing.Loc.getMessage("ACTION_BUTTON_REMOVE"),disabled:!this.isRemoveBlockAllowed(),onClick:this.deleteBlock.bind(this),attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_BLOCK_ACTION_REMOVE")}}));d.addButton(new ee("collapse",{html:"<span class='fas fa-caret-right'></span>",onClick:this.onCollapseActionPanel.bind(this),attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_BLOCK_ACTION_COLLAPSE")},separate:true}));d.show();this.addPanel(d)}this.adjustPanelsPosition();this.adjustSortButtonsState()},onCollapseActionPanel:function(){f(this.parent,"landing-ui-collapse")},getBlockFromRepository:function(e){var t=BX.Landing.Main.getInstance().options.blocks;var n=Object.keys(t);var i=n.find((function(n){return e in t[n].items}));if(i){return t[i].items[e]}},onRestrictedButtonClick:function(e){e.preventDefault()},onPlacementClick:function(e){BX.rest.AppLayout.openApplication(e.app_id,{ID:this.id,CODE:this.manifest.code,LID:BX.Landing.Main.getInstance().id},{PLACEMENT:"LANDING_BLOCK_"+e.placement,PLACEMENT_ID:e.id});if(this.blockPlacementsActionsMenu){this.blockPlacementsActionsMenu.close()}},onPlacementButtonClick:function(e){this.panels.get("content_actions").buttons.get("actions").activate();if(!this.blockPlacementsActionsMenu){var t=this.panels.get("content_actions").buttons.get("actions");var n=A("block_",this.id,"content_placement_actions_",j());var i=e.map((function(e){return new BX.Main.MenuItem({id:"placement_"+(e.id||j())+"_"+j(),text:M(e.title),disabled:e.disabled===true,onclick:typeof e.onClick==="function"?e.onClick:this.onPlacementClick.bind(this,e)})}),this);this.blockPlacementsActionsMenu=new BX.PopupMenuWindow({id:n,bindElement:t.layout,items:i,angle:{position:"top",offset:80},offsetTop:-6,events:{onPopupClose:function(){this.panels.get("content_actions").buttons.get("actions").deactivate();u(this.node,"landing-ui-hover")}.bind(this)}})}h(this.node,"landing-ui-hover");this.blockPlacementsActionsMenu.show()},onDesignerBlockClick:function(){var e=null;BX.Landing.Backend.getInstance().action("Block::getContent",{block:this.id,lid:this.lid,siteId:this.siteId,editMode:1}).then((function(t){e=t.content}));var t=BX.Landing.Env.getInstance().getOptions();var n=t.params.sef_url["design_block"].replace("__block_id__",this.id).replace("__site_show__",this.siteId).replace("__landing_edit__",this.lid)+"&code="+this.manifest.code+"&designed="+(this.designed?"Y":"N")+"&deviceCode="+BX.Landing.Main.getInstance().getDeviceCode();BX.SidePanel.Instance.open(n,{cacheable:false,allowChangeHistory:false,requestMethod:"post",customLeftBoundary:40,events:{onClose:function(t){BX.Landing.Backend.getInstance().action("Block::getContent",{block:this.id,lid:this.lid,siteId:this.siteId,editMode:1}).then(function(t){var n=t.content;if(e!==n){BX.Landing.History.getInstance().push();this.reload().then(function(){v("BX.Landing.Block:onDesignerBlockSave",[this.id])}.bind(this));var i=new BX.Landing.Metrika(true);i.sendLabel(null,"designerBlock","close"+"&designed="+(this.designed?"Y":"N")+"&code="+this.manifest.code)}}.bind(this))}.bind(this)}});if(this.blockPlacementsActionsMenu){this.blockPlacementsActionsMenu.close()}},isDesignBlockAllowed:function(){return!(this.access<fe||this.php||this.isCrmFormPage()&&this.isCrmFormBlock())},isStyleModifyAllowed:function(){return!(this.access<ge||l(this.manifest.style))},isEditBlockAllowed:function(){return this.access>=fe},isRemoveBlockAllowed:function(){return!(this.access<me||this.isCrmFormBlock()&&this.isDefaultCrmFormBlock())},isPasteBlockAllowed:function(){return window.localStorage.landingBlockId&&!this.isDefaultCrmFormBlock()},isSaveBlockInLibraryAllowed:function(){return!this.isDefaultCrmFormBlock()},isChangeStateBlockAllowed:function(){return!(this.access<fe||this.isDefaultCrmFormBlock())},saveBlock:function(){BX.Landing.Main.getInstance().showSaveBlock(this)},onRestrictedButtonMouseenter:function(e){clearTimeout(this.displayBlockTimer);this.displayBlockTimer=setTimeout(function(e){BX.Landing.UI.Tool.Suggest.getInstance().show(e,{description:BX.Landing.Loc.getMessage("LANDING_BLOCK_RESTRICTED_TEXT")})}.bind(this),200,e.currentTarget)},onRestrictedButtonMouseleave:function(){clearTimeout(this.displayBlockTimer);BX.Landing.UI.Tool.Suggest.getInstance().hide()},onBlockDisplayMouseenter:function(e){clearTimeout(this.displayBlockTimer);this.displayBlockTimer=setTimeout(function(e){BX.Landing.UI.Tool.Suggest.getInstance().show(e,{name:m("div",{props:{className:"landing-ui-block-display-message-header"},html:BX.Landing.Loc.getMessage("LANDING_BLOCK_DISABLED_ON_DESKTOP_NAME_2")}).outerHTML,description:this.getBlockDisplayItems()})}.bind(this),300,e.currentTarget)},onBlockDisplayMouseleave:function(){clearTimeout(this.displayBlockTimer);BX.Landing.UI.Tool.Suggest.getInstance().hide()},getBlockDisplayItems:function(){function e(e){return m("div",{props:{className:"landing-ui-block-display-message"},attrs:{"data-mod":e},children:[m("div",{props:{className:"landing-ui-block-display-message-left"},html:"&nbsp;"}),m("div",{props:{className:"landing-ui-block-display-message-right"},children:[m("p",{html:BX.Landing.Loc.getMessage("LANDING_BLOCK_HIDDEN_ON_"+(e?e.toUpperCase():""))})]})]})}var t=m("div");if(g(this.content,"l-d-lg-none")){t.appendChild(e("desktop"))}if(g(this.content,"l-d-md-none")){t.appendChild(e("tablet"))}if(g(this.content,"l-d-xs-none")){t.appendChild(e("mobile"))}return t.outerHTML},adjustPanelsPosition:function(){var e=C(this.node);var t=this.panels.get("content_actions");var n=this.panels.get("block_action");var i=e.height<80?h:u;if(t){i(t.layout,"landing-ui-panel-actions-compact")}if(n){i(n.layout,"landing-ui-panel-actions-compact")}},onEditorEnabled:function(e){if(this.node.contains(e)){h(this.node,"landing-ui-hover")}},onEditorDisabled:function(){u(this.node,"landing-ui-hover")},onStorage:function(){var e=this.blockActionsMenu||this.sidebarActionsMenu;if(e){var t=e.getMenuItem("block_paste");if(t){if(window.localStorage.landingBlockId){t.layout.item.setAttribute("title",window.localStorage.landingBlockName);u(t.layout.item,"landing-ui-disabled");h(t.layout.item,"menu-popup-no-icon")}else{t.layout.item.setAttribute("title","");h(t.layout.item,"landing-ui-disabled")}}}},showBlockActionsMenu:function(){this.panels.get("block_action").buttons.get("actions").activate();if(!this.blockActionsMenu){var e=g(this.node.parentElement,"landing-sidebar");var t=this.panels.get("block_action").buttons.get("actions");var n=A("block_",this.id,"_actions_",j());var i=BX.Landing.Main.getInstance();this.blockActionsMenu=new BX.PopupMenuWindow({id:n,bindElement:t.layout,className:"landing-ui-block-actions-popup",angle:{position:"top",offset:e?70:146},offsetTop:-6,offsetLeft:-26,events:{onPopupClose:function(){this.panels.get("block_action").buttons.get("actions").deactivate();u(this.node,"landing-ui-hover")}.bind(this),onPopupShow:function(){BX.Event.EventEmitter.emit("BX.Landing.PopupMenuWindow:onShow")}.bind(this)},items:[new BX.Main.MenuItem({id:"show_hide",text:BX.Landing.Loc.getMessage(this.isEnabled()?"ACTION_BUTTON_HIDE":"ACTION_BUTTON_SHOW"),className:!this.isChangeStateBlockAllowed()?"landing-ui-disabled":"",onclick:function(){this.onStateChange();this.blockActionsMenu.close()}.bind(this)}),new BX.Main.MenuItem({text:BX.Landing.Loc.getMessage("ACTION_BUTTON_ACTIONS_CUT"),className:!this.isRemoveBlockAllowed()?"landing-ui-disabled":"",onclick:function(){i.onCutBlock.bind(i,this)();this.blockActionsMenu.close()}.bind(this)}),new BX.Main.MenuItem({text:BX.Landing.Loc.getMessage("ACTION_BUTTON_ACTIONS_COPY"),className:this.isDefaultCrmFormBlock()?"landing-ui-disabled":"",onclick:function(){i.onCopyBlock.bind(i,this)();this.blockActionsMenu.close()}.bind(this)}),new BX.Main.MenuItem({id:"block_paste",text:BX.Landing.Loc.getMessage("ACTION_BUTTON_ACTIONS_PASTE"),title:window.localStorage.landingBlockName,className:this.isPasteBlockAllowed()?"":"landing-ui-disabled",onclick:function(){i.onPasteBlock.bind(i,this)();this.blockActionsMenu.close()}.bind(this)}),new BX.Main.MenuItem({text:BX.Landing.Loc.getMessage("LANDING_BLOCKS_ACTIONS_FEEDBACK_BUTTON"),onclick:this.showFeedbackForm.bind(this)}),new BX.Main.MenuItem({delimiter:true}),new BX.Main.MenuItem({text:BX.Landing.Loc.getMessage("LANDING_BLOCKS_ACTIONS_SAVE_BLOCK_BUTTON_MSGVER_1"),className:!this.isSaveBlockInLibraryAllowed()?"landing-ui-disabled":"",onclick:function(){this.saveBlock();this.blockActionsMenu.close()}.bind(this)})]})}h(this.node,"landing-ui-hover");this.blockActionsMenu.show()},moveUp:function(e){var n=T(this.node,"block-wrapper");var s=this.node;if(n){var a=Promise.all([X(s,-C(n).height),X(n,C(s).height)]);a.then(function(){void t(s,{transform:null,transition:null});void t(n,{transform:null,transition:null});i(s,n);if(!e||typeof e==="object"){BX.Landing.Backend.getInstance().action("Landing::upBlock",{block:this.id,lid:this.lid,siteId:this.siteId},{code:this.manifest.code}).then((()=>{BX.Landing.History.getInstance().push()}))}}.bind(this))}},moveDown:function(e){var i=_(this.node,"block-wrapper");var s=this.node;if(!!i){var a=Promise.all([X(s,C(i).height),X(i,-C(s).height)]);a.then(function(){void t(s,{transform:null,transition:null});void t(i,{transform:null,transition:null});n(s,i);if(!e||typeof e==="object"){BX.Landing.Backend.getInstance().action("Landing::downBlock",{block:this.id,lid:this.lid,siteId:this.siteId},{code:this.manifest.code}).then((()=>{BX.Landing.History.getInstance().push()}))}}.bind(this))}},addPanel:function(e,t){if(!this.panels.contains(e)){this.panels.add(e);if(!t){if(e.id==="content_edit"&&window.parent){let t=BX.Landing.PageObject.getRootWindow();s(e.layout,t.document.body)}else{s(e.layout,this.node)}}else{i(e.layout,t)}}},getBlockFormId:function(){var e=this.node.querySelector("script[data-b24-form]");if(BX.Type.isDomNode(e)){var t=BX.Dom.attr(e,"data-b24-form");if(BX.Type.isStringFilled(t)){var n=t.split("/");if(BX.Type.isArray(n)&&n.length===3){var i="";var s=BX.Dom.attr(e.previousSibling.firstChild,"id");if(s){i=s.replace("b24-","")}return{id:n[1],type:n[0],code:n[2],instanceId:i}}}}e=this.node.querySelector("[data-b24form]");if(BX.Type.isDomNode(e)){t=BX.Dom.attr(e,"data-b24form");if(BX.Type.isStringFilled(t)){n=t.split("|");if(BX.Type.isArray(n)&&n.length===3){i="";s=BX.Dom.attr(e.querySelector(".b24-form > div[id]"),"id");if(s){i=s.replace("b24-","")}return{id:n[0],type:n[2]||"inline",code:n[1],instanceId:i}}}}return null},getCrmFormOptions:function(){var e=this.node.querySelector("[data-b24form-use-style]");var t=BX.Dom.attr(e,"data-b24form-use-style");var n=/--primary([\da-fA-F]{2})/;if(BX.Type.isDomNode(e)&&BX.Text.toBoolean(t)){var i=BX.Dom.attr(e,"data-b24form-design");if(BX.Type.isPlainObject(i)){var s=BX.Dom.style(document.documentElement,"--primary").trim();Object.entries(i.color).forEach((function(e){if(e[1]==="--primary"||e[1].match(n)!==null){i.color[e[0]]=e[1].replace("--primary",s)}}));return{data:{design:i}}}}return{}},isCrmFormPage:function(){return BX.Landing.Env.getInstance().getOptions().specialType==="crm_forms"},isCrmFormBlock:function(){return this.isCrmFormPage()&&BX.Dom.attr(this.node,"data-subtype")==="form"},isDefaultCrmFormBlock:function(){return BX.Dom.hasClass(this.node,"block-66-90-form-new-default")},onShowContentPanel:function(){var e=this.getBlockFormId();var t=BX.Text.capitalize(BX.Landing.Env.getInstance().getOptions().params.type);if(BX.Type.isPlainObject(e)&&t!=="SMN"){var n=BX.Landing.PageObject.getRootWindow();void function(){if(BX.Landing.UI.Panel.FormSettingsPanel){return Promise.resolve([n.BX.Landing.UI.Panel,BX.Landing.UI.Panel])}return Promise.all([n.BX.Runtime.loadExtension("landing.ui.panel.formsettingspanel"),BX.Runtime.loadExtension("landing.ui.panel.formsettingspanel")])}().then(function(t){var n=t[1].FormSettingsPanel;if(n){return n.getInstance().show({formId:e.id,instanceId:e.instanceId,formOptions:this.getCrmFormOptions(),block:this})}}.bind(this))}else{this.showContentPanel()}BX.Landing.UI.Panel.EditorPanel.getInstance().hide()},onStateChange:function(){if(this.isEnabled()){this.disable()}else{this.enable()}},isEnabled:function(){return this.active},enable:function(){this.active=true;u(this.node,"landing-block-disabled");let e=this.blockActionsMenu||this.sidebarActionsMenu;if(e){I(e.getMenuItem("show_hide").getLayout().text,BX.Landing.Loc.getMessage("ACTION_BUTTON_HIDE"))}v("BX.Landing.Block:changeState",[this.id,true]);BX.Landing.Backend.getInstance().action("Landing::showBlock",{block:this.id,lid:this.lid,siteId:this.siteId},{code:this.manifest.code})},disable:function(){this.active=false;h(this.node,"landing-block-disabled");let e=this.blockActionsMenu||this.sidebarActionsMenu;if(e){I(e.getMenuItem("show_hide").getLayout().text,BX.Landing.Loc.getMessage("ACTION_BUTTON_SHOW"))}v("BX.Landing.Block:changeState",[this.id,false]);BX.Landing.Backend.getInstance().action("Landing::hideBlock",{block:this.id,lid:this.lid,siteId:this.siteId},{code:this.manifest.code})},createCardLabel:function(e,t){var n=[];if(c(t.label)){n.push(t.label)}else if(d(t.label)){n=n.concat(t.label)}var i=this.nodes.filter((function(t){return e.contains(t.node)}));var s=[];n.forEach((function(e){var t=i.find((function(t){return t.manifest.code===e}));if(t){var n;if(t instanceof BX.Landing.Block.Node.Text){n=m("span",{props:{className:"landing-card-title-text"},html:G(m("div",{html:t.getValue()}).innerText)});s.push(n);b(t.getField(),"change",(function(e){n.innerHTML=G(m("div",{html:e}).innerText)}));return}if(t instanceof BX.Landing.Block.Node.Link){n=m("span",{props:{className:"landing-card-title-link"},html:G(t.getValue().text)});s.push(n);b(t.getField(),"change",(function(e){n.innerHTML=G(e.text)}));return}if(t instanceof BX.Landing.Block.Node.Icon){n=m("span",{props:{className:"landing-card-title-icon"},children:[m("span",{props:{className:t.getValue().classList.join(" ")}})]});s.push(n);b(t.getField(),"change",(function(e){n.firstChild.className="landing-card-title-icon "+e.classList.join(" ")}));return}if(t instanceof BX.Landing.Block.Node.Img){n=m("span",{props:{className:"landing-card-title-img"},attrs:{style:"background-color: #fafafa"},children:[m("img",{props:{src:t.getValue().src}})]});s.push(n);b(t.getField(),"change",(function(e){n.innerHTML="";n.appendChild(m("img",{props:{src:e.src}}))}))}}}),this);return m("div",{props:{className:"landing-card-title"},children:!l(s)?s:t.name})},initCards:function(){if(this.access<fe){return}this.cards.clear();this.forEachCard((function(e,t,n){var i=BX.clone(this.manifest.cards[t]);var s=A(t,"@",n);if(this.isDynamicCards(t)){i.allowInlineEdit=false}S(e);var a=new BX.Landing.Block.Card(e,i,s);this.cards.add(a);if(i.allowInlineEdit!==false){var o=new Q("cardAction","landing-ui-panel-block-card-action");o.show();a.addPanel(o);o.addButton(new ne("clone",{html:"&nbsp;",onClick:function(e){e.stopPropagation();if(a.manifest.sync){var t=a.manifest.sync;if(c(a.manifest.sync)){t=[a.manifest.sync]}if(d(t)){t.forEach((function(e){this.cloneCard(A(e,"@",n))}),this)}}this.cloneCard(s)}.bind(this),attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_CARD_ACTION_CLONE")}}));o.addButton(new ne("remove",{html:"&nbsp;",onClick:function(e){e.stopPropagation();if(a.manifest.sync){var t=a.manifest.sync;if(c(a.manifest.sync)){t=[a.manifest.sync]}if(d(t)){t.forEach((function(e){this.removeCard(A(e,"@",n))}),this)}}this.removeCard(s)}.bind(this),attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_CARD_ACTION_REMOVE")}}))}a.selector=s;a.sortIndex=n;this.adjustCardRemoveButton(s)}));this.cards.sort((function(e,t){return e.getIndex()>t.getIndex()}))},cloneCard:function(e,t){var i=this.cards.getBySelector(e);var s=i.panels.get("cardAction").buttons.get("clone");var a={block:this.id,selector:e,lid:this.lid,siteId:this.siteId};var r={code:this.manifest.code};var c=this;Le(s);let d=Promise.resolve();if(o(t)&&!t||!o(t)){a.preventHistory=0;d=BX.Landing.Backend.getInstance().action("Landing\\Block::cloneCard",a,r).then((e=>{BX.Landing.History.getInstance().push();return e}))}return d.then((function(){v("BX.Landing.Block:Card:beforeAdd",[c.createEvent({card:i.node})])})).then((function(){var e=BX.clone(i.node);S(e);n(e,i.node);return e})).then((function(e){ye(s);v("BX.Landing.Block:Card:add",[c.createEvent({card:e})]);c.initEntities();c.initStyles()})).catch((function(){ye(s);return Promise.reject()}))},removeCard:function(e,t){var n=this.cards.getBySelector(e);var i=n.panels.get("cardAction").buttons.get("remove");var s={block:this.id,selector:e,lid:this.lid,siteId:this.siteId};var a={code:this.manifest.code};var r=this;Le(i);let c=Promise.resolve();if(o(t)&&!t||!o(t)){s.preventHistory=0;c=BX.Landing.Backend.getInstance().action("Landing\\Block::removeCard",s,a).then((e=>{BX.Landing.History.getInstance().push();return e}))}return c.then((function(){v("BX.Landing.Block:Card:beforeRemove",[r.createEvent({card:n.node})]);S(n.node)})).then((function(){r.cards.remove(n);n.node.remove();r.initEntities();r.adjustCardRemoveButton(e)})).then((function(){var t=r.createEvent({data:{selector:e}});v("BX.Landing.Block:Card:remove",[t]);ye(i)})).catch((function(){ye(i);return Promise.reject()}))},adjustCardRemoveButton:function(e){var t=this.cards.getBySelector(e);if(t){var n=t.panels.get("cardAction");if(n){var i=BX.hasClass(t.node,"landing-block-card-carousel-element");var s=t.node.closest(".landing-block-node-carousel-container");if(!i||!s){var a=t.node.parentElement.children.length===1;if(a){n.buttons.get("remove").disable()}else{n.buttons.get("remove").enable()}}else{var o=s.querySelectorAll(".landing-block-card-carousel-element").length;if(o>1){n.buttons.get("remove").enable()}else{n.buttons.get("remove").disable()}}}}},addCard:function(e,t){var i=e.selector.split("@")[0]+(e.index>0?"@"+(e.index-1):"");var s={block:this.id,content:e.content,selector:i,lid:this.lid,siteId:this.siteId};var a={code:this.manifest.code};var r=e.container;var c=m("div",{html:e.content}).firstElementChild;var d=this;let l=Promise.resolve();if(o(t)&&!t||!o(t)){s.preventHistory=0;l=BX.Landing.Backend.getInstance().action("Landing\\Block::addCard",s,a).then((e=>{BX.Landing.History.getInstance().push();return e}))}return l.then((function(){v("BX.Landing.Block:Card:beforeAdd",[d.createEvent({card:c})])})).then((function(){var t;if(e.index<=0){t=d.cards.find((function(e){return e.selector.includes(i.split("@")[0])}));if(t){x(c,t.node.parentNode)}}else{t=d.cards.getBySelector(i.split("@")[0]+"@"+(e.index-1));if(t){n(c,t.node)}}S(r);d.initEntities();v("BX.Landing.Block:Card:add",[d.createEvent({card:c})])}))},forEachCard:function(e){var t=Object.keys(this.manifest.cards);t.map((function(t){var n=E(this.node.querySelectorAll(t));n.forEach((function(n,i){e.apply(this,[n,t,i])}),this)}),this)},initNodes:function(){if(this.access<fe){return}var e=[];this.forEachNodeElements((function(t,n,i){var s=this.nodes.getByNode(t);var o=A(n,"@",i);if(!s){var r=k(this.manifest.nodes[n].handler);var c=t.closest("[data-card-preset]");var l=D(this.manifest.nodes[n]);var h=false;l.sections=this.sections;if(c){var u=c.dataset.cardPreset;Object.keys(this.manifest.cards).forEach((function(e){if(c.matches(e)){if(a(this.manifest.cards[e].presets)&&a(this.manifest.cards[e].presets[u])&&d(this.manifest.cards[e].presets[u].disallow)){var t=this.manifest.cards[e].presets[u].disallow.find((function(e){return n===e}));if(t){l.allowInlineEdit=false;h=true}}}}),this)}var g=this.cards.some((function(e){var n=e.selector.split("@")[0];return this.isDynamicCards(n)&&e.node.contains(t)}),this);if(g){l.allowInlineEdit=false}else{var f=this.cards.some((function(e){return e.node.contains(t)}));if(!f){if(this.isDynamic()){l.allowInlineEdit=false}}}s=new r({node:t,manifest:l,selector:o,onChange:this.onNodeChange.bind(this),onChangeOptions:this.onNodeOptionsChange.bind(this),onAttributeChange:this.onAttributeChange.bind(this),onDesignShow:this.showStylePanel.bind(this),uploadParams:{action:"Block::uploadFile",block:this.id}});if(h){s.getField().layout.hidden=true}this.nodes.add(s)}s.selector=o;e.push(s)}));this.nodes.clear();e.forEach((function(e){this.nodes.add(e)}),this);this.nodes.sort((function(e,t){return e.getIndex()>t.getIndex()}))},onNodeOptionsChange:function(e){if(!l(e)){this.initStyles();var t={code:this.manifest.code};var n={};n.data=e;n.block=this.id;n.siteId=this.siteId;return BX.Landing.Backend.getInstance().action("Block::changeNodeName",n,t)}},forEachNodeElements:function(e){Object.keys(this.manifest.nodes).forEach((function(t){try{E(this.node.querySelectorAll(t)).forEach((function(n,i){if(!n.matches('[data-id="content_edit"] *')){e.apply(this,[n,t,i])}}),this)}catch(e){}}),this)},showContentPanel:function(e){var t=!!e&&e.nodes?e.nodes:null;var n=!!e&&e.name?e.name:null;var i=!!e&&e.nodesOnly?e.nodesOnly:false;var o=!!e&&e.showAll?e.showAll:false;var r=!!e&&e.compact;var c=!!e&&e.hideCheckbox;var d=this.panels.get("content_edit");if(!d){d=new Z("content_edit",{title:BX.Landing.Loc.getMessage("LANDING_CONTENT_PANEL_TITLE"),subTitle:this.manifest.block.name,onSaveHandler:this.onContentSave.bind(this),onCancelHandler:this.onContentCancel.bind(this)});var l=this.getBlockFormId();var h=BX.Text.capitalize(BX.Landing.Env.getInstance().getOptions().params.type);if(BX.Type.isPlainObject(l)&&h!=="SMN"){var u=new BX.UI.Button({text:BX.Landing.Loc.getMessage("LANDING_SHOW_FORM_EDITOR"),color:BX.UI.Button.Color.LIGHT_BORDER,round:true,className:"landing-ui-panel-top-button",onclick:function(){d.hide().then(function(){this.onShowContentPanel()}.bind(this))}.bind(this)});BX.Dom.style(u.render(),{position:"absolute",right:"50px"});BX.Dom.append(u.render(),d.header)}this.addPanel(d)}d.compact(r);d.clear();var g=this.getBlockFromRepository(this.manifest.code);if(g&&g.restricted){s(this.getRestrictedMessage(),d.content)}this.tmpContent=m("div",{props:{hidden:true}});this.content.appendChild(this.tmpContent);var f="";Object.keys(this.manifest.cards).forEach((function(e){var t=this.manifest.cards[e];if(a(t.presets)){Object.keys(t.presets).forEach((function(e){var n=t.presets[e];f+=n.html}),this)}}),this);this.tmpContent.innerHTML=f;this.initEntities();this.initCardsLabels();var p=this.getEditForms({nodes:t,formName:n,nodesOnly:i,showAll:o,hideCheckbox:c});p.forEach((function(e){d.appendForm(e)}));this.tmpContent.innerHTML="";d.show();setTimeout(function(){this.lastBlockState=this.fetchRequestData(d,true)}.bind(this),300)},createHistoryEntry:function(e){Promise.all([this.lastBlockState,e]).then(function(e){var t=e[0];var n=e[1];BX.Landing.History.getInstance().push(new BX.Landing.History.Entry({block:this.id,selector:"#block"+this.id,command:"updateBlockState",undo:t,redo:n}))}.bind(this));return Promise.resolve(D(e))},updateContent:function(e,t){let n=Promise.resolve();if(o(t)&&!t||!o(t)){n=BX.Landing.Backend.getInstance().action("Block::updateContent",{lid:this.lid,block:this.id,content:e.replaceAll(' style="',' bxstyle="'),preventHistory:0},{code:this.manifest.code})}const i=this.reload();return Promise.all([n,i])},updateBlockState:function(e,t){if(BX.type.isPlainObject(e)&&BX.type.isPlainObject(e.dynamicParams)){this.dynamicParams=D(e.dynamicParams)}else{this.dynamicParams={}}Promise.resolve(e).then(function(e){return t?e:this.createHistoryEntry(e)}.bind(this)).then(this.applyMenuChanges.bind(this)).then(this.applyContentChanges.bind(this)).then(this.applyCardsChanges.bind(this)).then(this.applyAttributeChanges.bind(this)).then(this.applySettingsChanges.bind(this)).then((e=>this.saveChanges.bind(this)(e,t))).then(this.reload.bind(this)).catch(console.warn);var n=this.panels.get("content_edit");if(n){var i=new W;n.forms.forEach((function(e){if(e.type!=="attrs"){i.add(e);if(e.childForms&&e.childForms.length>0){e.childForms.forEach((function(e){i.add(e)}))}}}));i.fetchFields().forEach((function(e){if(e.tag){var t=this.nodes.getBySelector(e.selector);if(t){t.onChangeTag(e.tag)}}}),this)}},getRestrictedMessage:function(){return m("div",{props:{className:"ui-alert ui-alert-warning"},html:BX.Landing.Loc.getMessage("LANDING_BLOCK_RESTRICTED_TEXT"),attrs:{style:"margin-bottom: 20px"}})},onStyleShow:function(){BX.Landing.UI.Panel.EditorPanel.getInstance().hide();if(this.isCrmFormPage()&&this.isCrmFormBlock()){var e=Object.entries(this.manifest.style.nodes).reduce((function(e,t){if(t[1].type==="crm-form"){return t[0]}return e}),null);if(e){this.showStylePanel(e)}else{this.showStylePanel(this.selector)}}else{this.showStylePanel(this.selector)}},getPostfix:function(){return""},expandTypeGroups:function(e){var t=[];if(!BX.type.isArray(e)){e=[e]}e.forEach((function(e){if(ve(e)){be(e).forEach((function(e){t.push(e)}))}else{t.push(e)}}));return t},createStyleForm:function(e,t,n){var i=this.forms.get(e);if(i){this.forms.remove(i)}var s=!!t.props?t.props:!!t.type?t.type:null;var a=!!t.title?t.title:!!t.name?t.name:"";if(!!s&&!!a){var o=new ie({frame:window,postfix:this.getPostfix()});i=new ae({id:e,title:a,selector:e,iframe:window});s=this.expandTypeGroups(s).reduce((function(e,t){if(!e.includes(t)){e.push(t)}return e}),[]);s.forEach((function(t){var s=pe(t);if(s===null){return}var a=this.styles.get(e);var r=o.createField({block:this,styleNode:a,selector:!n?this.makeRelativeSelector(e):e,property:s.property,multiple:s.multiple===true,style:t,pseudoElement:s["pseudo-element"],pseudoClass:s["pseudo-class"],attrKey:s.attrKey,type:s.type,subtype:s.subtype,title:s.name,items:s.items,help:s.help,onChange:c.bind(this),onReset:d.bind(this)});function c(t,n,o,r){if(t instanceof BX.Event.BaseEvent){return}var c=!!s.exclude?pe(s.exclude):null;if(c){i.fields.forEach((function(e){if(e.style===s.exclude){e.reset()}}))}const d=this.createEvent({data:{selector:e,value:t,items:n,postfix:o,affect:r,exclude:c}});v(window,"BX.Landing.Block:beforeApplyStyleChanges",[d]);a.setValue(t,n,o,r,c);const l={node:a.getNode(),data:a.getValue()};v("BX.Landing.Block:updateStyleWithoutDebounce",[this.createEvent(l)]);this.onStyleInputWithDebounce(l,false)}function d(t,i,s){BX.Landing.Backend.getInstance().action("Landing\\Block::getContentFromRepository",{code:this.manifest.code}).then(function(o){var r=document.createElement("div");r.id="fake";r.innerHTML=o;r.style.display="none";window.document.body.append(r);var d=null;var h=null;if(n){h="#fake > :first-child";d=r.firstElementChild}else{h="#fake "+e;var u=a.getElementIndex(a.getTargetElement());d=r.querySelectorAll(h)[u]}var g=new BX.Landing.UI.Style({iframe:window,selector:h,relativeSelector:h,node:d});l(g);var f=g.getValue();var m=[];var p=a.getValue();t.forEach((function(e){if(f.classList.indexOf(e.value)!==-1){m.push(e.value)}var t=p.classList.indexOf(e.value);if(t!==-1){delete p.classList[t]}}));f.classList=p.classList.concat(m);f.className=f.classList;c.bind(this)(f,t,i,s);r.remove()}.bind(this)).catch((function(e){console.error("Error on reset",e)}))}function l(e){e.setInlineProperty(r.getInlineProperties());e.setComputedProperty(r.getComputedProperties());e.setPseudoElement(r.getPseudoElement());var t=true;var n=e.getValue(true);if(r.getInlineProperties().length>0||r.getComputedProperties().length>0){r.setValue(n.style,t)}else{n.classList.forEach((e=>{if(s.items.some((t=>t.value===e))){if(!!r.buttons&&r.multiple===true){return}r.setValue(e,t)}}))}}l(a);i.addField(r)}),this);this.forms.add(i)}i.fields.forEach((function(e){if(e.popup){e.popup.close()}}));return i},initStyles:function(){if(this.access<ge){return}this.styles.clear();var e=new BX.Landing.UI.Style({id:this.selector,iframe:window,selector:this.selector,relativeSelector:this.selector,onClick:this.onStyleClick.bind(this,this.selector)});this.styles.add(e);if(a(this.manifest.style)&&a(this.manifest.style.nodes)){Object.keys(this.manifest.style.nodes).forEach((function(e){var t=new BX.Landing.UI.Style({id:e,iframe:window,selector:e,relativeSelector:this.makeRelativeSelector(e),onClick:this.onStyleClick.bind(this,e)});this.styles.add(t)}),this)}},onStyleClick:function(e){this.showStylePanel(e);var t=this.forms.get(e);if(t){BX.Landing.PageObject.getInstance().design().then((function(e){BX.Landing.UI.Panel.Content.scrollTo(e.content,null)}))}},makeRelativeSelector:function(e){return A(this.selector," ",e)},makeAbsoluteSelector:function(e){e=e||this.selector;e=U(e);var t=e===this.selector?" > :first-child":this.selector;return U(e.replace(t,"").replace("!",""))},saveStyles:function(e){const t=this.styles.fetchChanges();if(t.length){t.forEach((function(e){if(e.selector===this.selector){e.selector=e.selector.replace(" > :first-child","")}if(!e.isSelectGroup()&&e.selector!==this.makeAbsoluteSelector(this.selector)){e.selector=A(e.selector.split("@")[0],"@",e.getElementIndex(e.getNode()[0]))}if(e.isSelectGroup()){e.selector=e.selector.split("@")[0]}}),this);if(o(e)&&!e||!o(e)){const e=t.fetchValues();BX.Landing.Backend.getInstance().action("Landing\\Block::updateStyles",{block:this.id,data:e,lid:this.lid,siteId:this.siteId,preventHistory:0},{code:this.manifest.code}).then((()=>{BX.Landing.History.getInstance().push()}))}}},showStylePanel:function(e){var t=BX.Reflection.getClass("BX.Landing.UI.Panel.FormSettingsPanel");var n=t&&t.getInstance().isShown()||BX.Landing.Main.getInstance().isControlsExternal();var i=this.isBlockSelector(e);var s=this.getStyleOptions(e);this.isMultiselection=this.content.querySelectorAll(e).length>1;BX.Landing.PageObject.getInstance().design().then(function(e){e.clearContent();if(s.type==="crm-form"){var t=BX.Landing.PageObject.getRootWindow();return Promise.all([t.BX.Runtime.loadExtension("landing.formstyleadapter"),BX.Runtime.loadExtension("landing.formstyleadapter")]).then(function(t){var i=t[1].FormStyleAdapter;var s=new i({formId:this.getBlockFormId().id,instanceId:this.getBlockFormId().instanceId,currentBlock:this});return Promise.all([e.show(n),s.load()])}.bind(this)).catch((function(e){console.log(e)}))}return e.show(n).then((function(e){return[e]}))}.bind(this)).then(function(t){var n=t[0];var o=t[1];n.prepareFooter(this.isMultiselection);if(o){n.appendForm(o.getStyleForm());return}if(d(s.type)||c(s.type)){if(s.type.length){n.appendForm(this.createStyleForm(e,s,i))}}if(a(s.additional)){e=s.selector?s.selector:e;n.appendForm(this.createAdditionalForm({form:ae,selector:e,group:s.additional,attrsType:s.additional.attrsType,onChange:this.onAttributeChange.bind(this)}));return}if(d(s.additional)){s.additional.forEach((function(t){n.appendForm(this.createAdditionalForm({form:ae,selector:e,group:t,onChange:this.onAttributeChange.bind(this)}))}),this)}}.bind(this)).catch(function(e){if(BX.Type.isArrayFilled(e)){var t=510;var n=e.some((function(e){return String(e.code)===String(t)}));if(n){BX.Dom.append(this.getAccessMessage(),BX.Landing.UI.Panel.StylePanel.getInstance().content)}}}.bind(this))},getAccessMessage:function(){if(!this.accessMessage){this.accessMessage=BX.create({tag:"div",props:{className:"landing-ui-access-error-message"},children:[BX.create({tag:"div",props:{className:"landing-ui-access-error-message-text"},text:BX.Landing.Loc.getMessage("LANDING_CRM_ACCESS_ERROR_MESSAGE")})]})}return this.accessMessage},getStyleOptions:function(e){if(this.isBlockSelector(e)){return this.prepareBlockOptions(this.manifest.style.block)}return this.manifest.style.nodes[e]},createAdditionalForm:function(e){var t=new e.form({title:e.group.name,type:"attrs"});var n=[];if(!BX.Type.isUndefined(e.group.attrs)){n=e.group.attrs}else{e.attrsType.forEach((e=>{let t=Be(e);if(t){n.push(t)}}))}n.forEach((function(n){var i=n.selector||e.selector;var s;if(d(n.tabs)){var a=new le({tabs:n.tabs.map((function(t){return{id:j(),name:t.name,active:t.active,fields:t.attrs.map((function(t){return this.createAttributeField(t,t.selector||e.selector,e.onChange)}),this)}}),this)});t.addCard(a);return}s=this.createAttributeField(n,i,e.onChange);t.addField(s)}),this);BX.Event.EventEmitter.subscribe("BX.Landing.UI.Form.StyleForm:attributeChange",(e=>{var n=e.data;this.prepareAttributeValue(n,t)}));return t},prepareAttributeValue:function(e,t){var n=e.data.dependency;if(n){n.forEach((n=>{var i=e.getValue();var s=n["conditions"].indexOf(i);if(s>=0){t.fields.forEach((e=>{if(e.attribute===n["attribute"]){if(n["action"]==="changeValue"){var t=e.getValue();var i=n["attributeCurrentValues"].indexOf(t);if(i>=0){e.setValue(n["attributeNewValue"],true);this.onAttributeChange(e)}}}}))}}))}},prepareBlockOptions:function(e){e=a(e)?e:{};e=D(e);e.name=BX.Landing.Loc.getMessage("BLOCK_STYLE_OPTIONS");if(!a(e.type)&&!c(e.type)&&!d(e.type)){e.type=["display","background","padding-top","padding-bottom","padding-left","padding-right","margin-top"]}return e},createAttributeField:function(e,t,n){var i=this.createFieldFactory(t,n);var s=this.getElementBySelector(t);if(!s&&t.includes("@")){var a=t.split("@");var o=this.getElementsBySelector(a[0]);if(o.length&&o[parseInt(a[1])]){s=o[parseInt(a[1])]}}var r=D(e);if(r.value===null||r.value===undefined){r.value=""}if(s){var c=w(s,r.attribute);if(BX.Type.isNil(c)){c=N(s,r.attribute)}if(c!==null){r.value=c}}return i.create(r)},onAttributeChange:function(e){BX.Event.EventEmitter.emit("BX.Landing.UI.Form.StyleForm:attributeChange",e);clearTimeout(this.attributeChangeTimeout);if(!this.requestData){this.requestData={}}this.appendAttrFieldValue(this.requestData,e);Promise.resolve(this.requestData).then(this.applyAttributeChanges.bind(this)).then(this.saveChanges.bind(this)).then(this.reload.bind(this)).then(function(){this.requestData=null}.bind(this))},appendSettingsFieldValue:function(e,t){e["settings"]=e["settings"]||{};e["settings"][t.attribute]=t.getValue();return e},appendAttrFieldValue:function(e,t){var n=this.makeAbsoluteSelector(t.selector);var i=t.getValue();e[n]=e[n]||{};e[n]["attrs"]=e[n]["attrs"]||{};if(BX.Type.isArray(t.attribute)){t.attribute.forEach((function(s){var a=s.replace("data-","");var o=i[a];if(o!==undefined){try{o=M(o)}catch(e){o=t.getValue()[a]}e[n]["attrs"][s]=o}}))}else{try{i=M(i)}catch(e){i=t.getValue()}e[n]["attrs"][t.attribute]=i}return e},appendMenuValue:function(e,t){e[t.code]=t.serialize();return e},getElementBySelector:function(e){if(this.isBlockSelector(e)){return this.content}var t;try{t=this.node.querySelector(e)}catch(e){t=null}return t},getElementsBySelector:function(e){if(this.isBlockSelector(e)){return[this.content]}var t;try{t=E(this.node.querySelectorAll(e))}catch(e){t=[]}return t},isBlockSelector:function(e){return!e||e===this.selector||"#block"+this.id===e},createFieldFactory:function(e,t){return new BX.Landing.UI.Factory.FieldFactory({selector:!this.isBlockSelector(e)?this.makeRelativeSelector(e):e,uploadParams:{action:"Block::uploadFile",block:this.id,lid:BX.Landing.Main.getInstance().id,id:BX.Landing.Main.getInstance().options.site_id},linkOptions:{siteId:BX.Landing.Main.getInstance().options.site_id,landingId:BX.Landing.Main.getInstance().id,filter:{"=TYPE":BX.Landing.Main.getInstance().options.params.type}},onValueChange:t||function(){}})},deleteBlock:function(e){var n=this.panels.get("block_action").buttons.get("remove");n.loader=n.loader||new BX.Loader({target:n.layout,size:28});n.loader.show();h(n.text,"landing-ui-hide-icon");void t(n.loader.layout.querySelector(".main-ui-loader-svg-circle"),{"stroke-width":"4px"});void t(n.loader.layout.querySelector(".main-ui-loader-svg"),{"margin-top":"-10px"});BX.Landing.UI.Panel.EditorPanel.getInstance().hide();if(this.blockActionsMenu){BX.Main.MenuManager.destroy(this.blockActionsMenu.id)}if(this.sidebarActionsMenu){BX.Main.MenuManager.destroy(this.sidebarActionsMenu.id)}if(String(window.localStorage.getItem("landingBlockId"))===String(this.id)){window.localStorage.removeItem("landingBlockId")}let i=Promise.resolve();if(o(e)&&!e||!o(e)){i=BX.Landing.Backend.getInstance().action("Landing::markDeletedBlock",{block:this.id,lid:this.lid,siteId:this.siteId,preventHistory:0},{code:this.manifest.code}).then((e=>{BX.Landing.History.getInstance().push();return e}))}i.then((()=>{n.loader.hide();u(n.text,"landing-ui-hide-icon");var e=this.createEvent();v("BX.Landing.Block:remove",[e]);E(this.node.querySelectorAll(".landing-ui-panel")).forEach(F);BX.Landing.PageObject.getBlocks().remove(this);F(this.node);v("Landing.Block:onAfterDelete",[this]);v("BX.Landing.Block:afterRemove",[e])}),(()=>{n.loader.hide();u(n.text,"landing-ui-hide-icon")}))},getFormEditorAddBlockTour:function(){var e=BX.Landing.PageObject.getRootWindow();return new e.BX.UI.Tour.Guide({steps:[{target:'[data-id="save_settings"]',title:BX.Landing.Loc.getMessage("LANDING_FORM_EDITOR_ADD_BLOCK_TOUR_STEP_1_TITLE"),text:BX.Landing.Loc.getMessage("LANDING_FORM_EDITOR_ADD_BLOCK_TOUR_STEP_1_TEXT")}]})},addBlockAfterThis:function(){var e=BX.Landing.UI&&BX.Landing.UI.Panel&&BX.Landing.UI.Panel.FormSettingsPanel?BX.Landing.UI.Panel.FormSettingsPanel.getInstance():null;if(this.isCrmFormPage()&&e&&e.isShown()){if(!e.isChanged()){e.hide().then(function(){BX.Landing.Main.getInstance().showBlocksPanel(this,null,null,true)}.bind(this))}else{this.getFormEditorAddBlockTour().start()}}else{BX.Landing.Main.getInstance().showBlocksPanel(this)}},addBlockBeforeThis:function(){var e=BX.Landing.UI.Panel.FormSettingsPanel.getInstance();if(this.isCrmFormPage()&&e.isShown()){if(!e.isChanged()){e.hide().then(function(){BX.Landing.Main.getInstance().showBlocksPanel(this,null,null,true)}.bind(this))}else{this.getFormEditorAddBlockTour().start()}}else{BX.Landing.Main.getInstance().showBlocksPanel(this,null,null,true)}},getFormEditorDesignTour:function(){var e=BX.Landing.PageObject.getRootWindow();return new e.BX.UI.Tour.Guide({steps:[{target:'[data-id="save_settings"]',title:BX.Landing.Loc.getMessage("LANDING_FORM_EDITOR_FORM_DESIGN_TOUR_STEP_1_TITLE"),text:BX.Landing.Loc.getMessage("LANDING_FORM_EDITOR_FORM_DESIGN_TOUR_STEP_1_TEXT")}]})},onFormDesignClick:function(){var e=Object.entries(this.manifest.style.nodes).reduce((function(e,t){if(t[1].type==="crm-form"){return t[0]}return e}),null);if(e){this.showStylePanel(e)}else{this.showStylePanel(this.selector)}},onNodeChange:function(e,t){const n=this.createEvent({node:e.node});v("BX.Landing.Block:Node:update",[n]);if(!e.isSavePrevented()){clearTimeout(this.changeTimeout);this.changedNodes.add(e);this.changeTimeout=setTimeout((()=>{if(o(t)&&!t||!o(t)){BX.Landing.Backend.getInstance().action("Landing\\Block::updateNodes",{block:this.id,data:this.changedNodes.fetchValues(),additional:this.changedNodes.fetchAdditionalValues(),lid:this.lid,siteId:this.siteId,preventHistory:0},{code:this.manifest.code})}this.changedNodes.clear()}),300)}},containsPseudoSelector:function(e){return Object.keys(e).some((function(e){var t;if(e==="cards"){return false}if(e==="dynamicState"){return false}if(BX.type.isPlainObject(this.manifest.menu)&&e in this.manifest.menu){return false}try{if(e!=="#block"+this.id&&e!==""){t=!this.node.querySelector(e)}else{t=false}}catch(n){t=!ke(e)}return t}),this)},containsReloadRequireAttributes:function(e){if(a(e)&&a(this.manifest)&&a(this.manifest.attrs)){return Object.keys(this.manifest.attrs).some((function(t){return this.manifest.attrs[t].some((function(n){if(n.requireReload&&a(e[t])&&a(e[t].attrs)&&e[t].attrs[n.attribute]){return true}return false}),this)}),this)}return false},applyContentChanges:function(e){if(!a(e)){return Promise.reject(new TypeError("BX.Landing.Block.applyContentChanges: data isn't object"))}var t=D(e);Object.keys(t).forEach((function(e){if(!ke(e)){delete t[e]}}));if(!l(t)){var n=this.createEvent({data:t});v(window,"BX.Landing.Block:beforeApplyContentChanges",[n])}var i=[];Object.keys(e).forEach((function(t){if(ke(t)){var n=this.nodes.getBySelector(t);if(n){var s=n.setValue(e[t],true,true);n.preventSave(false);if(s){i.push(s);s.then((function(){e[t]=n.getValue()}))}else{e[t]=n.getValue()}}}}),this);return Promise.all(i).then((function(){return e}))},applyMenuChanges:function(e){if(!a(e)){return Promise.reject(new TypeError("BX.Landing.Block.applyContentChanges: data isn't object"))}var t=Object.keys(this.manifest.menu||{});if(t.length>0){t.forEach(function(t){if(t in e){var n=this.menu.find((function(e){return e.code===t}));n.rebuild(e[t])}}.bind(this));e.forceReload=true}this.initMenu();return Promise.resolve(e)},applyCardsChanges:function(e){if(!a(e)){return Promise.reject(new TypeError("BX.Landing.Block.applyCardsChanges: data isn't object"))}var t=[];if("cards"in e&&a(e.cards)){v("BX.Landing.Block:Cards:beforeUpdate",[this.createEvent()]);var n={};Object.keys(e.cards).forEach((function(i){var o=this.node.querySelector(i).parentElement;var r=this.node.querySelectorAll(i);var d=e.cards[i].values;var h=e.cards[i].presets;var u=e.cards[i].indexes;var g=e.cards[i].source;o.innerHTML="";Object.keys(d).forEach((function(e){g[e]={value:0,type:"card"};if(!l(h)&&!l(h[e])){if(!r[u[e]]||!BX.type.isString(u[e])){g[e].type="preset";g[e].value=h[e];return}}if(r[u[e]]){g[e].type="card";g[e].value=u[e]}}),this);Object.keys(d).forEach((function(e){if(g[e].type==="preset"){var t=this.manifest.cards[i]["presets"][g[e].value]["html"];s(R(t),o);return}s(D(r[g[e].value]),o)}),this);this.initNodes();this.initCards();this.initGroups();Object.keys(d).forEach((function(e){var i=d[e];Object.keys(i).forEach((function(e){n[e]=e in n?n[e]+1:0;var s=this.nodes.getBySelector(A(e,"@",n[e]));if(s){var o=i[e];var r=s.getValue();if(a(o)&&c(o.url)){o.url=O(o.url)}if(a(r)&&c(r.url)){r.url=O(r.url)}try{o=JSON.stringify(o)}catch(t){o=i[e]}try{r=JSON.stringify(r)}catch(e){r=s.getValue()}var d=s.setValue(i[e],true,true)||Promise.resolve();s.preventSave(false);d.then(function(t,n,a){i[A(t,"@",n)]=s.getValue();if(s.manifest.type==="img"||s.manifest.type==="icon"){i[A(t,"@",n)]["url"]=M(a["url"])}delete i[e]}.bind(this,e,n[e],i[e]));t.push(d)}}),this)}),this);Promise.all(t).then(function(){this.initCardsLabels();this.initStyles();delete e.cards[i].presets;delete e.cards[i].indexes}.bind(this))}),this);Promise.all(t).then(function(){v("BX.Landing.Block:Cards:update",[this.createEvent()])}.bind(this))}return Promise.all(t).then((function(){return Promise.resolve(e)}))},applySettingsChanges:function(e){if(!a(e)){return Promise.reject(new TypeError("BX.Landing.Block.applyAttributeChanges: requestData isn't object"))}if(a(e.settings)&&!l(e.settings)){if(e.settings.id){this.content.id=e.settings.id}}return Promise.resolve(e)},applyAttributeChanges:function(e){if(!a(e)){return Promise.reject(new TypeError("BX.Landing.Block.applyAttributeChanges: requestData isn't object"))}var t=D(e);Object.keys(e).forEach((function(n){if(!(a(e[n])&&"attrs"in e[n])){delete t[n]}}));if(!l(t)){var n=this.createEvent({data:t});v(window,"BX.Landing.Block:beforeApplyAttributesChanges",[n])}var i=this;Object.keys(e).forEach((function(t){if(a(e[t])&&"attrs"in e[t]){var n=i.getElementsBySelector(t);if(!n.length&&t.includes("@")){var s=t.split("@");n=i.getElementsBySelector(s[0]);if(n[parseInt(s[1])]){n=[n[parseInt(s[1])]]}}Object.keys(e[t].attrs).forEach((function(s){n.forEach((function(n){var a=O(e[t]["attrs"][s]);if(!s.includes("data-")){N(n,s,a)}else{w(n,s,a)}v("BX.Landing.Block:Node:updateAttr",[i.createEvent({node:n,data:e[t]["attrs"]})])}))}))}}));return Promise.resolve(e)},saveChanges:function(e,t){if(!a(e)){return Promise.reject(new TypeError("BX.Landing.Block.saveChanges: data isn't object"))}if(Object.keys(e).length){var n={code:this.manifest.code};var i={block:this.id,data:e,lid:this.lid,siteId:this.siteId};var s={};if(a(e.settings)&&!l(e.settings)){if(e.settings.id){s.changeAnchor={action:"Block::changeAnchor",data:{block:this.id,lid:this.lid,data:e.settings.id}}}delete e.settings}if(!l(e)){var r=new H;Object.keys(i).forEach((function(e){r.add(this.nodes.getBySelector(e))}),this);s.updateNodes={action:"Block::updateNodes",data:i,additional:r.fetchAdditionalValues()}}if(!l(e.cards)){var c=D(e.cards);delete e.cards;var d=BX.Landing.Utils.arrayUnique(Object.keys(c));d=d.length===1?d+" *":d.join(" *, ");var h=this.nodes.matches(d).fetchAdditionalValues();s.updateCards={action:"Block::updateCards",data:{block:this.id,lid:this.lid,siteId:this.siteId,data:c,additional:h}}}if(e.cardsFirst){var u=s;s={};if(u.changeAnchor){s.changeAnchor=u.changeAnchor}if(u.updateCards){s.updateCards=u.updateCards}if(u.updateNodes){s.updateNodes=u.updateNodes}delete e.cardsFirst}if(o(t)&&!t||!o(t)){return BX.Landing.Backend.getInstance().batch("Landing\\Block::updateNodes",s,n).then((function(){return Promise.resolve(e)}))}}return Promise.resolve(e)},fetchRequestData:function(e,t){var n={};var i={};var s=function(e,t){return t?e:e.fetchChanges()};i.attrs=new W;i.cards=new W;i.dynamicCards=new W;i.dynamicBlock=new W;i.content=new W;i.settings=new W;i.menu=new W;e.forms.forEach((function(e){i[e.type].push(e)}));s(i.content.fetchFields(),t).reduce(V(this.appendContentFieldValue,this),n);var a=new q;i.cards.forEach((function(e){e.childForms.forEach((function(e){e.fields.forEach((function(e){if(e.type==="attr"){a.add(e)}}))}))}));s(a,true).reduce(V(this.appendAttrFieldValue,this),n);i.cards.reduce(V(this.appendCardsFormValue,this),n);i.dynamicCards.reduce(V(this.appendDynamicCardsFormValue,this),n);i.dynamicBlock.reduce(V(this.appendDynamicBlockFormValue,this),n);s(i.attrs.fetchFields(),t).reduce(V(this.appendAttrFieldValue,this),n);s(i.settings.fetchFields(),t).reduce(V(this.appendSettingsFieldValue,this),n);i.menu.reduce(V(this.appendMenuValue,this),n);n.dynamicState=Object.keys(this.manifest.cards).reduce((function(e,t){e[t]=BX.type.isPlainObject(n.dynamicParams)&&t in n.dynamicParams;return e}),{});n.dynamicState.wrapper=!!n.dynamicParams&&"wrapper"in n.dynamicParams;return Promise.resolve(n)},appendContentFieldValue:function(e,t){return e[t.selector]=t.getValue(),e},appendCardsFormValue:function(e,t){e.cards=e.cards||{};e.cards[t.code]={};e.cards[t.code]["values"]=t.serialize();e.cards[t.code]["presets"]=t.getUsedPresets();e.cards[t.code]["indexes"]=t.getIndexesMap();e.cards[t.code]["source"]={};return e},appendDynamicCardsFormValue:function(e,t){e.dynamicParams=e.dynamicParams||{};e.dynamicParams[t.code]={};e.dynamicParams[t.code]=t.serialize();return e},appendDynamicBlockFormValue:function(e,t){e.dynamicParams=e.dynamicParams||{};e.dynamicParams.wrapper=t.serialize();return e},reload:function(e){if(a(e)){var t=this.containsPseudoSelector(e)||this.containsReloadRequireAttributes(e);if(!t){return Promise.resolve(e)}}var n=new BX.Loader({target:this.parent.parentElement,color:"rgba(255, 255, 255, .8)"});n.layout.style.position="fixed";n.layout.style.zIndex="999";n.show();BX.Landing.Main.getInstance().showOverlay();var i=this;return BX.Landing.Backend.getInstance().action("Block::getContent",{block:this.id,lid:this.lid,siteId:this.siteId,editMode:1}).then(function(e){var t=this.createEvent();v("BX.Landing.Block:remove",[t]);BX.Landing.Main.getInstance().currentBlock=i;BX.Landing.Main.getInstance().currentArea=i.parent;return BX.Landing.Main.getInstance().addBlock(e,true)}.bind(this)).then((function(t){i.node=t;return Promise.resolve(e)})).then((function(e){return new Promise((function(t){setTimeout((function(){t(e);n.hide();BX.Landing.Main.getInstance().hideOverlay()}),800)}))}))},onContentSave:function(){var e=this.panels.get("content_edit");if(e){e.hide();this.fetchRequestData(e).then(function(e){v("BX.Landing.Block:onContentSave",[this.id]);return Object.assign({},e,{cardsFirst:true})}.bind(this)).then(this.updateBlockState.bind(this))}},onContentCancel:function(){this.panels.get("content_edit").hide();this.tmpContent.innerHTML="";this.anchor=this.savedAnchor},getCardsSelector:function(){var e=Object.keys(this.manifest.cards);var t=A(e.join(","),", ");var n=A(e.join(" *,")," *");return A(t,n)},onStyleInput:function(e,t){this.saveStyles(t);const n=this.createEvent(e);v("BX.Landing.Block:updateStyle",[n])},getBlockEditForm:function(e){var t={};if(BX.type.isPlainObject(e)){t=Object.assign({},e)}var n=t.nodes||this.nodes;if(this.cards.length>0&&!e.hideCheckbox){n=this.nodes.notMatches(this.getCardsSelector())}var i=Object.keys(this.manifest.nodes);n=i.reduce((function(e,t){if(!t.includes(":")){n.matches(t).getVisible().filter((function(e){return e.manifest.allowFormEdit!==false})).forEach((function(t){e.push(t)}))}return e}),new H);var s=this.onBlockFormTypeChange.bind(this);var a=!!(!e.skipBlockState&&BX.type.isPlainObject(this.dynamicParams)&&this.dynamicParams.wrapper);var o="";var r=BX.Landing.Main.getInstance().options.helps;if(BX.type.isPlainObject(r)){o=r.DYNAMIC_BLOCKS}var c={text:BX.Landing.Loc.getMessage("LANDING_BLOCK__MAKE_A_DYNAMIC"),onChange:s,state:a,help:o};var d=new se({title:e.formName||BX.Landing.Loc.getMessage("BLOCK_ELEMENTS"),description:this.manifest.block.formDescription,type:"content",code:this.id,headerCheckbox:function(){if(!e.hideCheckbox&&this.manifest.block.dynamic!==false){return c}return undefined}.bind(this)()});if(a){setTimeout((function(){s({form:d,state:true})}))}n.forEach((function(e){d.addField(e.getField())}));return d},getMenuEditForms:function(){return this.menu.map((function(e){return e.getForm()}),this)},getAttrsEditForm:function(){var e=Object.keys(this.manifest.attrs);var t=[];e.forEach((function(e){var n=this.manifest.attrs[e];if(!n.hidden){n=!d(n)?[n]:n;n.forEach((function(n){if(!n.hidden&&c(n.type)){t.push(this.createAttributeField(n,n.selector||e))}}),this)}}),this);var n=new se({id:"attr",type:"attrs",title:BX.Landing.Loc.getMessage("BLOCK_SETTINGS"),description:this.manifest.block.attrsFormDescription});t.forEach((function(e){n.addField(e)}));return n},getAttrsAdditionalEditForms:function(){var e=Object.keys(this.manifest.attrs);var t=[];e.forEach((function(e){var n=this.manifest.attrs[e];if(!n.hidden){n=!d(n)?[n]:n;n.forEach((function(n){if(!n.hidden&&c(n.type)){return}if(c(n.name)&&n.attrs){t.push(this.createAdditionalForm({form:se,selector:e,group:n,onChange:function(){}}))}}),this)}}),this);return t},getCardsEditForms:function(e){var t=Object.keys(this.manifest.cards);var n=Object.keys(this.manifest.nodes);var i=[];var s=t.reduce(function(e,t){var n=this.cards.filter((function(e){return e.selector.split("@")[0]===t}));if(n.length>0){n.sort((function(e,t){return e.sortIndex-t.sortIndex}));e.set(t,n)}return e}.bind(this),new Map);s.forEach((function(t,s){var o=BX.type.isPlainObject(this.dynamicParams)&&s in this.dynamicParams&&!e;var r=this.onCardsFormTypeChange.bind(this);var c=this.manifest.cards[s]["group_label"];var l="";var h=BX.Landing.Main.getInstance().options.helps;if(BX.type.isPlainObject(h)){l=h.DYNAMIC_BLOCKS}var u={text:BX.Landing.Loc.getMessage("LANDING_CARDS__MAKE_A_DYNAMIC"),onChange:r,state:o,help:l};var g=new re({title:c||BX.Landing.Loc.getMessage("LANDING_CARDS_FROM_TITLE"),code:s.split("@")[0],presets:t[0].manifest.presets,sync:t[0].manifest.sync,description:t[0].manifest.formDescription,forms:i,headerCheckbox:function(){if(this.manifest.block.dynamic!==false){return u}return undefined}.bind(this)()});i.push(g);if(o){setTimeout((function(){r({form:g,state:true})}))}t.forEach((function(e){var t=new oe({label:e.getLabel()||e.getName(),labelBindings:e.manifest.label,selector:e.selector,preset:e.preset});var i=new H;var o=this.nodes.filter((function(t){return e.node.contains(t.node)}));if(o.length){n.forEach((function(e){var t=o.matches(e);t.forEach(i.add,i)}),this);i.forEach((function(e){if(e.manifest.allowFormEdit!==false){t.addField(e.getField())}}));var r=this.manifest.cards[s].additional;if(a(r)){if(d(r.attrs)){r.attrs.forEach((function(n){var i=this.createAttributeField(n,e.selector,(function(){}));i.type="attr";t.addField(i)}),this)}}if(this.tmpContent.contains(e.node)){g.addPresetForm(t)}else{g.addChildForm(t)}}}),this)}),this);return i},getBlockSettingsForm:function(){var e=new se({title:BX.Landing.Loc.getMessage("BLOCK_SETTINGS"),type:"settings"});var t=this.createFieldFactory("!"+this.selector);var n=null;var i=BX.Landing.Main.getInstance().options.url;if(i[0]==="/"){i=top.location.origin+i}this.savedAnchor=this.anchor||this.node.id;var a=A(i,"#",this.anchor||this.node.id);var o=t.create({type:"text",name:BX.Landing.Loc.getMessage("BLOCK_SETTINGS_ANCHOR_FIELD"),description:"<span class='landing-ui-anchor-preview'>"+BX.Text.encode(a)+"</span>",attribute:"id",value:this.anchor||this.node.id,onInput:function(){var e=o.layout.querySelector(".landing-ui-anchor-preview");if(e){e.innerHTML=BX.Text.encode(A(i,"#",BX.Text.decode(o.getValue())))}this.anchor=o.getValue();if(n){F(n)}if(this.node.id!==o.getValue()&&document.getElementById(o.getValue())){n=BX.Landing.UI.Field.BaseField.createDescription(BX.Landing.Loc.getMessage("BLOCK_SETTINGS_ANCHOR_FIELD_VALIDATE_ERROR"));h(n,"landing-ui-error");s(n,o.layout)}if(!K(o.getValue())){n=BX.Landing.UI.Field.BaseField.createDescription(BX.Landing.Loc.getMessage("BLOCK_SETTINGS_ANCHOR_FIELD_VALIDATE_INVALID_ID"));h(n,"landing-ui-error");s(n,o.layout)}}.bind(this)});e.addField(o);return e},getEditForms:function(e){var t={};if(BX.type.isPlainObject(e)){t=Object.assign({},e)}if(arguments.length>1){t.nodes=arguments[0];t.formName=arguments[1];t.nodesOnly=arguments[2];t.showAll=arguments[3];t.skipCardsState=arguments[4];t.skipBlockState=arguments[5]}var n=new W;if(this.access>=fe){var i=!(l(this.manifest.nodes)&&l(this.manifest.attrs)&&l(this.manifest.menu));if(i){var s=this.getBlockEditForm(t);if(s.fields.length>0){n.add(s)}var a=this.getMenuEditForms(t);if(a.length>0){a.forEach((function(e){n.add(e)}))}if(!t.nodesOnly){var o=this.getAttrsEditForm();if(o.fields.length>0){n.add(o)}var r=this.getAttrsAdditionalEditForms();if(r.length>0){r.forEach((function(e){n.add(e)}))}var c=this.getCardsEditForms(t.skipCardsState);if(c.length>0){c.forEach((function(e){n.add(e)}))}}}var d=this.getBlockSettingsForm();if(d.fields.length>0){n.push(d)}}return n},isLastBlockInArea:function(){return this.parent.querySelectorAll(".block-wrapper").length<2},onBlockRemove:function(){this.adjustSortButtonsState()},adjustSortButtonsState:function(){var e=this.panels.get("block_action");if(e){if(this.isLastBlockInArea()){e.buttons.get("up").disable();e.buttons.get("down").disable()}else{e.buttons.get("up").enable();e.buttons.get("down").enable()}}},getFieldType:function(e){var t=this.nodes.getBySelector(e.selector);if(t){return t.type}return null},getTypeReferences:function(e,t){return e.filter((function(e){return e.type===t}))},convertReferencesToDropdownItems:function(e){var t=e.map((function(e){return{name:e.name,value:e.id}}));t.push({name:BX.Landing.Loc.getMessage("LANDING_BLOCK__DYNAMIC_REFERENCE_HIDE"),html:'<span class="landing-ui-field-dropdown-sep"></span>'+BX.Landing.Loc.getMessage("LANDING_BLOCK__DYNAMIC_REFERENCE_HIDE"),value:"@hide"});return t},getDefaultDropdownItems:function(){return[{name:BX.Landing.Loc.getMessage("LANDING_CARDS__DYNAMIC_FIELD_NOT_SET"),value:""}]},getDynamicFiledValue:function(e,t){var n=this.dynamicParams||{};if(BX.type.isPlainObject(n[e])&&BX.type.isPlainObject(n[e].references)){return n[e].references[t]}},convertToDynamicFields:function(e,t,n){return e.map((function(e){var i=this.getFieldType(e);if(i!=="text"&&i!=="img"&&i!=="link"&&i!=="link_ref"){return e}var s=this.getTypeReferences(n,i);var a=this.convertReferencesToDropdownItems(s);var o=this.getDynamicFiledValue(t,e.selector);if(i==="link"){if(BX.type.isPlainObject(s[0])&&BX.type.isArray(s[0].actions)){return new BX.Landing.UI.Field.ClickAction({title:e.title,selector:e.selector,reference:s[0],linkField:e,value:o})}return e}if(a.length===0){a=this.getDefaultDropdownItems()}if(i==="img"){return new BX.Landing.UI.Field.DynamicImage({title:e.title,selector:e.selector,dropdownItems:a,value:BX.type.isString(o)?{id:o}:o,hideCheckbox:t==="wrapper"})}return new BX.Landing.UI.Field.DynamicDropdown({title:e.title,selector:e.selector,dropdownItems:a,value:BX.type.isString(o)?{id:o}:o,hideCheckbox:t==="wrapper"||i==="link_ref"})}),this)},createDynamicCardsForm:function(e){var t="";var n=BX.Landing.Main.getInstance().options.helps;if(BX.type.isPlainObject(n)){t=n.DYNAMIC_BLOCKS}var i=new BX.Landing.UI.Form.DynamicCardsForm({title:e.title,code:e.code,type:"dynamicCards",dynamicParams:e.dynamicParams,headerCheckbox:{text:BX.Landing.Loc.getMessage("LANDING_CARDS__MAKE_A_DYNAMIC"),onChange:this.onCardsFormTypeChange.bind(this),state:true,help:t},onSourceChange:function(t){var n=this.convertToDynamicFields(e.form.childForms[0].fields,e.code,t.references);var s=new he({id:"references",items:n});var a=i.detailPageGroup.fields[0];if(!BX.Type.isStringFilled(a.getValue().href)){var o={text:"",href:""};if(t&&t.default&&t.default.detail){o.href=t.default.detail}a.setValue(o);a.hrefInput.makeDisplayedHrefValue()}var r=i.cards.get("references");i.replaceCard(r,s)}.bind(this)});return i},onCardsFormTypeChange:function(e){var t=this.panels.get("content_edit");var n=!!e.state;if(n){var i={};if(BX.type.isPlainObject(this.dynamicParams)&&this.dynamicParams[e.form.code]){i=this.dynamicParams[e.form.code]}var s=Object.assign({},i);if(BX.type.isPlainObject(s.settings)){if(!("pagesCount"in s.settings)){s.settings.pagesCount=e.form.childForms.length}}else{s.settings={pagesCount:e.form.childForms.length}}var a=this.createDynamicCardsForm({title:e.form.title,code:e.form.code,form:e.form,dynamicParams:s});t.replaceForm(e.form,a);return}delete this.dynamicParams[e.form.code];var o=this.getCardsEditForms(true).find((function(t){return t.code===e.form.code}));t.replaceForm(e.form,o)},isDynamicCards:function(e){return e in this.dynamicParams},onBlockFormTypeChange:function(e){var t=this.panels.get("content_edit");var n=!!e.state;let i=this.content.parentElement.querySelector(".landing-html-lock");if(i){if(!n){this.content.style.display="flex";i.style.display="none"}else{this.content.style.display="none";i.style.display="flex"}}if(n){var s=this.createDynamicBlockForm({title:e.form.title,code:e.form.code,form:e.form,dynamicParams:this.dynamicParams});t.replaceForm(e.form,s);return}delete this.dynamicParams.wrapper;var a=this.getBlockEditForm({skipBlockState:true});t.replaceForm(e.form,a)},createDynamicBlockForm:function(e){var t="";var n=BX.Landing.Main.getInstance().options.helps;if(BX.type.isPlainObject(n)){t=n.DYNAMIC_BLOCKS}var i=new BX.Landing.UI.Form.DynamicBlockForm({title:e.title,code:this.id,type:"dynamicBlock",dynamicParams:e.dynamicParams,headerCheckbox:{text:BX.Landing.Loc.getMessage("LANDING_BLOCK__MAKE_A_DYNAMIC"),onChange:this.onBlockFormTypeChange.bind(this),state:true,help:t},onSourceChange:function(t){var n=i.cards.get("references");if(BX.type.isPlainObject(t)){var s=this.convertToDynamicFields(e.form.fields,"wrapper",t.references);var a=new he({id:"references",items:s});i.replaceCard(n,a);return}i.removeCard(n)}.bind(this)});return i},isDynamic:function(e){e=e||this.id;var t=this.panels.get("content_edit");if(t){var n=t.forms.toArray().find((function(t){return t.code===e}));if(n){return n.isCheckboxChecked()}}e=e===this.id?"wrapper":e;return!!this.dynamicParams&&e in this.dynamicParams}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:45:"/bitrix/js/landing/card.min.js?17081150491589";s:6:"source";s:26:"/bitrix/js/landing/card.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
(function(){"use strict";BX.namespace("BX.Landing");var n=BX.Landing.Utils.clone;var e=BX.Landing.Utils.isPlainObject;var t=BX.Landing.Utils.isEmpty;var i=BX.Landing.Utils.data;var s=BX.Landing.Utils.deepFreeze;BX.Landing.Block.Card=function(a,r,l,d){this.node=a;this.manifest=r||{};this.selector=l;this.panels=new BX.Landing.UI.Collection.PanelCollection;this.form=null;this.node.classList.add("landing-card");this.label=d;this.preset=null;this.sortIndex=-1;if(e(this.manifest.presets)&&!t(this.manifest.presets)){var o=i(this.node,"data-card-preset");if(o){this.preset=n(this.manifest.presets[o]);this.preset.id=o;s(this.preset)}}if(!BX.type.isDomNode(this.node)){throw new Error("BX.Landing.Block.Card: 'node' is not a DOMNode.")}if(!BX.type.isPlainObject(this.manifest)){throw new Error("BX.Landing.Block.Card: 'manifest' is not an Object.")}};BX.Landing.Block.Card.init=function(n,e,t){return new BX.Landing.Block.Card(n,e,t)};BX.Landing.Block.Card.prototype={getIndex:function(){var n=parseInt(this.selector.split("@")[1]);n=BX.type.isNumber(n)?n:0;return n},getName:function(){var n=(this.manifest.name||"")+" "+(this.getIndex()+1);if(this.manifest.label){var e=this.node.querySelector('[data-selector*="'+this.manifest.label+'"]');if(e&&e.innerHTML){n=e.innerHTML}}return n},getLabel:function(){return this.label},addPanel:function(n){if(!!n&&n instanceof BX.Landing.UI.Panel.BasePanel&&!this.panels.contains(n)){this.panels.add(n);this.node.appendChild(n.layout)}},clone:function(){return new BX.Landing.Block.Card(n(this.node),n(this.manifest),this.selector,n(this.label))}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:45:"/bitrix/js/landing/node.min.js?17081150492544";s:6:"source";s:26:"/bitrix/js/landing/node.js";s:3:"min";s:30:"/bitrix/js/landing/node.min.js";s:3:"map";s:30:"/bitrix/js/landing/node.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.Block");var n=BX.Landing.Utils.isFunction;var e=BX.Landing.Utils.isString;var t=BX.Landing.Utils.isPlainObject;var i=BX.Landing.Utils.isArray;var o=BX.Landing.Utils.bind;var s=BX.Landing.Utils.proxy;var r=BX.Landing.Utils.data;BX.Landing.Block.Node=function(i){this.node=i.node;this.manifest=t(i.manifest)?i.manifest:{};this.selector=e(i.selector)?i.selector:"";this.onChangeHandler=n(i.onChange)?i.onChange:function(){};this.onDesignShow=n(i.onDesignShow)?i.onDesignShow:function(){};this.changeOptionsHandler=n(i.onChangeOptions)?i.onChangeOptions:function(){};this.onDocumentClick=s(this.onDocumentClick,this);this.onDocumentKeydown=s(this.onDocumentKeydown,this);o(document,"click",this.onDocumentClick);o(document,"keydown",this.onDocumentKeydown);Object.freeze(this.manifest);this.node.dataset.selector=this.selector;if(this.isAllowInlineEdit()){this.onAllowInlineEdit()}};BX.Landing.Block.Node.storage=[];BX.Landing.Block.Node.prototype={onDocumentClick:function(n){},onDocumentKeydown:function(n){if(n.keyCode===27){this.onEscapePress()}},onEscapePress:function(){},getField:function(){throw new Error("Must be implemented by subclass")},showEditor:function(){},hideEditor:function(){},onAllowInlineEdit:function(){},isAllowInlineEdit:function(){return this.manifest.allowInlineEdit!==false},isGrouped:function(){return typeof this.manifest.group==="string"&&this.manifest.group.length>0},setValue:function(n,e,t){throw new Error("Must be implemented by subclass")},getValue:function(){throw new Error("Must be implemented by subclass")},getAdditionalValue:function(){if(t(this.manifest.extend)&&i(this.manifest.extend.attrs)){return this.manifest.extend.attrs.reduce(function(n,e){return n[e]=r(this.node,e),n}.bind(this),{})}return{}},onChange:function(n){this.onChangeHandler.apply(null,[this,n])},getIndex:function(){var n=parseInt(this.selector.split("@")[1]);n=n===n?n:0;return n},preventSave:function(n){this.isSavePreventedValue=n},isSavePrevented:function(){return!!this.isSavePreventedValue},getBlock:function(){return BX.Landing.PageObject.getBlocks().getByChildNode(this.node)},preparePseudoUrl:function(n){let e=false;if(!(n.href==="#"&&n.target==="")){e=true}if(n.href==="selectActions:"){n.href="";n.enabled=false;e=true}if(n.href.startsWith("product:")){n.target="_self";e=true}if(n.enabled!==false){if(n.href===""||n.href==="#"){n.enabled=false;e=true}}if(n.target===""){n.target="_blank";e=true}if(e===true){return n}return null}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:51:"/bitrix/js/landing/node/text.min.js?170811504917809";s:6:"source";s:31:"/bitrix/js/landing/node/text.js";s:3:"min";s:35:"/bitrix/js/landing/node/text.min.js";s:3:"map";s:35:"/bitrix/js/landing/node/text.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing");var e=BX.Landing.Utils.escapeText;var t=BX.Landing.Utils.Matchers.headerTag;var n=BX.Landing.Utils.changeTagName;var i=BX.Landing.Utils.textToPlaceholders;BX.Landing.Block.Node.Text=function(e){BX.Runtime.loadExtension("landing.node.text.tableeditor");BX.Landing.Block.Node.apply(this,arguments);this.type="text";this.tableBaseFontSize="22";this.onClick=this.onClick.bind(this);this.onPaste=this.onPaste.bind(this);this.onDrop=this.onDrop.bind(this);this.onInput=this.onInput.bind(this);this.onKeyDown=this.onKeyDown.bind(this);this.onMousedown=this.onMousedown.bind(this);this.onMouseup=this.onMouseup.bind(this);this.node.addEventListener("mousedown",this.onMousedown);this.node.addEventListener("click",this.onClick);this.node.addEventListener("paste",this.onPaste);this.node.addEventListener("drop",this.onDrop);this.node.addEventListener("input",this.onInput);this.node.addEventListener("keydown",this.onKeyDown);document.addEventListener("mouseup",this.onMouseup)};BX.Landing.Block.Node.Text.currentNode=null;BX.Landing.Block.Node.Text.prototype={__proto__:BX.Landing.Block.Node.prototype,superClass:BX.Landing.Block.Node.prototype,constructor:BX.Landing.Block.Node.Text,onAllowInlineEdit:function(){this.node.setAttribute("title",e(BX.Landing.Loc.getMessage("LANDING_TITLE_OF_TEXT_NODE")))},onChange:function(e,t){this.superClass.onChange.call(this,t);if(!e){BX.Landing.UI.Panel.EditorPanel.getInstance().adjustPosition(this.node)}if(!t){BX.Landing.History.getInstance().push()}},onKeyDown:function(e){if(e.code==="Backspace"){this.onBackspaceDown(e)}this.onInput(e)},onInput:function(e){clearTimeout(this.inputTimeout);var t=e.keyCode||e.which;if(!(t===90&&(top.window.navigator.userAgent.match(/win/i)?e.ctrlKey:e.metaKey))){this.inputTimeout=setTimeout(function(){if(this.lastValue!==this.getValue()){this.onChange(true);this.lastValue=this.getValue()}}.bind(this),400)}if(this.isTable(e)){var n=parseInt(window.getComputedStyle(e.srcElement).getPropertyValue("font-size"));if(e.srcElement.textContent===""&&e.srcElement.classList.contains("landing-table-td")&&n<this.tableBaseFontSize){e.srcElement.classList.add("landing-table-td-height")}else{e.srcElement.classList.remove("landing-table-td-height")}}},onEscapePress:function(){if(this.isEditable()){if(this===BX.Landing.Block.Node.Text.currentNode){BX.Landing.UI.Panel.EditorPanel.getInstance().hide()}this.disableEdit()}},onDrop:function(e){e.preventDefault()},onPaste:function(e){e.preventDefault();if(e.clipboardData&&e.clipboardData.getData){var t=e.clipboardData.getData("text/plain");var n=BX.Text.encode(t);if(this.isLinkPasted(t)){n=this.prepareToLink(n)}var i=n.replace(new RegExp("\n","g"),"<br>");document.execCommand("insertHTML",false,i)}else{var a=window.clipboardData.getData("text");document.execCommand("paste",true,BX.Text.encode(a))}this.onChange()},onDocumentClick:function(e){if(this.isEditable()&&!this.fromNode){BX.Landing.UI.Panel.EditorPanel.getInstance().hide();this.disableEdit()}this.fromNode=false},onMousedown:function(e){if(!this.manifest.group){this.fromNode=true;if(this.manifest.allowInlineEdit!==false&&BX.Landing.Main.getInstance().isControlsEnabled()){e.stopPropagation();this.enableEdit();if(this.isTable(e)){this.disableEdit();BX.Landing.Block.Node.Text.currentNode.node.querySelectorAll(".landing-table-container").forEach((function(e){if(!e.hasAttribute("table-prepare")){BX.Landing.Block.Node.Text.prototype.prepareNewTable(e)}}));var t=parseInt(window.getComputedStyle(e.srcElement).getPropertyValue("font-size"));if(e.srcElement.textContent===""&&e.srcElement.classList.contains("landing-table-td")&&t<this.tableBaseFontSize){e.srcElement.classList.add("landing-table-td-height")}else{e.srcElement.classList.remove("landing-table-td-height")}}else{if(!this.manifest.textOnly&&!BX.Landing.UI.Panel.StylePanel.getInstance().isShown()){BX.Landing.UI.Panel.EditorPanel.getInstance().show(this.node,null,this.buttons)}if(BX.Landing.Block.Node.Text.nodeTableContainerList){BX.Landing.Block.Node.Text.nodeTableContainerList.forEach((function(e){e.tableEditor.unselect(e.tableEditor)}))}}BX.Landing.UI.Tool.ColorPicker.hideAll()}requestAnimationFrame((function(){if(e.target.nodeName==="A"||e.target.parentElement.nodeName==="A"){var t=document.createRange();t.selectNode(e.target);window.getSelection().removeAllRanges();window.getSelection().addRange(t)}}))}},onMouseup:function(){setTimeout(function(){this.fromNode=false}.bind(this),10)},onClick:function(e){if(this.isTable(e)){this.addTableButtons(e)}e.stopPropagation();e.preventDefault();this.fromNode=false;if(e.target.nodeName==="A"||e.target.parentElement.nodeName==="A"){var t=document.createRange();t.selectNode(e.target);window.getSelection().removeAllRanges();window.getSelection().addRange(t)}},isEditable:function(){return this.node.isContentEditable},enableEdit:function(){var e=BX.Landing.Block.Node.Text.currentNode;if(e){var t=BX.Landing.Block.Node.Text.currentNode.node;var n=t.querySelectorAll(".landing-table-container");if(n.length>0){n.forEach((function(e){if(!e.tableEditor){e.tableEditor=new BX.Landing.Node.Text.TableEditor.default(e)}}));BX.Landing.Block.Node.Text.nodeTableContainerList=n}}if(!this.isEditable()&&!BX.Landing.UI.Panel.StylePanel.getInstance().isShown()){if(this!==BX.Landing.Block.Node.Text.currentNode&&BX.Landing.Block.Node.Text.currentNode!==null){BX.Landing.Block.Node.Text.currentNode.disableEdit()}BX.Landing.Block.Node.Text.currentNode=this;this.buttons=[];this.buttons.push(this.getDesignButton());if(BX.Landing.Main.getInstance()["options"]["allow_ai_text"]){this.buttons.push(this.getAiTextButton())}if(this.isHeader()){this.buttons.push(this.getChangeTagButton());this.getChangeTagButton().onChangeHandler=this.onChangeTag.bind(this)}this.lastValue=this.getValue();this.node.contentEditable=true;this.node.setAttribute("title","")}},getDesignButton:function(){if(!this.designButton){this.designButton=new BX.Landing.UI.Button.Design("design",{html:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_DESIGN"),attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_DESIGN")},onClick:function(){BX.Landing.UI.Panel.EditorPanel.getInstance().hide();this.disableEdit();this.onDesignShow(this.manifest.code)}.bind(this)})}return this.designButton},getAiTextButton:function(){if(!this.aiTextButton){this.aiTextButton=new BX.Landing.UI.Button.AiText("ai_text",{html:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_AI_TEXT"),attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_AI_TEXT")},onClick:function(){BX.Landing.UI.Panel.EditorPanel.getInstance().hide();let e=BX.Landing.Main.getInstance()["options"]["blocks"];let t=this.manifest.sections;let n="";let i={};for(let a=0,s=t.length;a<s;a++){let s=t[a];if(e[s]&&e[s]["meta"]){if(e[s]["meta"]["ai_text_placeholder"]){n=e[s]["meta"]["ai_text_placeholder"]}if(e[s]["meta"]["ai_text_max_tokens"]){i["max_tokens"]=parseInt(e[s]["meta"]["ai_text_max_tokens"])}}}if(!this.aiTextPicker){let e=BX.Landing.Main.getInstance()["options"]["site_id"];let t=top.BX.AI?top.BX.AI.Picker:BX.AI.Picker;this.aiTextPicker=new t({moduleId:"landing",contextId:"text_site_"+e,analyticLabel:"landing_text",history:true,onSelect:function(e){this.node.innerHTML=e.data.replace(/(\r\n|\r|\n)/g,"<br>");this.onChange()}.bind(this),onTariffRestriction:function(){BX.UI.InfoHelper.show("limit_sites_TextAssistant_AI")}});this.aiTextPicker.setLangSpace(BX.AI.Picker.LangSpace.text)}this.aiTextPicker.setEngineParameters(i);this.aiTextPicker.text()}.bind(this)})}return this.aiTextButton},disableEdit:function(){if(this.isEditable()){this.node.contentEditable=false;if(this.lastValue!==this.getValue()){this.onChange();this.lastValue=this.getValue()}if(this.isAllowInlineEdit()){this.node.setAttribute("title",e(BX.Landing.Loc.getMessage("LANDING_TITLE_OF_TEXT_NODE")))}}},getField:function(){if(!this.field){this.field=new BX.Landing.UI.Field.Text({selector:this.selector,title:this.manifest.name,content:this.node.innerHTML,textOnly:this.manifest.textOnly,bind:this.node});if(this.isHeader()){this.field.changeTagButton=this.getChangeTagButton()}}else{this.field.setValue(this.node.innerHTML);this.field.content=this.node.innerHTML}return this.field},setValue:function(e,t,n){this.preventSave(t);this.lastValue=this.isSavePrevented()?this.getValue():this.lastValue;this.node.innerHTML=e;this.onChange(false,n)},getValue:function(){if(this.node.querySelector(".landing-table-container")!==null){const e=this.node.cloneNode(true);this.prepareTable(e);return i(e.innerHTML)}return i(this.node.innerHTML)},isHeader:function(){return t.test(this.node.nodeName)},isTable:function(e){var t=false;if(BX.Landing.Block.Node.Text.currentNode&&e){BX.Landing.Block.Node.Text.currentNode.node.querySelectorAll(".landing-table-container").forEach((function(n){if(n.contains(e.srcElement)){t=true}}))}return t},prepareNewTable:function(e){e.querySelectorAll("br").forEach((function(e){e.remove()}));e.setAttribute("table-prepare","true");BX.Landing.Block.Node.Text.currentNode.onChange(true)},addTableButtons:function(e){var t=[];var n=[];var i=[];var a=this.getTableButtons();var s=[a[0],a[1],a[2],a[3]];var o=BX.Landing.Block.Node.Text.currentNode.node;var l=null;var d=false;var r=false;var c=false;var g=true;if(e.srcElement.classList.contains("landing-table")||e.srcElement.classList.contains("landing-table-col-dnd")){g=false}if(e.srcElement.classList.contains("landing-table-row-add")){r=true}if(e.srcElement.classList.contains("landing-table-col-add")){c=true}var h=[];var u=o.querySelectorAll(".landing-table");if(u.length>0){u.forEach((function(t){if(t.contains(e.srcElement)){l=t;return true}}))}a.forEach((function(t){t["options"]["srcElement"]=e.srcElement;t["options"]["node"]=o;t["options"]["table"]=l}));if(e.srcElement.classList.contains("landing-table-row-dnd")){i=e.srcElement.parentNode.children;i=Array.from(i);if(this.getAmountTableRows(l)>1){n=[0,1,2,3,4,5,6]}else{n=[0,1,2,3,4,5]}n.forEach((function(e){a[e]["options"]["target"]="row";a[e]["options"]["setTd"]=i;t.push(a[e])}))}if(e.srcElement.parentNode.classList.contains("landing-table-col-dnd")){var f=e.srcElement.parentElement.parentElement.childNodes;var L=Array.from(f);var T=[];L.forEach((function(e){if(e.nodeType===1){T.push(e)}}));var E=T.indexOf(e.srcElement.parentElement);var p=e.srcElement.parentElement.parentElement.parentElement.childNodes;p.forEach((function(e){if(e.nodeType===1){var t=[];e.childNodes.forEach((function(e){if(e.nodeType===1){t.push(e)}}));if(t[E]){i.push(t[E])}}}));if(this.getAmountTableCols(l)>1){n=[0,1,2,3,4,5,7]}else{n=[0,1,2,3,4,5]}n.forEach((function(e){a[e]["options"]["target"]="col";a[e]["options"]["setTd"]=i;t.push(a[e])}))}if(e.srcElement.classList.contains("landing-table-th-select-all")){var B;if(e.srcElement.classList.contains("landing-table-th-select-all-selected")){B=true;const s=e.srcElement.parentElement.parentElement.childNodes;s.forEach((function(e){e.childNodes.forEach((function(e){i.push(e)}))}));n=[0,1,2,3,4,5,8,9,10];n.forEach((function(e){a[e]["options"]["target"]="table";a[e]["options"]["setTd"]=i;t.push(a[e])}))}else{B=false;BX.Landing.UI.Panel.EditorPanel.getInstance().hide()}}if(BX.Dom.hasClass(e.srcElement,"landing-table-td")||this.hasParentWithClass(e.srcElement,"landing-table-td")){i.push(e.srcElement);n=[3,2,1,0];n.forEach((function(e){a[e]["options"]["target"]="cell";a[e]["options"]["setTd"]=i;a[e].insertAfter="strikeThrough";t.push(a[e])}));d=true;h=["justifyLeft","justifyCenter","justifyRight","justifyFull","createTable","pasteTable"]}var I;let _=[];i.forEach((function(e){if(e.nodeType===1){I=undefined;if(e.classList.contains("text-left")){I="alignLeft"}if(e.classList.contains("text-center")){I="alignCenter"}if(e.classList.contains("text-right")){I="alignRight"}if(e.classList.contains("text-justify")){I="alignJustify"}_.push(I)}}));var b=0;var N=true;while(b<_.length&&N){if(b>0){if(_[b]!==_[b-1]){N=false}}b++}if(N){I=_[0]}else{I=undefined}if(I){s.forEach((function(e){if(e.id===I){e.layout.classList.add("landing-ui-active")}}))}if(t[0]&&t[1]&&t[2]&&t[3]){t[0]["options"]["alignButtons"]=s;t[1]["options"]["alignButtons"]=s;t[2]["options"]["alignButtons"]=s;t[3]["options"]["alignButtons"]=s}if(!this.manifest.textOnly){if(g){if(!r&&!c&&l){if(!d){if(B===false){BX.Landing.UI.Panel.EditorPanel.getInstance().hide()}else{BX.Landing.UI.Panel.EditorPanel.getInstance().show(l.parentNode,null,t,true)}}else{BX.Landing.UI.Panel.EditorPanel.getInstance().show(l.parentNode,null,t,true,h)}}}else{BX.Landing.UI.Panel.EditorPanel.getInstance().hide()}}},hasParentWithClass:function(e,t){let n=e.parentNode;while(n!==null){if(n.classList&&BX.Dom.hasClass(n,t)){return true}n=n.parentNode}return false},getChangeTagButton:function(){if(!this.changeTagButton){this.changeTagButton=new BX.Landing.UI.Button.ChangeTag("changeTag",{html:'<span class="landing-ui-icon-editor-'+this.node.nodeName.toLowerCase()+'"></span>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_CHANGE_TAG")},onChange:this.onChangeTag.bind(this)})}this.changeTagButton.insertAfter="unlink";this.changeTagButton.activateItem(this.node.nodeName);return this.changeTagButton},getTableButtons:function(){this.buttons=[];this.buttons.push(new BX.Landing.UI.Button.AlignTable("alignLeft",{html:'<span class="landing-ui-icon-editor-left"></span>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_ALIGN_LEFT")}}),new BX.Landing.UI.Button.AlignTable("alignCenter",{html:'<span class="landing-ui-icon-editor-center"></span>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_ALIGN_CENTER")}}),new BX.Landing.UI.Button.AlignTable("alignRight",{html:'<span class="landing-ui-icon-editor-right"></span>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_ALIGN_RIGHT")}}),new BX.Landing.UI.Button.AlignTable("alignJustify",{html:'<span class="landing-ui-icon-editor-justify"></span>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_ALIGN_JUSTIFY")}}),new BX.Landing.UI.Button.ColorAction("tableTextColor",{text:BX.Landing.Loc.getMessage("EDITOR_ACTION_SET_FORE_COLOR"),attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_COLOR")}}),new BX.Landing.UI.Button.ColorAction("tableBgColor",{html:'<i class="landing-ui-icon-editor-fill-color"></i>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_TABLE_CELL_BG")}}),new BX.Landing.UI.Button.DeleteElementTable("deleteRow",{html:'<span class="landing-ui-icon-editor-delete"></span>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_DELETE_ROW_TABLE")}}),new BX.Landing.UI.Button.DeleteElementTable("deleteCol",{html:'<span class="landing-ui-icon-editor-delete"></span>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_DELETE_COL_TABLE")}}),new BX.Landing.UI.Button.StyleTable("styleTable",{html:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_TABLE_STYLE")+'<i class="fas fa-chevron-down g-ml-8"></i>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_TABLE_STYLE")}}),new BX.Landing.UI.Button.CopyTable("copyTable",{text:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_TABLE_COPY"),attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_TABLE_COPY")}}),new BX.Landing.UI.Button.DeleteTable("deleteTable",{html:'<span class="landing-ui-icon-editor-delete"></span>',attrs:{title:BX.Landing.Loc.getMessage("LANDING_TITLE_OF_EDITOR_ACTION_TABLE_DELETE")}}));return this.buttons},onChangeTag:function(e,t){this.node=n(this.node,e);this.node.addEventListener("mousedown",this.onMousedown);this.node.addEventListener("click",this.onClick);this.node.addEventListener("paste",this.onPaste);this.node.addEventListener("drop",this.onDrop);this.node.addEventListener("input",this.onInput);this.node.addEventListener("keydown",this.onInput);if(!this.getField().isEditable()&&!t){this.disableEdit();this.enableEdit()}var i={};i[this.selector]=e;if(!t){this.changeOptionsHandler(i).then((()=>{BX.Landing.History.getInstance().push()}))}},getAmountTableCols:function(e){return e.querySelectorAll(".landing-table-col-dnd").length},getAmountTableRows:function(e){return e.querySelectorAll(".landing-table-row-dnd").length},prepareTable:function(e){var t=["table-selected-all","landing-table-th-select-all-selected","landing-table-cell-selected","landing-table-row-selected","landing-table-th-selected","landing-table-th-selected-cell","landing-table-th-selected-top","landing-table-th-selected-x","landing-table-tr-selected-left","landing-table-tr-selected-y","landing-table-col-selected","landing-table-tr-selected","table-selected-all-right","table-selected-all-bottom"];t.forEach((function(t){e.querySelectorAll("."+t).forEach((function(e){e.classList.remove(t)}))}));return e},onBackspaceDown:function(e){var t=window.getSelection();var n=t.getRangeAt(0).startOffset;if(n===0){var i=t.focusNode;if(!BX.Type.isNil(i)&&i.nodeType!==3){if(i.firstChild.nodeType===3&&i.firstChild.firstChild.nodeType===3){i=i.firstChild.firstChild}else if(i.firstChild.nodeType!==3){i=i.firstChild}else{i=null}}if(i){var a=i.parentNode;var s=["BLOCKQUOTE","UL"];if(a&&s.includes(a.nodeName)){var o=document.createElement("div");o.append(i);a.append(o)}var l=i.parentNode.parentNode;while(l&&!s.includes(l.nodeName)){l=l.parentNode}if(l&&l.childNodes.length===1){l.after(i.parentNode);l.remove();e.preventDefault()}}}},isLinkPasted:function(e){var t=/^https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_\+.~#?&\/=]*)$/;return!!e.match(t)},prepareToLink:function(e){return"<a class='g-bg-transparent' href='"+e+"' target='_blank'> "+e+" </a>"}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:50:"/bitrix/js/landing/node/link.min.js?17081150493900";s:6:"source";s:31:"/bitrix/js/landing/node/link.js";s:3:"min";s:35:"/bitrix/js/landing/node/link.min.js";s:3:"map";s:35:"/bitrix/js/landing/node/link.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing");var t=BX.Landing.Utils.trim;var e=BX.Landing.Utils.isPlainObject;var i=BX.Landing.Utils.isString;var n=BX.Landing.Utils.textToPlaceholders;var a=BX.Landing.Utils.create;var s=BX.Landing.Utils.escapeText;var d=BX.Landing.Utils.decodeDataValue;BX.Landing.Block.Node.Link=function(t){BX.Landing.Block.Node.apply(this,arguments);this.type="link";if(!this.isGrouped()){this.node.addEventListener("click",this.onClick.bind(this))}if(this.isAllowInlineEdit()){this.node.setAttribute("title",BX.Landing.Loc.getMessage("LANDING_TITLE_OF_LINK_NODE"))}this.onChange=BX.Runtime.debounce(this.onChange,500);this.onContentUpdate=BX.Runtime.debounce(this.onContentUpdate,500)};BX.Landing.Block.Node.Link.prototype={__proto__:BX.Landing.Block.Node.prototype,constructor:BX.Landing.Block.Node.Link,onContentUpdate:function(){BX.Landing.History.getInstance().push();this.getField().setValue(this.getValue())},isMenuMode:function(){return this.manifest.menuMode===true},onClick:function(t){t.preventDefault();if(!this.isMenuMode()){t.stopPropagation()}if(this.isAllowInlineEdit()){BX.Landing.UI.Button.ColorAction.hideAll();if(!BX.Landing.UI.Panel.StylePanel.getInstance().isShown()){BX.Landing.UI.Panel.Link.getInstance().show(this)}}},isPrevented:function(){return this.getValue().target==="_popup"},setValue:function(t,e,n){this.startValue=this.startValue||this.getValue();this.preventSave(e);if(!this.containsImage()&&this.isAllowInlineEdit()){var a=this.getField(true).hrefInput;if(i(t.text)&&t.text.includes("{{name}}")){a.getPlaceholderData(t.href).then(function(e){this.node.innerHTML=t.text.replace(new RegExp("{{name}}"),'<span data-placeholder="name">'+e.name+"</span>")}.bind(this))}else{if(!this.getField().containsHtml()&&!this.manifest.skipContent){this.node.innerHTML=s(t.text)}}}this.node.setAttribute("href",d(t.href));this.node.setAttribute("target",s(t.target));if("attrs"in t){for(var r in t.attrs){if(t.attrs.hasOwnProperty(r)){this.node.setAttribute(r,t.attrs[r])}}}else{this.node.removeAttribute("data-url");this.node.removeAttribute("data-embed")}this.onChange(n);if(!n){this.onContentUpdate()}},containsImage:function(){return!!this.node.firstElementChild&&this.node.firstElementChild.tagName==="IMG"},getValue:function(){var i={text:n(t(this.node.innerHTML)),href:t(this.node.getAttribute("href")),target:t(this.node.getAttribute("target")||"_self")};if(this.node.getAttribute("data-url")){i.attrs={"data-url":t(this.node.getAttribute("data-url"))}}if(this.node.getAttribute("data-dynamic")){if(!e(i.attrs)){i.attrs={}}i.attrs["data-dynamic"]=this.node.getAttribute("data-dynamic")}if(this.manifest.skipContent){i["skipContent"]=true;delete i.text}if(i.href&&i.href.startsWith("selectActions:")){i.href="#"}return i},getField:function(t){var e=this.getValue();e.text=n(a("div",{html:e.text}).innerHTML);if(!this.field){var i=[BX.Landing.UI.Field.LinkUrl.TYPE_BLOCK,BX.Landing.UI.Field.LinkUrl.TYPE_PAGE,BX.Landing.UI.Field.LinkUrl.TYPE_CRM_FORM,BX.Landing.UI.Field.LinkUrl.TYPE_CRM_PHONE];if(BX.Landing.Main.getInstance().options.params.type===BX.Landing.Main.TYPE_STORE){i.push(BX.Landing.UI.Field.LinkUrl.TYPE_CATALOG)}if(BX.Landing.Main.getInstance().options.features.includes("diskFile")){i.push(BX.Landing.UI.Field.LinkUrl.TYPE_DISK_FILE)}this.field=new BX.Landing.UI.Field.Link({title:this.manifest.name,selector:this.selector,skipContent:this.manifest.skipContent,content:e,options:{siteId:BX.Landing.Main.getInstance().options.site_id,landingId:BX.Landing.Main.getInstance().id},allowedTypes:i})}else{if(!t){this.field.setValue(e);this.field.content=e;this.field.hrefInput.content=e.href;this.field.hrefInput.makeDisplayedHrefValue();this.field.hrefInput.setHrefTypeSwitcherValue(this.field.hrefInput.getHrefStringType());this.field.hrefInput.removeHrefTypeFromHrefString()}}return this.field}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:49:"/bitrix/js/landing/node/img.min.js?17081150496006";s:6:"source";s:30:"/bitrix/js/landing/node/img.js";s:3:"min";s:34:"/bitrix/js/landing/node/img.min.js";s:3:"map";s:34:"/bitrix/js/landing/node/img.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing");var e=BX.Landing.Utils.attr;var t=BX.Landing.Utils.data;var n=BX.Landing.Utils.encodeDataValue;var i=BX.Landing.Utils.decodeDataValue;BX.Landing.Block.Node.Img=function(e){BX.Landing.Block.Node.apply(this,arguments);this.type="img";this.editPanel=null;this.lastValue=null;this.field=null;this.uploadParams=e.uploadParams;if(!this.isGrouped()){this.node.addEventListener("click",this.onClick.bind(this))}if(this.isAllowInlineEdit()){this.node.setAttribute("title",BX.Landing.Loc.getMessage("LANDING_TITLE_OF_IMAGE_NODE"))}};function a(e){return e.node.nodeName!=="IMG"}function s(e){return e.node.nodeName==="IMG"}function d(e){return e.node.nodeName==="SPAN"||e.node.nodeName==="I"||e.node.nodeName==="EM"}function o(e){var t=e.node.style.getPropertyValue("background-image");if(t){var n=t.match(/url\((.*?)\)/);if(n&&n[1]){return n[1].replace(/["|']/g,"")}}return""}function r(e){var t=e.node.style.getPropertyValue("background-image");if(t){var n=t.match(/1x, url\(["|'](.*)["|']\) 2x\)/);if(n&&n[1]){return n[1].replace(/["|']/g,"")}}return""}function l(e){var t=parseInt(e.node.dataset.fileid);return t===t?t:-1}function c(e){var t=parseInt(e.node.dataset.fileid2x);return t===t?t:-1}function u(t){var n=e(t.node,"alt");return!!n?n:""}function g(e){var n=t(e.node,"data-pseudo-url");return!!n?n:""}function h(t){var n=e(t.node,"src");return!!n?n:""}function f(t){var n=e(t.node,"srcset");return!!n?n.replace(" 2x",""):""}function m(e,t){if(!s(e)){var n=BX.create("img",{attrs:{src:t.src,alt:t.alt,"data-fileid":t.id}});e.node.parentNode.insertBefore(n,e.node);BX.remove(e.node);e.node=n}else{e.node.src=t.src;e.node.alt=t.alt||"";e.node.dataset.fileid=t.id||-1;e.node.srcset=t.src2x?t.src2x+" 2x":"";e.node.dataset.fileid2x=t.id2x||-1}}function p(e,t){if(!a(e)){var n=BX.create("div",{attrs:{style:'background-image: url("'+t.src+'")',"data-fileid":t.id}});e.node.parentNode.insertBefore(n,e.node);BX.remove(e.node);e.node=n}else{if(t.src){const n=['background-image: url("'+t.src+'");'];if(t.src2x){n.push('background-image: -webkit-image-set(url("'+t.src+'") 1x, url("'+t.src2x+'") 2x);');n.push('background-image: image-set(url("'+t.src+'") 1x, url("'+t.src2x+'") 2x);')}const i=e.node.style;const a={};Array.from(i).map((e=>{a[e]=i.getPropertyValue(e)}));e.node.setAttribute("style",n.join(" "));for(let t in a){if(t!=="background-image"){e.node.style.setProperty(t,a[t])}}}else{if(e.node.style){e.node.style.removeProperty("background-image")}}e.node.dataset.fileid=t.id||-1;e.node.dataset.fileid2x=t.id2x||-1}}BX.Landing.Block.Node.Img.prototype={__proto__:BX.Landing.Block.Node.prototype,constructor:BX.Landing.Block.Node.Img,onClick:function(e){if(this.manifest.allowInlineEdit!==false&&BX.Landing.Main.getInstance().isControlsEnabled()&&(!BX.Landing.Block.Node.Text.currentNode||!BX.Landing.Block.Node.Text.currentNode.isEditable())&&!BX.Landing.UI.Panel.StylePanel.getInstance().isShown()){e.preventDefault();e.stopPropagation();BX.Landing.UI.Button.ColorAction.hideAll();if(!this.editPanel){this.editPanel=new BX.Landing.UI.Panel.Content(this.selector,{title:BX.Landing.Loc.getMessage("LANDING_IMAGE_PANEL_TITLE"),className:"landing-ui-panel-edit-image"});this.editPanel.appendFooterButton(new BX.Landing.UI.Button.BaseButton("save_block_content",{text:BX.Landing.Loc.getMessage("BLOCK_SAVE"),onClick:this.save.bind(this),className:"landing-ui-button-content-save"}));this.editPanel.appendFooterButton(new BX.Landing.UI.Button.BaseButton("cancel_block_content",{text:BX.Landing.Loc.getMessage("BLOCK_CANCEL"),onClick:this.editPanel.hide.bind(this.editPanel),className:"landing-ui-button-content-cancel"}));window.parent.document.body.appendChild(this.editPanel.layout)}var t=new BX.Landing.UI.Form.BaseForm({title:this.manifest.name});t.addField(this.getField());this.editPanel.clear();this.editPanel.appendForm(t);this.editPanel.show();BX.Landing.UI.Panel.EditorPanel.getInstance().hide()}},save:function(){var e=this.editPanel.forms[0].fields[0].getValue();if(JSON.stringify(this.getValue())!==JSON.stringify(e)){this.setValue(e)}this.editPanel.hide()},getField:function(){if(!this.field){var e="";if(this.manifest.dimensions){var t=this.manifest.dimensions;var n=t.width||t.maxWidth||t.minWidth;var s=t.height||t.maxHeight||t.minHeight;if(n&&!s){e=BX.Landing.Loc.getMessage("LANDING_CONTENT_IMAGE_RECOMMENDED_WIDTH")+" ";e+=n+"px"}else if(s&&!n){e=BX.Landing.Loc.getMessage("LANDING_CONTENT_IMAGE_RECOMMENDED_HEIGHT")+" ";e+=s+"px"}else if(n&&s){e=BX.Landing.Loc.getMessage("LANDING_CONTENT_IMAGE_RECOMMENDED_SIZE")+" ";e+=n+"px&nbsp;/&nbsp;";e+=s+"px"}}var d=this.getValue();d.url=i(d.url);var o=!!this.node.closest("a")||!!this.manifest.disableLink;if(this.manifest["editInStyle"]!==true){this.field=new BX.Landing.UI.Field.Image({selector:this.selector,title:this.manifest.name,description:e,disableLink:o,content:d,dimensions:!!this.manifest.dimensions?this.manifest.dimensions:{},create2xByDefault:this.manifest.create2xByDefault,disableAltField:a(this),uploadParams:this.uploadParams})}}else{this.field.setValue(this.getValue());this.field.content=this.getValue();requestAnimationFrame(function(){this.field.adjustPreviewBackgroundSize()}.bind(this))}return this.field},setValue:function(t,n,i){this.lastValue=this.lastValue||this.getValue();this.preventSave(n);t.src=decodeURIComponent(t.src);if(s(this)){m(this,t)}if(a(this)){p(this,t)}if(t.url){const n=this.preparePseudoUrl(t.url);if(n!==null){e(this.node,"data-pseudo-url",n)}}this.onChange(i);if(!i){BX.Landing.History.getInstance().push()}this.lastValue=this.getValue()},getValue:function(){const e={type:"",src:"",alt:"",url:""};const t=l(this);if(t>0){e.id=t}const i=c(this);if(i>0){e.id2x=i}if(a(this)){e.type="background";e.src=o(this);const t=r(this);if(t){e.src2x=t}}if(s(this)){e.type="image";e.alt=u(this);e.src=h(this);const t=f(this);if(t){e.src2x=t}}e.url=n(g(this))||{text:"",href:"",target:"_self",enabled:false};return e}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:44:"/bitrix/js/landing/node/ul.js?17081150495944";s:6:"source";s:29:"/bitrix/js/landing/node/ul.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
(function() {

"use strict";

BX.namespace("BX.Landing");

/**
 * DOMNode of Block (Ul).
 * @param {nodeOptions} options
 */
BX.Landing.Block.Node.Ul = function(options)
{
	BX.Landing.Block.Node.apply(this, arguments);

	this.popup = null;
	this.nodeEditSubmit = null;
	this.nodeEditLi = [];
	this.content = [];

	// get all LI with BIU tags
	var ulLi = BX.findChildren(this.node, {tag: "li"});
	for (var i = 0, c = ulLi.length; i < c; i++)
	{
		var liContent = "";
		for (var j = 0, cc = ulLi[i].childNodes.length; j < cc; j++)
		{
			if (
				ulLi[i].childNodes[j].nodeType === 1 &&
				(
					ulLi[i].childNodes[j].tagName === "B" ||
					ulLi[i].childNodes[j].tagName === "I" ||
					ulLi[i].childNodes[j].tagName === "U"
				)
			)
			{
				liContent += ulLi[i].childNodes[j].outerHTML;
			}
			else if (
					ulLi[i].childNodes[j].nodeType === 3 &&
					BX.util.trim(ulLi[i].childNodes[j].textContent) !== ""
			)
			{
				liContent += " #VAL# ";
			}
		}
		this.content.push({
			content: BX.util.trim(ulLi[i].textContent),
			original: liContent
		});
	}

	BX.bind(this.node, "click", BX.delegate(this.onClick, this));
};


BX.Landing.Block.Node.Ul.prototype = {
	__proto__: BX.Landing.Block.Node.prototype,
	constructor: BX.Landing.Block.Node.Ul,

	/**
	 * Save content for Node.
	 * @returns {void}
	 */
	saveContent: function ()
	{
		var wasChanged = false;
		var isNulled = true;
		// change any li or not
		for (var i = 0, c = this.nodeEditLi.length; i < c; i++)
		{
			if (this.nodeEditLi[i] !== null)
			{
				var value = BX.util.trim(this.nodeEditLi[i].value);
				isNulled = false;
				if (
					typeof this.content[i] === "undefined" ||
					this.content[i].content !== value
				)
				{
					wasChanged = true;
					break;
				}
			}
			else
			{
				wasChanged = true;
				break;
			}
		}
		// save content
		if (!isNulled && wasChanged)
		{
			BX.cleanNode(this.node);
			this.content = [];
			for (var i = 0, c = this.nodeEditLi.length; i < c; i++)
			{
				if (this.nodeEditLi[i] !== null)
				{
					var value = BX.util.trim(this.nodeEditLi[i].value);
					var original = BX.data(this.nodeEditLi[i], "original");
					this.content.push({
						content: value,
						original: original
					});
					this.node.appendChild(BX.create("li", {
						html: original.replace("#VAL#", BX.util.htmlspecialchars(value))
					}));
				}
				else
				{
					this.content.push(false);
				}
			}
			this.markAsChanged();
		}
	},

	/**
	 * Return element for add new li item.
	 * @returns {DOMNode}
	 */
	getAddLiButton: function (i)
	{
		return BX.create("input", {
			attrs: {
				type: "button",
				value: "+"
			},
			dataset: {
				i: i
			},
			events: {
				click: BX.delegate(function ()
				{
					var button = BX.proxy_context;
					var i = parseInt(BX.data(button, "i"));
					var newLi = BX.create("input", {
						dataset: {
							original: this.content[i].original
						},
						attrs: {
							type: "text"
						}
					});
					BX.insertAfter(BX.create("div", {
						children: [
							newLi,
							this.getAddLiButton(i + 1),
							this.getRemoveLiButton(i + 1)
						]
					}), button.parentNode);
					this.nodeEditLi.splice(i + 1, 0, newLi);
					BX.focus(newLi);
				}, this)
			}
		});
	},

	/**
	 * Return element for remove li item.
	 * @returns {DOMNode}
	 */
	getRemoveLiButton: function (i)
	{
		return BX.create("input", {
			attrs: {
				type: "button",
				value: "-"
			},
			dataset: {
				i: i
			},
			events: {
				click: BX.delegate(function ()
				{
					var button = BX.proxy_context;
					this.nodeEditLi[BX.data(button, "i")] = null;
					BX.remove(button.parentNode);
				}, this)
			}
		});
	},

	/**
	 * Rerturn nodes for edit content.
	 * @param {Boolean} showbutton False if not show save button.
	 * @returns {Array of DOMNode}
	 */
	getEditNodes: function (showbutton)
	{
		var li, editLi = [];

		this.nodeEditLi = [];

		// edit li
		for (var i = 0, c = this.content.length; i < c; i++)
		{
			li = BX.create("input", {
				dataset: {
					original: this.content[i].original
				},
				attrs: {
					type: "text",
					value: BX.util.trim(this.content[i].content)
				}
			});
			this.nodeEditLi.push(li);

			editLi.push(BX.create("div", {
				children: [
					li,
					this.getAddLiButton(i),
					this.getRemoveLiButton(i)
				]
			}));
		}

		// save button
		if (showbutton !== false)
		{
			this.nodeEditSubmit = BX.create("input", {
				attrs: {
					type: "button",
					value: "Save"
				},
				events: {
					click: function ()
					{
						this.saveContent();
						this.popup.close();
					}.bind(this)
				}
			});
		}

		if (showbutton !== false)
		{
			editLi.push(this.nodeEditSubmit);
		}

		return editLi;
	},

	/**
	 * Click on field - edit mode.
	 * @param {MouseEvent} e
	 * @returns {void}
	 */
	onClick: function (e)
	{
		this.popup = BX.PopupWindowManager.create(
			"landing_node_img",
			BX.proxy_context,
			{
				closeIcon: false,
				autoHide: true,
				closeByEsc: true,
				contentColor: "white",
				angle: true,
				offsetLeft: 15,
				overlay: {
					backgroundColor: "#cdcdcd",
					opacity: ".1"
				},
				events: {
					onPopupClose: function ()
					{
						this.popup.destroy();
					}.bind(this)
				}
			}
		);

		// popup content
		this.popup.setContent(BX.create("div", {
			children: this.getEditNodes()
		}));

		this.popup.show();

		return BX.PreventDefault(e);
	},

	/*
	 * Get tags for show Node in settings form.
	 * @returns {Array}
	 */
	getSettingsForm: function ()
	{
		return [{
			name: this.getName(),
			node: BX.create("div", {
				children: this.getEditNodes(false)
			})
		}];
	},

	/*
	 * Callback on save settings form.
	 * @returns {void}
	 */
	saveSettingsForm: function ()
	{
		this.saveContent();
	},

	getValue: function ()
	{

	},

	setValue: function ()
	{

	},

	getField: function()
	{
		return new BX.Landing.UI.Field.BaseField({
			selector: this.selector,
			title: this.manifest.name
		});
	}
};

})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:49:"/bitrix/js/landing/node/map.min.js?17081150492472";s:6:"source";s:30:"/bitrix/js/landing/node/map.js";s:3:"min";s:34:"/bitrix/js/landing/node/map.min.js";s:3:"map";s:34:"/bitrix/js/landing/node/map.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing");var t=BX.Landing.Utils.debounce;var a=BX.Landing.Utils.data;var i=BX.Landing.Utils.proxy;var n=BX.Landing.Utils.onCustomEvent;var e=BX.Landing.Utils.encodeDataValue;BX.Landing.Block.Node.Map=function(t){BX.Landing.Block.Node.apply(this,arguments);this.type="map";this.attribute="data-map";this.hidden=true;this.createMap();this.lastValue=this.getValue();this.onBlockUpdateAttrs=this.onBlockUpdateAttrs.bind(this);n("BX.Landing.Block:Node:updateAttr",this.onBlockUpdateAttrs)};BX.Landing.Block.Node.Map.prototype={constructor:BX.Landing.Block.Node.Map,__proto__:BX.Landing.Block.Node.prototype,createMap:function(){this.mapOptions={mapContainer:this.node,mapOptions:a(this.node,"data-map"),theme:a(this.node,"data-map-theme"),roads:a(this.node,"data-map-roads")||[],landmarks:a(this.node,"data-map-landmarks")||[],labels:a(this.node,"data-map-labels")||[],onMapClick:i(this.onMapClick,this),onChange:t(this.onChange,500,this),fullscreenControl:false,mapTypeControl:false,zoomControl:false};this.map=BX.Landing.Provider.Map.create(this.node,this.mapOptions)},reinitMap:function(){const t=BX.Runtime.clone(this.mapOptions);this.mapOptions.mapOptions=a(this.node,"data-map");this.mapOptions.theme=a(this.node,"data-map-theme");this.mapOptions.roads=a(this.node,"data-map-roads")||[];this.mapOptions.landmarks=a(this.node,"data-map-landmarks")||[];this.mapOptions.labels=a(this.node,"data-map-labels")||[];if(t!==this.mapOptions){this.map.reinit(this.mapOptions)}},onBlockUpdateAttrs:function(t){if(t.node===this.node){this.reinitMap();this.lastValue=this.getValue()}},onMapClick:function(t){if(BX.Landing.UI.Panel.StylePanel.getInstance().isShown()){return}this.map.addMarker({latLng:this.map.getPointByEvent(t),title:"",description:"",showByDefault:false,draggable:true,editable:true});this.map.onMarkerClick(this.map.markers[this.map.markers.length-1])},onChange:function(t){if(this.isChanged()){if(!t){BX.Landing.History.getInstance().push()}this.lastValue=this.getValue();this.onChangeHandler(this,t)}},isChanged:function(){return JSON.stringify(this.getValue())!==JSON.stringify(this.lastValue)},getValue:function(){return this.map&&this.map.isApiLoaded()?this.map.getValue():null},getAttrValue:function(){return e(this.getValue())},setValue:function(t,a,i){this.map.setValue(t,i)},getField:function(){return new BX.Landing.UI.Field.BaseField({selector:this.selector,hidden:true})}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:54:"/bitrix/js/landing/node/component.min.js?1708115049491";s:6:"source";s:36:"/bitrix/js/landing/node/component.js";s:3:"min";s:40:"/bitrix/js/landing/node/component.min.js";s:3:"map";s:40:"/bitrix/js/landing/node/component.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.Block.Node");BX.Landing.Block.Node.Component=function(n){BX.Landing.Block.Node.apply(this,arguments);this.type="component"};BX.Landing.Block.Node.Component.prototype={constructor:BX.Landing.Block.Node.Component,__proto__:BX.Landing.Block.Node.prototype,getField:function(){return new BX.Landing.UI.Field.BaseField({selector:this.selector})},getValue:function(){return""},setValue:function(n,o,e){}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:50:"/bitrix/js/landing/node/icon.min.js?17081150491728";s:6:"source";s:31:"/bitrix/js/landing/node/icon.js";s:3:"min";s:35:"/bitrix/js/landing/node/icon.min.js";s:3:"map";s:35:"/bitrix/js/landing/node/icon.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.Block.Node");var t=BX.Landing.Utils.encodeDataValue;var n=BX.Landing.Utils.decodeDataValue;var i=BX.Landing.Utils.data;var e=BX.Landing.Utils.attr;BX.Landing.Block.Node.Icon=function(t){BX.Landing.Block.Node.Img.apply(this,arguments);this.type="icon"};function s(t){var n=i(t.node,"data-pseudo-url");return!!n?n:""}function a(t){return t.node.className.split(" ")}function o(t,n){return BX.Landing.UI.Panel.IconPanel.getLibraries().then((function(i){i.forEach((function(n){n.categories.forEach((function(n){n.items.forEach((function(n){var i="";if(BX.Type.isObject(n)){i=n.options.join(" ")}else{i=n}var e=i.split(" ");e.forEach((function(n){if(n){t.node.classList.remove(n)}}))}))}))}));n.classList.forEach((function(n){t.node.classList.add(n)}))}))}BX.Landing.Block.Node.Icon.prototype={constructor:BX.Landing.Block.Node.Icon,__proto__:BX.Landing.Block.Node.Img.prototype,getField:function(){if(!this.field){var t=this.getValue();t.url=n(t.url);var i=!!this.node.closest("a");this.field=new BX.Landing.UI.Field.Icon({selector:this.selector,title:this.manifest.name,disableLink:i,content:t,dimensions:!!this.manifest.dimensions?this.manifest.dimensions:{}})}else{this.field.content=this.getValue()}return this.field},setValue:function(t,n,i){this.lastValue=this.lastValue||this.getValue();this.preventSave(n);return o(this,t).then(function(){if(t.url){const n=this.preparePseudoUrl(t.url);if(n!==null){e(this.node,"data-pseudo-url",n)}}this.onChange(i);if(!i){BX.Landing.History.getInstance().push()}this.lastValue=this.getValue()}.bind(this))},getValue:function(){return{type:"icon",src:"",id:-1,alt:"",classList:a(this),url:t(s(this))}}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:51:"/bitrix/js/landing/node/embed.min.js?17081150492431";s:6:"source";s:32:"/bitrix/js/landing/node/embed.js";s:3:"min";s:36:"/bitrix/js/landing/node/embed.min.js";s:3:"map";s:36:"/bitrix/js/landing/node/embed.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing");var e=BX.Landing.Utils.data;BX.Landing.Block.Node.Embed=function(e){BX.Landing.Block.Node.apply(this,arguments);this.type="embed";this.attribute=["data-src","data-source","data-preview"];this.onAttributeChangeHandler=e.onAttributeChange||function(){};this.lastValue=this.getValue();this.nodeContainer=this.node.closest(BX.Landing.Block.Node.Embed.CONTAINER_SELECTOR)};BX.Landing.Block.Node.Embed.CONTAINER_SELECTOR=".embed-responsive";BX.Landing.Block.Node.Embed.RATIO_CLASSES=["embed-responsive-16by9","embed-responsive-9by16","embed-responsive-4by3","embed-responsive-3by4","embed-responsive-21by9","embed-responsive-9by21","embed-responsive-1by1"];BX.Landing.Block.Node.Embed.DEFAULT_RATIO_V="embed-responsive-9by16";BX.Landing.Block.Node.Embed.DEFAULT_RATIO_H="embed-responsive-16by9";BX.Landing.Block.Node.Embed.prototype={constructor:BX.Landing.Block.Node.Embed,__proto__:BX.Landing.Block.Node.prototype,onChange:function(e){this.lastValue=this.getValue();this.onAttributeChangeHandler(this);this.onChangeHandler(this,e)},isChanged:function(){return JSON.stringify(this.getValue())!==JSON.stringify(this.lastValue)},getValue:function(){const n=this.nodeContainer?BX.Landing.Block.Node.Embed.RATIO_CLASSES.find((e=>this.nodeContainer.classList.contains(e))):"";return{src:this.node.src?this.node.src:e(this.node,"data-src"),source:e(this.node,"data-source"),preview:e(this.node,"data-preview"),ratio:n||""}},setValue:function(n,t,i){if(this.node.src){this.node.src=n.src}else{e(this.node,"data-src",n.src)}e(this.node,"data-source",n.source);if(n.preview){e(this.node,"data-preview",n.preview);this.node.style.backgroundImage='url("'+n.preview+'")'}else{e(this.node,"data-preview",null);this.node.style.backgroundImage=""}if(n.src&&n.ratio&&this.lastValue.src!==n.src&&BX.Landing.Block.Node.Embed.RATIO_CLASSES.indexOf(n.ratio)!==-1&&this.nodeContainer){BX.Landing.Block.Node.Embed.RATIO_CLASSES.forEach((e=>{n.ratio===e?BX.Dom.addClass(this.nodeContainer,e):BX.Dom.removeClass(this.nodeContainer,e)}))}if(this.isChanged()){if(!i){BX.Landing.History.getInstance().push()}this.onChange(i)}},getField:function(){const e={title:this.manifest.name,selector:this.selector,content:this.getValue()};if(BX.Dom.hasClass(this.node.parentNode,"bg-video__inner")){return new BX.Landing.UI.Field.EmbedBg(e)}return new BX.Landing.UI.Field.Embed(e)}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:56:"/bitrix/js/landing/client/unsplash.min.js?17081150491537";s:6:"source";s:37:"/bitrix/js/landing/client/unsplash.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
(function(){"use strict";BX.namespace("BX.Landing.Client");BX.Landing.Client.Unsplash=function(){if(BX.Landing.Client.Unsplash.instance){return BX.Landing.Client.Unsplash.instance}this.host="https://api.unsplash.com";this.clientId="2f2daddc0c0ea9983e1edd64ef83925faae6d6ab6bf35fe4eb64c2bcfc76fb75";this.perPage=31};BX.Landing.Client.Unsplash.getInstance=function(){return BX.Landing.Client.Unsplash.instance||(BX.Landing.Client.Unsplash.instance=new BX.Landing.Client.Unsplash)};BX.Landing.Client.Unsplash.prototype={makeUrl:function(n,e){e=typeof e==="object"?e:{};e.client_id=this.clientId;return BX.util.add_url_param(this.host+n,e)},download:function(n){var e=BX.util.add_url_param(n.links.download_location,{client_id:this.clientId});return new Promise(function(n){BX.ajax({url:e,method:"GET",headers:[{name:"Authorization",value:"Client-ID "+this.clientId}],onsuccess:function(e){try{var t=JSON.parse(e);n(t.url)}catch(e){n("");console.error(e)}}})}.bind(this))},request:function(n,e){return new Promise(function(t){BX.ajax({url:this.makeUrl(n,e),method:"GET",data:e,headers:[{name:"Authorization",value:"Client-ID "+this.clientId}],onsuccess:function(n){var e;try{e=JSON.parse(n);e="results"in e?e.results:e}catch(n){e=[];console.error(n)}t(e)}})}.bind(this))},popular:function(n){n=BX.type.isNumber(n)?n:1;return this.request("/photos",{order_by:"popular",per_page:this.perPage,page:n})},search:function(n,e){e=BX.type.isNumber(e)?e:1;return this.request("/search/photos",{per_page:this.perPage,page:e,query:encodeURI(n)})}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:61:"/bitrix/js/landing/client/google_images.min.js?17081150491041";s:6:"source";s:42:"/bitrix/js/landing/client/google_images.js";s:3:"min";s:46:"/bitrix/js/landing/client/google_images.min.js";s:3:"map";s:46:"/bitrix/js/landing/client/google_images.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.Client");BX.Landing.Client.Google=function(){this.host="https://www.googleapis.com/customsearch/v1"};BX.Landing.Client.Google.getInstance=function(){return BX.Landing.Client.Google.instance||(BX.Landing.Client.Google.instance=new BX.Landing.Client.Google)};BX.Landing.Client.Google.prototype={makeUrl:function(e){e=typeof e==="object"?e:{};e.key=BX.Landing.Client.Google.key;e.searchType="image";e.rights="cc_attributte";e.imgSize="xxlarge";e.cx="001784514362171586730:5nd_tu8dtbw";e.safe="medium";e.imgType="photo";e.filter="1";e.num="10";return BX.util.add_url_param(this.host,e)},request:function(e){return new Promise(function(t,n){BX.ajax({url:this.makeUrl(e),method:"GET",data:e,onsuccess:function(e){var i,o;try{i=JSON.parse(e);i="items"in i?i.items:[]}catch(e){i=[];console.error(e);n(e);o=true}if(!o){t(i)}},onfailure:n})}.bind(this))},search:function(e,t){t=(BX.type.isNumber(t)?t:1)*10;return this.request({start:t,q:encodeURI(e)})}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:60:"/bitrix/js/landing/client/google_fonts.min.js?17081150491141";s:6:"source";s:41:"/bitrix/js/landing/client/google_fonts.js";s:3:"min";s:45:"/bitrix/js/landing/client/google_fonts.min.js";s:3:"map";s:45:"/bitrix/js/landing/client/google_fonts.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.Client");var n=BX.Landing.Utils.isEmpty;var t=BX.Landing.Utils.clone;BX.Landing.Client.GoogleFonts=function(){this.key="AIzaSyCqOG-HakgzOQh9prxtkuWLA16lnkNZvsg";this.patch="https://www.googleapis.com/webfonts/v1/webfonts?sort=popularity&key=";this.fontUrl="https://";this.fontUrl+=window.fontsProxyUrl||"fonts.googleapis.com";this.fontUrl+="/css2";this.response={}};BX.Landing.Client.GoogleFonts.getInstance=function(){return BX.Landing.Client.GoogleFonts.instance||(BX.Landing.Client.GoogleFonts.instance=new BX.Landing.Client.GoogleFonts)};BX.Landing.Client.GoogleFonts.prototype={getList:function(){if(!n(this.response)){return Promise.resolve(t(this.response))}return this.request().then(function(n){this.response=n;return t(this.response)}.bind(this))},request:function(){return new Promise(function(n){BX.ajax({url:this.patch+this.key,method:"GET",onsuccess:function(t){var s;try{s=JSON.parse(t);s="items"in s?s.items:s}catch(n){s=[];console.error(n)}n(s)}})}.bind(this))},makeUrl:function(n){return BX.util.add_url_param(this.fontUrl,n)}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:71:"/bitrix/js/landing/mediaservice/base_mediaservice.min.js?17081150482709";s:6:"source";s:52:"/bitrix/js/landing/mediaservice/base_mediaservice.js";s:3:"min";s:56:"/bitrix/js/landing/mediaservice/base_mediaservice.min.js";s:3:"map";s:56:"/bitrix/js/landing/mediaservice/base_mediaservice.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.MediaService");var e=BX.Landing.Utils.isArray;BX.Landing.MediaService.BaseMediaService=function(e,t){if(typeof e!=="string"){throw new TypeError("URL not a string")}this.url=encodeURI(e);this.settings=t||{};this.matcher=new RegExp("//");this.embedURL="";this.idPlace=0;this.type="iframe";this.params={};this.isDataLoaded=true;this.isBgVideoMode=false;this.isVertical=false};BX.Landing.MediaService.BaseMediaService.prototype={getMediaId:function(){return this.url.match(this.matcher)[this.idPlace]},getUserSettings:function(){var t={};var i=this.getSettingsForm();if(i){t=i.fields.fetchValues();Object.keys(t).forEach((function(i){if(e(t[i])){t[i]=encodeURIComponent(t[i].join(", "))}}))}return t},getSettings:function(){return BX.util.objectMerge(BX.clone(this.params),BX.Landing.Utils.getQueryParams(this.url),BX.clone(this.settings))},getEmbedURL:function(){var e=this.embedURL;var t=this.url.match(this.matcher);if(typeof this.embedURL==="string"){[].slice.call(t).forEach((function(t,i){e=e.replace(new RegExp("\\$"+i,"g"),t)}));var i=BX.util.objectMerge(this.getSettings(),this.getUserSettings());e=BX.util.add_url_param(e,i)}if(typeof this.embedURL==="function"){e=this.embedURL(t)}return e},getEmbedPreview:function(){var e=this.previewURL;var t=this.url.match(this.matcher);if(typeof this.previewURL==="string"){[].slice.call(t).forEach((function(t,i){e=e.replace(new RegExp("\\$"+i,"g"),t)}));return e}else if(typeof this.previewURL==="function"){return this.previewURL(t)}return false},getEmbedElement:function(){return BX.create("iframe",{attrs:{src:this.getEmbedURL(),frameborder:"0",gesture:"media",allow:"encrypted-media",allowfullscreen:true}})},getURLPreview:function(){return BX.Landing.Utils.getURLPreview(this.url)},getURLPreviewElement:function(){return this.getURLPreview().then(function(e){var t=e.DESCRIPTION;var i=e.TITLE;if(i.length+t.length>120){if(i.length>120){t="";i=i.slice(0,120)+"..."}else if(i.length+t.length>120){t=t.slice(0,t.length-(i.length+t.length-120))+"..."}}return BX.create("div",{props:{className:"landing-ui-mediaservice-url-preview"},children:[BX.create("div",{props:{className:"landing-ui-mediaservice-url-preview-image"},attrs:{style:'background-image: url("'+e.IMAGE+'")'}}),BX.create("div",{props:{className:"landing-ui-mediaservice-url-preview-text"},children:[BX.create("div",{props:{className:"landing-ui-mediaservice-url-preview-text-title"},text:i}),BX.create("div",{props:{className:"landing-ui-mediaservice-url-preview-text-description"},text:t})]})]})}.bind(this))},getSettingsForm:function(){return null},setBgVideoMode(e){this.isBgVideoMode=!!e}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:74:"/bitrix/js/landing/mediaservice/youtube_mediaservice.min.js?17081150483285";s:6:"source";s:55:"/bitrix/js/landing/mediaservice/youtube_mediaservice.js";s:3:"min";s:59:"/bitrix/js/landing/mediaservice/youtube_mediaservice.min.js";s:3:"map";s:59:"/bitrix/js/landing/mediaservice/youtube_mediaservice.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.MediaService");BX.Landing.MediaService.Youtube=function(e,i){BX.Landing.MediaService.BaseMediaService.apply(this,arguments);this.matcher=BX.Landing.Utils.Matchers.youtube;this.embedURL="//www.youtube.com/embed/$6";this.previewURL="//img.youtube.com/vi/$6/sddefault.jpg";this.loadEmbedInfo();this.idPlace=6;this.params={autoplay:0,controls:1,loop:0,mute:0,rel:0,start:0,html5:1}};BX.Landing.MediaService.Youtube.validate=function(e){return BX.Landing.Utils.Matchers.youtube.test(e)};BX.Landing.MediaService.Youtube.prototype={constructor:BX.Landing.MediaService.Youtube,__proto__:BX.Landing.MediaService.BaseMediaService.prototype,getSettingsForm:function(){if(!this.form){this.form=new BX.Landing.UI.Form.BaseForm;var e=this.getSettings();this.form.addField(new BX.Landing.UI.Field.Dropdown({title:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_AUTOPLAY"),description:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_AUTOPLAY_DESC_NEW"),selector:"autoplay",content:!this.isBgVideoMode?parseInt(e.autoplay):1,items:[{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_YES"),value:1},{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_NO"),value:0}],onChange:!this.isBgVideoMode?n:()=>{},disabled:this.isBgVideoMode}));function n(e){if(e===1){i.setValue(1);i.disable();if(!i.descriptionText){i.setDescription(BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_SOUND_ALERT"))}}else if(e===0){i.removeDescription();i.enable();i.setValue(0)}}var i=new BX.Landing.UI.Field.Dropdown({title:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_SOUND"),selector:"mute",content:!this.isBgVideoMode?parseInt(e.mute):1,items:[{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_YES"),value:0},{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_NO"),value:1}],disabled:this.isBgVideoMode});this.form.addField(i);this.form.addField(new BX.Landing.UI.Field.Dropdown({title:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_CONTROLS"),selector:"controls",content:!this.isBgVideoMode?parseInt(e.controls):0,items:[{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_YES"),value:1},{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_NO"),value:0}],disabled:this.isBgVideoMode}));this.form.addField(new BX.Landing.UI.Field.Dropdown({title:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_LOOP"),selector:"loop",content:!this.isBgVideoMode?parseInt(e.loop):1,items:[{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_YES"),value:1},{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_NO"),value:0}],disabled:this.isBgVideoMode}));var t=new BX.Landing.UI.Field.Unit({title:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_START"),selector:"start",unit:BX.Landing.Loc.getMessage("LANDING_CONTENT_MEDIA_SECONDS_SHORT"),content:parseInt(e.start),placeholder:"40"});this.form.addField(t);if(!this.isBgVideoMode){n(parseInt(e.autoplay))}}return this.form},loadEmbedInfo:function(){const e="https://www.youtube.com/oembed?format=json&url="+this.url;BX.ajax({url:e,method:"GET",dataType:"json",onsuccess:e=>{if(e.height&&e.width&&e.height>e.width){this.isVertical=true}if(e.thumbnail_url){this.previewURL=e.thumbnail_url}}})}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:72:"/bitrix/js/landing/mediaservice/rutube_mediaservice.min.js?1708115048971";s:6:"source";s:54:"/bitrix/js/landing/mediaservice/rutube_mediaservice.js";s:3:"min";s:58:"/bitrix/js/landing/mediaservice/rutube_mediaservice.min.js";s:3:"map";s:58:"/bitrix/js/landing/mediaservice/rutube_mediaservice.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.MediaService");BX.Landing.MediaService.Rutube=function(e,t){BX.Landing.MediaService.BaseMediaService.apply(this,arguments);this.matcher=BX.Landing.Utils.Matchers.rutube;this.embedURL="//rutube.ru/play/embed/$2";this.idPlace=2;this.params={t:0}};BX.Landing.MediaService.Rutube.validate=function(e){return BX.Landing.Utils.Matchers.rutube.test(e)};BX.Landing.MediaService.Rutube.prototype={constructor:BX.Landing.MediaService.Rutube,__proto__:BX.Landing.MediaService.BaseMediaService.prototype,getSettingsForm:function(){if(!this.form){this.form=new BX.Landing.UI.Form.BaseForm;var e=this.getSettings();var t=new BX.Landing.UI.Field.Unit({title:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_START"),unit:BX.Landing.Loc.getMessage("LANDING_CONTENT_MEDIA_SECONDS_SHORT"),selector:"t",content:parseInt(e.t),placeholder:"40"});this.form.addField(t)}return this.form}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:69:"/bitrix/js/landing/mediaservice/vk_mediaservice.min.js?17081150483055";s:6:"source";s:50:"/bitrix/js/landing/mediaservice/vk_mediaservice.js";s:3:"min";s:54:"/bitrix/js/landing/mediaservice/vk_mediaservice.min.js";s:3:"map";s:54:"/bitrix/js/landing/mediaservice/vk_mediaservice.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.MediaService");BX.Landing.MediaService.Vk=function(e,t){BX.Landing.MediaService.BaseMediaService.apply(this,arguments);this.matcher=BX.Landing.Utils.Matchers.vk;this.isDataLoaded=false;this.embedInfoLoader=this.loadEmbedInfo();this.embedInfoLoader.then((e=>{this.isDataLoaded=true;BX.onCustomEvent(this,"onDataLoaded")})).catch((e=>{BX.onCustomEvent(this,"onDataLoadError",[{message:e}])}));this.embedInfo=null;this.embedURL=()=>{if(this.embedInfo){const e=BX.util.objectMerge(this.getSettings(),this.getUserSettings());if(this.isAnotherService()&&e.autoplay==1){e.mute=1}this.embedInfo.embedUrl=BX.util.add_url_param(this.embedInfo.embedUrl,e)}return this.embedInfo?this.embedInfo["embedUrl"]:""};this.previewURL=()=>this.embedInfo?this.embedInfo["preview"]:"";this.idPlace=3;this.params={autoplay:0}};BX.Landing.MediaService.Vk.validate=function(e){return BX.Landing.Utils.Matchers.vk.test(e)};BX.Landing.MediaService.Vk.prototype={constructor:BX.Landing.MediaService.Vk,__proto__:BX.Landing.MediaService.BaseMediaService.prototype,getSettingsForm:function(){if(!this.form){this.form=new BX.Landing.UI.Form.BaseForm;var e=this.getSettings();this.form.addField(new BX.Landing.UI.Field.Dropdown({title:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_AUTOPLAY"),description:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_AUTOPLAY_DESC_NEW"),selector:"autoplay",content:!this.isBgVideoMode?parseInt(e.autoplay):1,items:[{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_YES"),value:1},{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_NO"),value:0}],disabled:this.isBgVideoMode}))}return this.form},loadEmbedInfo:function(){const e=BX.Landing.Backend.getInstance();return e.action("Vk::isAuthorized").then((t=>{if(!t){return e.action("Vk::getAuthUrl").then((e=>new Promise((t=>{BX.addCustomEvent(window,"seo-client-auth-result",(e=>{e.reload=false;t()}));BX.util.popup(e,800,600)}))))}return Promise.resolve()})).then((()=>{const t=this.url.match(this.matcher);if(t&&t.length){const i=t[this.idPlace];return e.action("Vk::getVideoInfo",{videoId:i}).then((e=>{this.embedInfo={embedUrl:e.player,preview:e.preview.url};this.isAnotherService(this.embedInfo.embedUrl);{this.convertToAnotherService(this.embedInfo.embedUrl)}return this.embedInfo})).catch((e=>{if(e.type==="error"&&BX.Type.isArray(e.result)){const t=[];e.result.forEach((e=>{t.push(e.error_description)}));return Promise.reject(t.join(". "))}}))}return Promise.reject("Wrong VK video url")}))},isAnotherService:function(){return BX.Landing.Utils.Matchers.youtube.test(this.embedInfo.embedUrl)},convertToAnotherService:function(){const e=this.embedInfo.embedUrl;if(BX.Landing.Utils.Matchers.youtube.test(e)){const t=e.match(BX.Landing.Utils.Matchers.youtube)[4];this.url="https://www.youtube.com/watch?v="+t}},getURLPreview:function(){return this.embedInfoLoader.then((()=>BX.Landing.Utils.getURLPreview(this.url))).then((e=>{e.IMAGE=this.embedInfo.preview;return e}))}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:72:"/bitrix/js/landing/mediaservice/vimeo_mediaservice.min.js?17081150482897";s:6:"source";s:53:"/bitrix/js/landing/mediaservice/vimeo_mediaservice.js";s:3:"min";s:57:"/bitrix/js/landing/mediaservice/vimeo_mediaservice.min.js";s:3:"map";s:57:"/bitrix/js/landing/mediaservice/vimeo_mediaservice.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.MediaService");BX.Landing.MediaService.Vimeo=function(e,a){BX.Landing.MediaService.BaseMediaService.apply(this,arguments);this.matcher=BX.Landing.Utils.Matchers.vimeo;this.embedURL="//player.vimeo.com/video/$2";this.idPlace=3;this.params={autoplay:1,loop:0,hd:1,muted:0,background:0,show_title:1,show_byline:1,show_portrait:0,fullscreen:1,api:1}};BX.Landing.MediaService.Vimeo.validate=function(e){return BX.Landing.Utils.Matchers.vimeo.test(e)};BX.Landing.MediaService.Vimeo.prototype={constructor:BX.Landing.MediaService.Vimeo,__proto__:BX.Landing.MediaService.BaseMediaService.prototype,getSettingsForm:function(){if(!this.form){this.form=new BX.Landing.UI.Form.BaseForm;var e=this.getSettings();this.form.addField(new BX.Landing.UI.Field.Dropdown({title:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_AUTOPLAY"),selector:"autoplay",content:parseInt(e.autoplay),items:[{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_YES"),value:1},{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_NO"),value:0}],onChange:a}));function a(e){if(e===1){n.setValue(1);n.disable();if(!n.descriptionText){n.setDescription(BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_SOUND_ALERT"))}}else if(e===0){n.removeDescription();n.enable();n.setValue(0)}}var n=new BX.Landing.UI.Field.Dropdown({title:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_SOUND"),selector:"muted",content:e.muted,items:[{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_YES"),value:0},{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_NO"),value:1}]});this.form.addField(n);a(parseInt(e.autoplay));this.form.addField(new BX.Landing.UI.Field.Dropdown({title:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_CONTROLS"),selector:"background",content:parseInt(e.background),items:[{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_YES"),value:0},{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_NO"),value:1}]}));this.form.addField(new BX.Landing.UI.Field.Dropdown({title:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_QUALITY"),selector:"quality",content:e.quality,items:[{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_QUALITY_AUTO"),value:""},{name:"4k ("+BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_QUALITY_HIGH")+")",value:"4k"},{name:"2k",value:"2k"},{name:"1080p",value:"1080p"},{name:"780p",value:"780p"},{name:"360p ("+BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_QUALITY_LOW")+")",value:"360p"}]}));this.form.addField(new BX.Landing.UI.Field.Dropdown({title:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_LOOP"),selector:"loop",content:e.loop,items:[{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_YES"),value:1},{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_NO"),value:0}]}))}return this.form}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:71:"/bitrix/js/landing/mediaservice/vine_mediaservice.min.js?17081150481047";s:6:"source";s:52:"/bitrix/js/landing/mediaservice/vine_mediaservice.js";s:3:"min";s:56:"/bitrix/js/landing/mediaservice/vine_mediaservice.min.js";s:3:"map";s:56:"/bitrix/js/landing/mediaservice/vine_mediaservice.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.MediaService");BX.Landing.MediaService.Vine=function(e,i){BX.Landing.MediaService.BaseMediaService.apply(this,arguments);this.matcher=BX.Landing.Utils.Matchers.vine;this.embedURL="//vine.co/v/$1/embed/simple";this.idPlace=1;this.params={autoplay:1}};BX.Landing.MediaService.Vine.validate=function(e){return BX.Landing.Utils.Matchers.vine.test(e)};BX.Landing.MediaService.Vine.prototype={constructor:BX.Landing.MediaService.Vine,__proto__:BX.Landing.MediaService.BaseMediaService.prototype,getSettingsForm:function(){if(!this.form){this.form=new BX.Landing.UI.Form.BaseForm;var e=this.getSettings();this.form.addField(new BX.Landing.UI.Field.Dropdown({title:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_AUTOPLAY"),selector:"autoplay",content:parseInt(e.autoplay),items:[{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_YES"),value:1},{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_NO"),value:0}]}))}return this.form}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:76:"/bitrix/js/landing/mediaservice/instagram_mediaservice.min.js?17081150481215";s:6:"source";s:57:"/bitrix/js/landing/mediaservice/instagram_mediaservice.js";s:3:"min";s:61:"/bitrix/js/landing/mediaservice/instagram_mediaservice.min.js";s:3:"map";s:61:"/bitrix/js/landing/mediaservice/instagram_mediaservice.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.MediaService");BX.Landing.MediaService.Instagram=function(e,i){BX.Landing.MediaService.BaseMediaService.apply(this,arguments);this.matcher=BX.Landing.Utils.Matchers.instagram;this.embedURL="//instagram.com/p/$2/embed/captioned";this.idPlace=1;this.params={}};BX.Landing.MediaService.Instagram.validate=function(e){return BX.Landing.Utils.Matchers.instagram.test(e)};BX.Landing.MediaService.Instagram.prototype={constructor:BX.Landing.MediaService.Instagram,__proto__:BX.Landing.MediaService.BaseMediaService.prototype,getSettingsForm:function(){if(!this.form){this.form=new BX.Landing.UI.Form.BaseForm;this.form.addField(new BX.Landing.UI.Field.Dropdown({title:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_CAPTIONED"),selector:"captioned",items:[{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_YES"),value:1},{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_NO"),value:0}],onChange:function(e){if(e===1){if(this.embedURL.indexOf("captioned")===-1){this.embedURL=this.embedURL+"captioned"}}else{this.embedURL=this.embedURL.replace("captioned","")}}.bind(this)}))}return this.form}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:85:"/bitrix/js/landing/mediaservice/google_maps_search_mediaservice.min.js?17081150481169";s:6:"source";s:66:"/bitrix/js/landing/mediaservice/google_maps_search_mediaservice.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
(function(){"use strict";BX.namespace("BX.Landing.MediaService");BX.Landing.MediaService.GoogleMapsSearch=function(e,i){BX.Landing.MediaService.BaseMediaService.apply(this,arguments);this.matcher=BX.Landing.Utils.Matchers.googleMapsSearch;this.embedURL=function(e){var i="";if(e[5]){i=e[5].replace("query=","q=").replace("api=1","")}else if(e[9]){i=e[9]}return"//maps.google."+e[2]+"/maps?q="+i+"&output=embed"}};BX.Landing.MediaService.GoogleMapsSearch.validate=function(e){return BX.Landing.Utils.Matchers.googleMapsSearch.test(e)};BX.Landing.MediaService.GoogleMapsSearch.prototype={constructor:BX.Landing.MediaService.GoogleMapsSearch,__proto__:BX.Landing.MediaService.BaseMediaService.prototype,getURLPreviewElement:function(){return new Promise(function(e){var i='<span class="fa fa-map"></span>&nbsp;Google Maps';setTimeout(function(){e(BX.create("div",{props:{className:"landing-ui-mediaservice-url-preview landing-ui-mediaservice-url-preview-map"},children:[BX.create("div",{props:{className:"landing-ui-mediaservice-url-preview-text"},children:[BX.create("div",{props:{className:"landing-ui-mediaservice-url-preview-text-title"},html:i})]})]}))},400)})}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:83:"/bitrix/js/landing/mediaservice/google_maps_place_mediaservice.min.js?1708115048828";s:6:"source";s:65:"/bitrix/js/landing/mediaservice/google_maps_place_mediaservice.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
(function(){"use strict";BX.namespace("BX.Landing.MediaService");BX.Landing.MediaService.GoogleMapsPlace=function(e,a){BX.Landing.MediaService.GoogleMapsSearch.apply(this,arguments);this.matcher=BX.Landing.Utils.Matchers.googleMapsPlace;this.embedURL=function(e){var a="//maps.google."+e[2]+"/?ll="+(e[9]?e[9]+"&z="+Math.floor(e[10])+(e[12]?e[12].replace(/^\//,"&"):""):e[12])+"&output="+(e[12]&&e[12].indexOf("layer=c")>0?"svembed":"embed");if(e[8]){a="//maps.google."+e[2]+"/maps?q="+decodeURI(decodeURI(e[8]))+"&output=embed"}return a}};BX.Landing.MediaService.GoogleMapsPlace.validate=function(e){return BX.Landing.Utils.Matchers.googleMapsPlace.test(e)};BX.Landing.MediaService.GoogleMapsPlace.prototype={constructor:BX.Landing.MediaService.GoogleMapsPlace,__proto__:BX.Landing.MediaService.GoogleMapsSearch.prototype}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:82:"/bitrix/js/landing/mediaservice/facebook_page_plugin_service.min.js?17081150482767";s:6:"source";s:63:"/bitrix/js/landing/mediaservice/facebook_page_plugin_service.js";s:3:"min";s:67:"/bitrix/js/landing/mediaservice/facebook_page_plugin_service.min.js";s:3:"map";s:67:"/bitrix/js/landing/mediaservice/facebook_page_plugin_service.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.MediaService");var e=BX.Landing.Utils.isString;BX.Landing.MediaService.FacebookPages=function(e,a){BX.Landing.MediaService.BaseMediaService.apply(this,arguments);this.matcher=BX.Landing.Utils.Matchers.facebookPages;this.pageUrl=encodeURIComponent(e.replace(/\/$/,""));this.embedURL="https://www.facebook.com/plugins/page.php?href="+this.pageUrl;this.params={tabs:"timeline",width:340,small_header:false,adapt_container_width:true,hide_cover:false,show_facepile:true}};BX.Landing.MediaService.FacebookPages.validate=function(e){if(e.endsWith&&(e.endsWith("facebook.com/")||e.endsWith("facebook.com"))){return false}return BX.Landing.Utils.Matchers.facebookPages.test(e)};BX.Landing.MediaService.FacebookPages.prototype={constructor:BX.Landing.MediaService.FacebookPages,__proto__:BX.Landing.MediaService.BaseMediaService.prototype,getSettingsForm:function(){if(!this.form){this.form=new BX.Landing.UI.Form.BaseForm;var a=this.getSettings();this.form.addField(new BX.Landing.UI.Field.Dropdown({title:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_FB_PAGE_SMALL_HEADER"),selector:"small_header",content:a.small_header==="true"||a.small_header===true,items:[{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_YES"),value:true},{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_NO"),value:false}]}));this.form.addField(new BX.Landing.UI.Field.Dropdown({title:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_FB_PAGE_COVER"),selector:"hide_cover",content:a.hide_cover==="true"||a.hide_cover===true,items:[{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_YES"),value:false},{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_NO"),value:true}]}));this.form.addField(new BX.Landing.UI.Field.Dropdown({title:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_FB_PAGE_FACES"),selector:"show_facepile",content:a.show_facepile==="true"||a.show_facepile===true,items:[{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_YES"),value:true},{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_NO"),value:false}]}));var i=[{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_FB_PAGE_TABS_TIMELINE"),value:"timeline"},{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_FB_PAGE_TABS_MESSAGES"),value:"messages"},{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_FB_PAGE_TABS_EVENTS"),value:"events"}];var t=e(a.tabs)?a.tabs.split(", "):[];if(t.length){i.forEach(function(e){e.selected=t.includes(e.value)})}this.form.addField(new BX.Landing.UI.Field.MultiSelect({title:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_FB_PAGE_TABS"),selector:"tabs",value:t,items:i}))}return this.form}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:81:"/bitrix/js/landing/mediaservice/facebook_post_embed_service.min.js?17081150481228";s:6:"source";s:62:"/bitrix/js/landing/mediaservice/facebook_post_embed_service.js";s:3:"min";s:66:"/bitrix/js/landing/mediaservice/facebook_post_embed_service.min.js";s:3:"map";s:66:"/bitrix/js/landing/mediaservice/facebook_post_embed_service.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.MediaService");BX.Landing.MediaService.FacebookPosts=function(e,t){BX.Landing.MediaService.BaseMediaService.apply(this,arguments);this.matcher=BX.Landing.Utils.Matchers.facebookPosts;this.pageUrl=encodeURIComponent(e.replace(/\/$/,""));this.embedURL="https://www.facebook.com/plugins/post.php?href="+this.pageUrl;this.params={width:500,show_text:true}};BX.Landing.MediaService.FacebookPosts.validate=function(e){return BX.Landing.Utils.Matchers.facebookPosts.test(e)};BX.Landing.MediaService.FacebookPosts.prototype={constructor:BX.Landing.MediaService.FacebookPosts,__proto__:BX.Landing.MediaService.BaseMediaService.prototype,getSettingsForm:function(){if(!this.form){this.form=new BX.Landing.UI.Form.BaseForm;var e=this.getSettings();this.form.addField(new BX.Landing.UI.Field.Dropdown({title:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_FB_POST_FULL"),selector:"show_text",content:e.show_text==="true"||e.show_text===true,items:[{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_YES"),value:true},{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_NO"),value:false}]}))}return this.form}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:82:"/bitrix/js/landing/mediaservice/facebook_video_embed_service.min.js?17081150481239";s:6:"source";s:63:"/bitrix/js/landing/mediaservice/facebook_video_embed_service.js";s:3:"min";s:67:"/bitrix/js/landing/mediaservice/facebook_video_embed_service.min.js";s:3:"map";s:67:"/bitrix/js/landing/mediaservice/facebook_video_embed_service.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.MediaService");BX.Landing.MediaService.FacebookVideos=function(e,i){BX.Landing.MediaService.BaseMediaService.apply(this,arguments);this.matcher=BX.Landing.Utils.Matchers.facebookVideos;this.pageUrl=encodeURIComponent(e.replace(/\/$/,""));this.embedURL="https://www.facebook.com/plugins/video.php?href="+this.pageUrl;this.params={width:500,show_text:0}};BX.Landing.MediaService.FacebookVideos.validate=function(e){return BX.Landing.Utils.Matchers.facebookVideos.test(e)};BX.Landing.MediaService.FacebookVideos.prototype={constructor:BX.Landing.MediaService.FacebookVideos,__proto__:BX.Landing.MediaService.BaseMediaService.prototype,getSettingsForm:function(){if(!this.form){this.form=new BX.Landing.UI.Form.BaseForm;var e=this.getSettings();this.form.addField(new BX.Landing.UI.Field.Dropdown({title:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_FB_POST_FULL"),selector:"show_text",content:!isNaN(parseInt(e.show_text))?parseInt(e.show_text):0,items:[{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_YES"),value:1},{name:BX.Landing.Loc.getMessage("LANDING_CONTENT_URL_MEDIA_NO"),value:0}]}))}return this.form}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:68:"/bitrix/js/landing/mediaservice/service_factory.min.js?1708115048847";s:6:"source";s:50:"/bitrix/js/landing/mediaservice/service_factory.js";s:3:"min";s:54:"/bitrix/js/landing/mediaservice/service_factory.min.js";s:3:"map";s:54:"/bitrix/js/landing/mediaservice/service_factory.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing.MediaService");BX.Landing.MediaService.Factory=function(){};BX.Landing.MediaService.Factory.prototype={services:{youtube:"BX.Landing.MediaService.Youtube",rutube:"BX.Landing.MediaService.Rutube",vk:"BX.Landing.MediaService.Vk",vimeo:"BX.Landing.MediaService.Vimeo",vine:"BX.Landing.MediaService.Vine",instagram:"BX.Landing.MediaService.Instagram",facebookVideos:"BX.Landing.MediaService.FacebookVideos",facebookPosts:"BX.Landing.MediaService.FacebookPosts"},create:function(e,i){const n=this.getRelevantClass(e);if(n){return new n(e,i)}return null},getRelevantClass:function(e){let i=null;for(let n in this.services){if(this.services.hasOwnProperty(n)&&BX.getClass(this.services[n])["validate"](e)){i=BX.getClass(this.services[n]);break}}return i}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:54:"/bitrix/js/landing/error_manager.min.js?17081150492325";s:6:"source";s:35:"/bitrix/js/landing/error_manager.js";s:3:"min";s:39:"/bitrix/js/landing/error_manager.min.js";s:3:"map";s:39:"/bitrix/js/landing/error_manager.map.js";}"*/
(function(){"use strict";BX.namespace("BX.Landing");var n=BX.Landing.Utils.clone;var e={"Landing::addBlock":BX.Landing.Loc.getMessage("LANDING_ACTION_ERROR__ADD_BLOCK"),"Landing::deleteBlock":BX.Landing.Loc.getMessage("LANDING_ACTION_ERROR__DELETE_BLOCK"),"Landing::upBlock":BX.Landing.Loc.getMessage("LANDING_ACTION_ERROR__SAVE_CHANGES"),"Landing::downBlock":BX.Landing.Loc.getMessage("LANDING_ACTION_ERROR__SAVE_CHANGES"),"Landing::showBlock":BX.Landing.Loc.getMessage("LANDING_ACTION_ERROR__SAVE_CHANGES"),"Landing::hideBlock":BX.Landing.Loc.getMessage("LANDING_ACTION_ERROR__SAVE_CHANGES"),"Block::cloneCard":BX.Landing.Loc.getMessage("LANDING_ACTION_ERROR__CLONE_CARD"),"Block::removeCard":BX.Landing.Loc.getMessage("LANDING_ACTION_ERROR__DELETE_CARD"),"Block::updateStyles":BX.Landing.Loc.getMessage("LANDING_ACTION_ERROR__SAVE_CHANGES"),"Block::updateNodes":BX.Landing.Loc.getMessage("LANDING_ACTION_ERROR__SAVE_CHANGES"),"Site::getList":BX.Landing.Loc.getMessage("LANDING_ACTION_ERROR__SITE_GET_LIST"),"Block::getList":BX.Landing.Loc.getMessage("LANDING_ACTION_ERROR__BLOCK_GET_LIST"),"Utils::uploadFile":BX.Landing.Loc.getMessage("LANDING_ACTION_ERROR__UPLOAD_FILE"),UNKNOWN_ACTION:BX.Landing.Loc.getMessage("LANDING_ACTION_ERROR__UNKNOWN_ACTION"),BAD_IMAGE:BX.Landing.Loc.getMessage("LANDING_ACTION_ERROR__BAD_IMAGE")};BX.Landing.ErrorManager=function(){this.stack=[];this.showTimeout=null};BX.Landing.ErrorManager.getInstance=function(){var n=BX.Landing.PageObject.getRootWindow();if(!n.BX.Landing.ErrorManager.instance){n.BX.Landing.ErrorManager.instance=new BX.Landing.ErrorManager}return n.BX.Landing.ErrorManager.instance};BX.Landing.ErrorManager.prototype={add:function(n){if(n.type==="error"){n.action=n.action in e?n.action:"UNKNOWN_ACTION";this.stack.push({action:n.action,description:e[n.action],hideSupportLink:n.hideSupportLink});return this.show()}},show:function(){clearTimeout(this.showTimeout);this.showTimeout=setTimeout(function(){var e=n(this.stack);this.stack=[];var a=e.map(this.createErrorMessage,this).join("");var i=e.some(function(n){return n.hideSupportLink===true});BX.Landing.UI.Panel.Alert.getInstance().show("error",a,i)}.bind(this),100)},createErrorMessage:function(n){return'<div class="landing-ui-error-item">'+n.description+"</div>"}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:86:"/bitrix/js/landing/external/webfontloader/webfontloader_landing.min.js?170811504912558";s:6:"source";s:66:"/bitrix/js/landing/external/webfontloader/webfontloader_landing.js";s:3:"min";s:70:"/bitrix/js/landing/external/webfontloader/webfontloader_landing.min.js";s:3:"map";s:70:"/bitrix/js/landing/external/webfontloader/webfontloader_landing.map.js";}"*/
(function(){function t(t,n,i){return t.call.apply(t.bind,arguments)}function n(t,n,i){if(!t)throw Error();if(2<arguments.length){var e=Array.prototype.slice.call(arguments,2);return function(){var i=Array.prototype.slice.call(arguments);Array.prototype.unshift.apply(i,e);return t.apply(n,i)}}return function(){return t.apply(n,arguments)}}function i(e,o,a){i=Function.prototype.bind&&-1!=Function.prototype.bind.toString().indexOf("native code")?t:n;return i.apply(null,arguments)}var e=Date.now||function(){return+new Date};function o(t,n){this.a=t;this.m=n||t;this.c=this.m.document}var a=!!window.FontFace;function s(t,n,i,e){n=t.c.createElement(n);if(i)for(var o in i)i.hasOwnProperty(o)&&("style"==o?n.style.cssText=i[o]:n.setAttribute(o,i[o]));e&&n.appendChild(t.c.createTextNode(e));return n}function r(t,n,i){t=t.c.getElementsByTagName(n)[0];t||(t=document.documentElement);t.insertBefore(i,t.lastChild)}function f(t){t.parentNode&&t.parentNode.removeChild(t)}function c(t,n,i){n=n||[];i=i||[];for(var e=t.className.split(/\s+/),o=0;o<n.length;o+=1){for(var a=!1,s=0;s<e.length;s+=1)if(n[o]===e[s]){a=!0;break}a||e.push(n[o])}n=[];for(o=0;o<e.length;o+=1){a=!1;for(s=0;s<i.length;s+=1)if(e[o]===i[s]){a=!0;break}a||n.push(e[o])}t.className=n.join(" ").replace(/\s+/g," ").replace(/^\s+|\s+$/,"")}function h(t,n){for(var i=t.className.split(/\s+/),e=0,o=i.length;e<o;e++)if(i[e]==n)return!0;return!1}function l(t){if("string"===typeof t.f)return t.f;var n=t.m.location.protocol;"about:"==n&&(n=t.a.location.protocol);return"https:"==n?"https:":"http:"}function u(t){return t.m.location.hostname||t.a.location.hostname}function p(t,n,i){function e(){h&&o&&f&&(h(c),h=null)}n=s(t,"link",{rel:"stylesheet",href:n,media:"all"});var o=!1,f=!0,c=null,h=i||null;a?(n.onload=function(){o=!0;e()},n.onerror=function(){o=!0;c=Error("Stylesheet failed to load");e()}):setTimeout((function(){o=!0;e()}),0);r(t,"head",n)}function d(t,n,i,e){var o=t.c.getElementsByTagName("head")[0];if(o){var a=s(t,"script",{src:n}),r=!1;a.onload=a.onreadystatechange=function(){r||this.readyState&&"loaded"!=this.readyState&&"complete"!=this.readyState||(r=!0,i&&i(null),a.onload=a.onreadystatechange=null,"HEAD"==a.parentNode.tagName&&o.removeChild(a))};o.appendChild(a);setTimeout((function(){r||(r=!0,i&&i(Error("Script load timeout")))}),e||5e3);return a}return null}function g(){this.a=0;this.c=null}function v(t){t.a++;return function(){t.a--;m(t)}}function w(t,n){t.c=n;m(t)}function m(t){0==t.a&&t.c&&(t.c(),t.c=null)}function y(t){this.a=t||"-"}y.prototype.c=function(t){for(var n=[],i=0;i<arguments.length;i++)n.push(arguments[i].replace(/[\W_]+/g,"").toLowerCase());return n.join(this.a)};function b(t,n){this.c=t;this.f=4;this.a="n";var i=(n||"n4").match(/^([nio])([1-9])$/i);i&&(this.a=i[1],this.f=parseInt(i[2],10))}function x(t){return k(t)+" "+(t.f+"00")+" 300px "+j(t.c)}function j(t){var n=[];t=t.split(/,\s*/);for(var i=0;i<t.length;i++){var e=t[i].replace(/['"]/g,"");-1!=e.indexOf(" ")||/^\d/.test(e)?n.push("'"+e+"'"):n.push(e)}return n.join(",")}function _(t){return t.a+t.f}function k(t){var n="normal";"o"===t.a?n="oblique":"i"===t.a&&(n="italic");return n}function T(t){var n=4,i="n",e=null;t&&((e=t.match(/(normal|oblique|italic)/i))&&e[1]&&(i=e[1].substr(0,1).toLowerCase()),(e=t.match(/([1-9]00|normal|bold)/i))&&e[1]&&(/bold/i.test(e[1])?n=7:/[1-9]00/.test(e[1])&&(n=parseInt(e[1].substr(0,1),10))));return i+n}function S(t,n){this.c=t;this.f=t.m.document.documentElement;this.h=n;this.a=new y("-");this.j=!1!==n.events;this.g=!1!==n.classes}function C(t){t.g&&c(t.f,[t.a.c("wf","loading")]);A(t,"loading")}function N(t){if(t.g){var n=h(t.f,t.a.c("wf","active")),i=[],e=[t.a.c("wf","loading")];n||i.push(t.a.c("wf","inactive"));c(t.f,i,e)}A(t,"inactive")}function A(t,n,i){if(t.j&&t.h[n])if(i)t.h[n](i.c,_(i));else t.h[n]()}function E(){this.c={}}function W(t,n,i){var e=[],o;for(o in n)if(n.hasOwnProperty(o)){var a=t.c[o];a&&e.push(a(n[o],i))}return e}function F(t,n){this.c=t;this.f=n;this.a=s(this.c,"span",{"aria-hidden":"true"},this.f)}function I(t){r(t.c,"body",t.a)}function P(t){return"display:block;position:absolute;top:-9999px;left:-9999px;font-size:300px;width:auto;height:auto;line-height:normal;margin:0;padding:0;font-variant:normal;white-space:nowrap;font-family:"+j(t.c)+";"+("font-style:"+k(t)+";font-weight:"+(t.f+"00")+";")}function B(t,n,i,e,o,a){this.g=t;this.j=n;this.a=e;this.c=i;this.f=o||3e3;this.h=a||void 0}B.prototype.start=function(){var t=this.c.m.document,n=this,i=e(),o=new Promise((function(o,a){function s(){e()-i>=n.f?a():t.fonts.load(x(n.a),n.h).then((function(t){1<=t.length?o():setTimeout(s,25)}),(function(){a()}))}s()})),a=new Promise((function(t,i){setTimeout(i,n.f)}));Promise.race([a,o]).then((function(){n.g(n.a)}),(function(){n.j(n.a)}))};function O(t,n,i,e,o,a,s){this.v=t;this.B=n;this.c=i;this.a=e;this.s=s||"BESbswy";this.f={};this.w=o||3e3;this.u=a||null;this.o=this.j=this.h=this.g=null;this.g=new F(this.c,this.s);this.h=new F(this.c,this.s);this.j=new F(this.c,this.s);this.o=new F(this.c,this.s);t=new b(this.a.c+",serif",_(this.a));t=P(t);this.g.a.style.cssText=t;t=new b(this.a.c+",sans-serif",_(this.a));t=P(t);this.h.a.style.cssText=t;t=new b("serif",_(this.a));t=P(t);this.j.a.style.cssText=t;t=new b("sans-serif",_(this.a));t=P(t);this.o.a.style.cssText=t;I(this.g);I(this.h);I(this.j);I(this.o)}var L={D:"serif",C:"sans-serif"},D=null;function $(){if(null===D){var t=/AppleWebKit\/([0-9]+)(?:\.([0-9]+))/.exec(window.navigator.userAgent);D=!!t&&(536>parseInt(t[1],10)||536===parseInt(t[1],10)&&11>=parseInt(t[2],10))}return D}O.prototype.start=function(){this.f.serif=this.j.a.offsetWidth;this.f["sans-serif"]=this.o.a.offsetWidth;this.A=e();H(this)};function q(t,n,i){for(var e in L)if(L.hasOwnProperty(e)&&n===t.f[L[e]]&&i===t.f[L[e]])return!0;return!1}function H(t){var n=t.g.a.offsetWidth,i=t.h.a.offsetWidth,o;(o=n===t.f.serif&&i===t.f["sans-serif"])||(o=$()&&q(t,n,i));o?e()-t.A>=t.w?$()&&q(t,n,i)&&(null===t.u||t.u.hasOwnProperty(t.a.c))?U(t,t.v):U(t,t.B):M(t):U(t,t.v)}function M(t){setTimeout(i((function(){H(this)}),t),50)}function U(t,n){setTimeout(i((function(){f(this.g.a);f(this.h.a);f(this.j.a);f(this.o.a);n(this.a)}),t),0)}function z(t,n,i){this.c=t;this.a=n;this.f=0;this.o=this.j=!1;this.s=i}var G=null;z.prototype.g=function(t){var n=this.a;n.g&&c(n.f,[n.a.c("wf",t.c,_(t).toString(),"active")],[n.a.c("wf",t.c,_(t).toString(),"loading"),n.a.c("wf",t.c,_(t).toString(),"inactive")]);A(n,"fontactive",t);this.o=!0;K(this)};z.prototype.h=function(t){var n=this.a;if(n.g){var i=h(n.f,n.a.c("wf",t.c,_(t).toString(),"active")),e=[],o=[n.a.c("wf",t.c,_(t).toString(),"loading")];i||e.push(n.a.c("wf",t.c,_(t).toString(),"inactive"));c(n.f,e,o)}A(n,"fontinactive",t);K(this)};function K(t){0==--t.f&&t.j&&(t.o?(t=t.a,t.g&&c(t.f,[t.a.c("wf","active")],[t.a.c("wf","loading"),t.a.c("wf","inactive")]),A(t,"active")):N(t.a))}function R(t){this.j=t;this.a=new E;this.h=0;this.f=this.g=!0}R.prototype.load=function(t){this.c=new o(this.j,t.context||this.j);this.g=!1!==t.events;this.f=!1!==t.classes;Q(this,new S(this.c,t),t)};function J(t,n,e,o,a){var s=0==--t.h;(t.f||t.g)&&setTimeout((function(){var t=a||null,r=o||null||{};if(0===e.length&&s)N(n.a);else{n.f+=e.length;s&&(n.j=s);var f,h=[];for(f=0;f<e.length;f++){var l=e[f],u=r[l.c],p=n.a,d=l;p.g&&c(p.f,[p.a.c("wf",d.c,_(d).toString(),"loading")]);A(p,"fontloading",d);p=null;null===G&&(G=window.FontFace?(d=/Gecko.*Firefox\/(\d+)/.exec(window.navigator.userAgent))?42<parseInt(d[1],10):!0:!1);G?p=new B(i(n.g,n),i(n.h,n),n.c,l,n.s,u):p=new O(i(n.g,n),i(n.h,n),n.c,l,n.s,t,u);h.push(p)}for(f=0;f<h.length;f++)h[f].start()}}),0)}function Q(t,n,i){var e=[],o=i.timeout;C(n);var e=W(t.a,i,t.c),a=new z(t.c,n,o);t.h=e.length;n=0;for(i=e.length;n<i;n++)e[n].load((function(n,i,e){J(t,a,n,i,e)}))}function V(t,n){this.c=t;this.a=n}function X(t,n,i){var e=l(t.c);t=(t.a.api||"fast.fonts.net/jsapi").replace(/^.*http(s?):(\/\/)?/,"");return e+"//"+t+"/"+n+".js"+(i?"?v="+i:"")}V.prototype.load=function(t){function n(){if(a["__mti_fntLst"+e]){var i=a["__mti_fntLst"+e](),o=[],s;if(i)for(var r=0;r<i.length;r++){var f=i[r].fontfamily;void 0!=i[r].fontStyle&&void 0!=i[r].fontWeight?(s=i[r].fontStyle+i[r].fontWeight,o.push(new b(f,s))):o.push(new b(f))}t(o)}else setTimeout((function(){n()}),50)}var i=this,e=i.a.projectId,o=i.a.version;if(e){var a=i.c.m;d(this.c,X(i,e,o),(function(o){o?t([]):(a["__MonotypeConfiguration__"+e]=function(){return i.a},n())})).id="__MonotypeAPIScript__"+e}else t([])};function Y(t,n){this.c=t;this.a=n}Y.prototype.load=function(t){var n,i,e=this.a.urls||[],o=this.a.families||[],a=this.a.testStrings||{},s=new g;n=0;for(i=e.length;n<i;n++)p(this.c,e[n],v(s));var r=[];n=0;for(i=o.length;n<i;n++)if(e=o[n].split(":"),e[1])for(var f=e[1].split(","),c=0;c<f.length;c+=1)r.push(new b(e[0],f[c]));else r.push(new b(e[0]));w(s,(function(){t(r,a)}))};function Z(t,n,i){var e=window.fontsProxyUrl??"fonts.googleapis.com";e="//"+e+"/css";t?this.c=t:this.c=n+e;this.a=[];this.f=[];this.g=i||""}function tt(t,n){for(var i=n.length,e=0;e<i;e++){var o=n[e].split(":");3==o.length&&t.f.push(o.pop());var a="";2==o.length&&""!=o[1]&&(a=":");t.a.push(o.join(a))}}function nt(t){if(0==t.a.length)throw Error("No fonts to load!");if(-1!=t.c.indexOf("kit="))return t.c;for(var n=t.a.length,i=[],e=0;e<n;e++)i.push(t.a[e].replace(/ /g,"+"));n=t.c+"?family="+i.join("%7C");0<t.f.length&&(n+="&subset="+t.f.join(","));0<t.g.length&&(n+="&text="+encodeURIComponent(t.g));return n}function it(t){this.f=t;this.a=[];this.c={}}var et={latin:"BESbswy","latin-ext":"\xe7\xf6\xfc\u011f\u015f",cyrillic:"\u0439\u044f\u0416",greek:"\u03b1\u03b2\u03a3",khmer:"\u1780\u1781\u1782",Hanuman:"\u1780\u1781\u1782"},ot={thin:"1",extralight:"2","extra-light":"2",ultralight:"2","ultra-light":"2",light:"3",regular:"4",book:"4",medium:"5","semi-bold":"6",semibold:"6","demi-bold":"6",demibold:"6",bold:"7","extra-bold":"8",extrabold:"8","ultra-bold":"8",ultrabold:"8",black:"9",heavy:"9",l:"3",r:"4",b:"7"},at={i:"i",italic:"i",n:"n",normal:"n"},st=/^(thin|(?:(?:extra|ultra)-?)?light|regular|book|medium|(?:(?:semi|demi|extra|ultra)-?)?bold|black|heavy|l|r|b|[1-9]00)?(n|i|normal|italic)?$/;function rt(t){for(var n=t.f.length,i=0;i<n;i++){var e=t.f[i].split(":"),o=e[0].replace(/\+/g," "),a=["n4"];if(2<=e.length){var s;var r=e[1];s=[];if(r)for(var r=r.split(","),f=r.length,c=0;c<f;c++){var h;h=r[c];if(h.match(/^[\w-]+$/)){var l=st.exec(h.toLowerCase());if(null==l)h="";else{h=l[2];h=null==h||""==h?"n":at[h];l=l[1];if(null==l||""==l)l="4";else var u=ot[l],l=u?u:isNaN(l)?"4":l.substr(0,1);h=[h,l].join("")}}else h="";h&&s.push(h)}0<s.length&&(a=s);3==e.length&&(e=e[2],s=[],e=e?e.split(","):s,0<e.length&&(e=et[e[0]])&&(t.c[o]=e))}t.c[o]||(e=et[o])&&(t.c[o]=e);for(e=0;e<a.length;e+=1)t.a.push(new b(o,a[e]))}}function ft(t,n){this.c=t;this.a=n}var ct={Arimo:!0,Cousine:!0,Tinos:!0};ft.prototype.load=function(t){var n=new g,i=this.c,e=new Z(this.a.api,l(i),this.a.text),o=this.a.families;tt(e,o);var a=new it(o);rt(a);p(i,nt(e),v(n));w(n,(function(){t(a.a,a.c,ct)}))};function ht(t,n){this.c=t;this.a=n}ht.prototype.load=function(t){var n=this.a.id,i=this.c.m;n?d(this.c,(this.a.api||"https://use.typekit.net")+"/"+n+".js",(function(n){if(n)t([]);else if(i.Typekit&&i.Typekit.config&&i.Typekit.config.fn){n=i.Typekit.config.fn;for(var e=[],o=0;o<n.length;o+=2)for(var a=n[o],s=n[o+1],r=0;r<s.length;r++)e.push(new b(a,s[r]));try{i.Typekit.load({events:!1,classes:!1,async:!0})}catch(t){}t(e)}}),2e3):t([])};function lt(t,n){this.c=t;this.f=n;this.a=[]}lt.prototype.load=function(t){var n=this.f.id,i=this.c.m,e=this;n?(i.__webfontfontdeckmodule__||(i.__webfontfontdeckmodule__={}),i.__webfontfontdeckmodule__[n]=function(n,i){for(var o=0,a=i.fonts.length;o<a;++o){var s=i.fonts[o];e.a.push(new b(s.name,T("font-weight:"+s.weight+";font-style:"+s.style)))}t(e.a)},d(this.c,l(this.c)+(this.f.api||"//f.fontdeck.com/s/css/js/")+u(this.c)+"/"+n+".js",(function(n){n&&t([])}))):t([])};var ut=new R(window);ut.a.c.custom=function(t,n){return new Y(n,t)};ut.a.c.fontdeck=function(t,n){return new lt(n,t)};ut.a.c.monotype=function(t,n){return new V(n,t)};ut.a.c.typekit=function(t,n){return new ht(n,t)};ut.a.c.google=function(t,n){return new ft(n,t)};var pt={load:i(ut.load,ut)};"function"===typeof define&&define.amd?define((function(){return pt})):"undefined"!==typeof module&&module.exports?module.exports=pt:(window.WebFont=pt,window.WebFontConfig&&ut.load(window.WebFontConfig))})();
/* End */
;
//# sourceMappingURL=kernel_landing_master.map.js