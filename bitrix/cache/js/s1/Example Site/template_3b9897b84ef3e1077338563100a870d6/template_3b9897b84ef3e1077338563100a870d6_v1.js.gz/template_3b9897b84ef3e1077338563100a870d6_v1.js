
; /* Start:"a:4:{s:4:"full";s:60:"/local/templates/Example Site/styles/index.css?1708195303267";s:6:"source";s:46:"/local/templates/Example Site/styles/index.css";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
.hero {
    height: min-content;
}

#portfolio {
    height: min-content;
}

#partners {
    height: min-content;
}

#about {
    height: min-content;
}

.blog {
    height: min-content;
}

#contact {
    height: min-content;
}

.footer {
    height: min-content;
}


/* End */
;; /* /local/templates/Example Site/styles/index.css?1708195303267*/
